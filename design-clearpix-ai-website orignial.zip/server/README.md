# CLEARPIX AI — API server

A real, runnable backend for the CLEARPIX AI workspace: Node + Express, versioned
REST routes, multipart uploads, a worker-thread job queue, signed sessions, plan
and credit enforcement, and a durable JSON document store.

> **Honest scope.** The cutout engine is a deterministic computer-vision pipeline
> (border flood-fill matting → enclosed-gap recovery → speckle removal → edge
> feathering → colour decontamination). It is **not** a trained neural network and
> it does **not** call any third-party AI service. There is also **no payment
> processor**: plans and credits exist only to demonstrate tier behaviour.

---

## Run it

```bash
npm install          # already done if you installed the project deps
node server/index.js
```

```
┌──────────────────────────────────────────────┐
│  CLEARPIX AI — API server                    │
│  listening  http://localhost:8787            │
│  health     http://localhost:8787/api/health │
│  catalogue  http://localhost:8787/api/v1     │
└──────────────────────────────────────────────┘
```

Run `npm run build` first and the same process will also serve the built
front-end from `dist/`, so `http://localhost:8787` gives you the whole product
on one origin.

### Front-end wiring

`src/lib/engine.ts` probes `GET /api/health` on load:

| Result | Behaviour |
| --- | --- |
| API reachable | Upload → queue job → poll progress → stream the render back |
| API unreachable | The identical pipeline runs in the browser tab |

The workspace always shows which path produced the cutout, and the result panel
reports `Engine: REST API` or `Engine: In-browser`. Point the client somewhere
else with `localStorage.setItem("clearpix.apiBase", "https://api.example.com")`
or a `VITE_API_URL` build variable.

---

## Configuration

Every value has a working default — the server runs with zero configuration.

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `8787` | HTTP port |
| `HOST` | `0.0.0.0` | Bind address |
| `CLEARPIX_SECRET` | random per boot | HMAC secret for session tokens |
| `CLEARPIX_TOKEN_TTL` | `604800` | Token lifetime in seconds |
| `CLEARPIX_DATA_DIR` | `server/data` | JSON store, uploads and renders |
| `CLEARPIX_MAX_UPLOAD` | `14680064` | Max upload size in bytes |
| `CLEARPIX_MAX_EDGE` | `1600` | Longest output edge in pixels |
| `CLEARPIX_ASSET_TTL` | `21600000` | Asset lifetime before the sweeper deletes it |
| `CLEARPIX_CORS` | `*` | Comma-separated allow-list |
| `CLEARPIX_VERBOSE` | `true` | Request/stage logging |

---

## Endpoints

Auth is a bearer token. Anonymous callers are automatically issued a **signed
guest session**, returned in the `x-clearpix-session` response header — send it
back as `Authorization: Bearer <token>` on later calls.

| Method | Path | Notes |
| --- | --- | --- |
| `GET` | `/api/health` | Liveness, capabilities, limits, queue state |
| `GET` | `/api/v1` | Self-describing route catalogue |
| `GET` | `/api/v1/stats` | Aggregate processing counters |
| `POST` | `/api/v1/auth/register` | Create a demo account (scrypt hashed) |
| `POST` | `/api/v1/auth/login` | Exchange credentials for a token |
| `POST` | `/api/v1/auth/guest` | Mint an anonymous session explicitly |
| `GET` | `/api/v1/auth/me` | Current identity and plan |
| `POST` | `/api/v1/images` | Upload one image — multipart field `image` |
| `POST` | `/api/v1/images/batch` | Upload many — multipart field `images` |
| `GET` | `/api/v1/images` | List this session's uploads |
| `GET` | `/api/v1/images/:id/file` | Original bytes |
| `DELETE` | `/api/v1/images/:id` | Delete an upload |
| `POST` | `/api/v1/jobs` | Queue a cutout — `{ imageId, sensitivity }` |
| `POST` | `/api/v1/jobs/batch` | Queue many — `{ imageIds[], sensitivity }` |
| `GET` | `/api/v1/jobs` | Job history |
| `GET` | `/api/v1/jobs/:id` | Poll `status`, `progress`, `stage` |
| `GET` | `/api/v1/jobs/:id/result.png` | Preview render, optional `?backdrop=%23FFFFFF` |
| `POST` | `/api/v1/jobs/:id/export` | Spend a credit, mint a download link |
| `GET` | `/api/v1/downloads/:exportId` | Download the exported PNG |
| `DELETE` | `/api/v1/jobs/:id` | Delete a job and its render |
| `GET` | `/api/v1/plans` | Demo pricing catalogue |
| `GET` | `/api/v1/account` | Plan, credits and usage snapshot |
| `POST` | `/api/v1/account/plan` | Switch tier (nothing is charged) |
| `POST` | `/api/v1/account/credits/reset` | Refill the demo allowance |
| `POST` | `/api/v1/contact` | Store a contact message |

### Quickstart

```bash
BASE=http://localhost:8787

# 1 — upload; grab the guest token from the response headers
TOKEN=$(curl -sS -D - -o /tmp/up.json -F image=@photo.jpg $BASE/api/v1/images \
        | awk -F': ' '/x-clearpix-session/ {print $2}' | tr -d '\r')
IMAGE=$(node -pe "require('/tmp/up.json').image.id")

# 2 — queue the cutout
JOB=$(curl -sS -X POST $BASE/api/v1/jobs \
      -H "authorization: Bearer $TOKEN" -H 'content-type: application/json' \
      -d "{\"imageId\":\"$IMAGE\",\"sensitivity\":50}" \
      | node -pe "JSON.parse(require('fs').readFileSync(0)).job.id")

# 3 — poll until "succeeded"
curl -sS $BASE/api/v1/jobs/$JOB -H "authorization: Bearer $TOKEN"

# 4 — transparent PNG
curl -sS $BASE/api/v1/jobs/$JOB/result.png -H "authorization: Bearer $TOKEN" -o cutout.png
```

### Admin endpoints (`role: "admin"` required)

An administrator is seeded on first boot — `admin@clearpix.ai` / `clearpix-admin`
unless `CLEARPIX_ADMIN_EMAIL` / `CLEARPIX_ADMIN_PASSWORD` are set. The console UI
lives at `/#/admin` in the built site.

| Method | Path | Notes |
| --- | --- | --- |
| `GET` | `/api/v1/admin/overview` | KPIs, 24h hourly series, queue, plans, storage, runtime |
| `GET` | `/api/v1/admin/users` | `?q=&kind=&plan=&role=&status=&page=&limit=` |
| `GET` | `/api/v1/admin/users/:id` | Account + recent jobs |
| `PATCH` | `/api/v1/admin/users/:id` | `plan`, `credits`, `addCredits`, `role`, `status`, `name` |
| `DELETE` | `/api/v1/admin/users/:id` | Cascades images, jobs, exports and files |
| `GET` | `/api/v1/admin/jobs` | `?status=&q=&page=&limit=` — every session |
| `GET` | `/api/v1/admin/jobs/:id/result.png` | Any job's render |
| `POST` | `/api/v1/admin/jobs/:id/retry` | Re-queue (optional `sensitivity`) |
| `DELETE` | `/api/v1/admin/jobs/:id` | Remove job, render and its exports |
| `GET` | `/api/v1/admin/images` · `/images/:id/file` · `DELETE /images/:id` | Uploads on disk |
| `GET` | `/api/v1/admin/exports` | Credit ledger |
| `GET` | `/api/v1/admin/messages` | `?status=received|read|resolved&q=` |
| `PATCH` | `/api/v1/admin/messages/:id` | `{ status }` |
| `DELETE` | `/api/v1/admin/messages/:id` | |
| `GET` | `/api/v1/admin/system` | Runtime, config, storage, settings, recent logs |
| `GET` | `/api/v1/admin/logs` | `?limit=&level=` — in-memory ring buffer |
| `PATCH` | `/api/v1/admin/system/settings` | `acceptingJobs` (pause → clients get `503 maintenance`), `maintenanceMessage` |
| `POST` | `/api/v1/admin/system/sweep` | Run the TTL sweep now |
| `POST` | `/api/v1/admin/system/purge-guests` | Drop guest sessions idle for 24h+ with their assets |

Safety rails: admins cannot demote, suspend or delete themselves; guests cannot be
promoted; suspended accounts are refused at the identity layer with `403`; and
`<img>`-friendly access is possible by passing the bearer token as `?token=`.

### Error shape

```json
{
  "error": {
    "code": "bad_request",
    "message": "Some fields did not pass validation.",
    "details": { "email": "Enter a valid email address." }
  }
}
```

`400 bad_request` · `401 unauthorized` · `402 credits_exhausted` ·
`403 forbidden` · `404 not_found` · `409 conflict` · `413 payload_too_large` ·
`415 unsupported_media_type` · `429 rate_limited` · `500 internal_error`

---

## Architecture

```
server/
├── index.js              bootstrap, graceful shutdown, housekeeping
├── app.js                express wiring, security headers, CORS, static dist
├── config.js             env-driven config, plan catalogue, capability flags
├── lib/
│   ├── auth.js           scrypt password hashing + HMAC session tokens
│   ├── errors.js         ApiError hierarchy and asyncHandler
│   ├── imageio.js        pure-JS PNG/JPEG decode, area-average resize, PNG encode
│   ├── logger.js         coloured structured logs + request timing
│   ├── queue.js          FIFO queue, worker pool, progress fan-out, timeouts
│   ├── segment.js        the cutout pipeline (shared logic with the client)
│   ├── store.js          atomic JSON store, collections, TTL sweeper
│   ├── validate.js       dependency-free schema validation
│   └── worker.js         worker-thread entry: decode → fit → matte → encode
├── middleware/
│   ├── auth.js           identity resolution, ownership checks, credit spend
│   ├── error.js          404 + central error serialisation
│   ├── rateLimit.js      sliding-window limiter
│   └── upload.js         multer disk storage, MIME and size guards
└── routes/               auth · images · jobs · account/plans · meta/contact
```

**Design notes**

- *No native modules.* PNG/JPEG IO is pure JavaScript (`pngjs`, `jpeg-js`), so
  the server runs anywhere Node runs with no system libraries or build step.
  WEBP is accepted on upload but cannot be decoded server-side; the API says so
  with a `415` and the client simply handles those files locally.
- *Off the event loop.* Segmentation is CPU-bound, so each job runs in a
  `worker_thread` with a 60 s timeout, streaming stage-by-stage progress back to
  the queue for polling clients.
- *No database to provision.* Documents live in `server/data/db.json`, written
  atomically (tmp file + rename) and debounced. Uploads and renders are files on
  disk, swept on a timer and on boot.
- *Ownership everywhere.* Images, jobs, exports and messages all carry an
  `ownerId`; every read and write is checked against the caller's session.
