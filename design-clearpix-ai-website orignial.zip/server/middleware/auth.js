import { planById } from "../config.js";
import { bearerFrom, issueGuestToken, readToken } from "../lib/auth.js";
import { forbidden, unauthorized } from "../lib/errors.js";
import { find, id, insert, now, update } from "../lib/store.js";

/**
 * Resolves `req.actor` for every request.
 *
 * Signed-in users are looked up in the store; everyone else gets a signed
 * guest identity so demo export credits can be tracked without an account.
 * A fresh guest token is handed back in the `x-clearpix-session` header.
 */
export function identify(req, res, next) {
  const claims = readToken(bearerFrom(req));

  if (claims?.kind === "user") {
    const user = find("users", (u) => u.id === claims.sub);
    if (user) {
      if (user.status === "suspended") {
        return next(forbidden("This account has been suspended by an administrator."));
      }
      req.actor = { kind: "user", id: user.id, user, plan: planById(user.plan) };
      return next();
    }
  }

  if (claims?.kind === "guest") {
    let guest = find("users", (u) => u.id === claims.sub);
    if (!guest) guest = createGuest(claims.sub);
    if (guest.status === "suspended") {
      return next(forbidden("This session has been suspended by an administrator."));
    }
    req.actor = { kind: "guest", id: guest.id, user: guest, plan: planById(guest.plan) };
    return next();
  }

  const guest = createGuest();
  const token = issueGuestToken(guest.id);
  res.set("x-clearpix-session", token);
  req.actor = { kind: "guest", id: guest.id, user: guest, plan: planById(guest.plan), token };
  next();
}

function createGuest(forcedId) {
  const plan = planById("free");
  return insert("users", {
    id: forcedId ?? id("gst"),
    kind: "guest",
    role: "member",
    status: "active",
    email: null,
    name: "Guest",
    passwordHash: null,
    plan: plan.id,
    credits: plan.exportCredits,
    createdAt: now(),
    updatedAt: now(),
  });
}

/** Require a real, registered account. */
export function requireUser(req, _res, next) {
  if (req.actor?.kind !== "user") {
    return next(unauthorized("Sign in to use this endpoint."));
  }
  next();
}

/** Require an administrator. */
export function requireAdmin(req, _res, next) {
  if (req.actor?.kind !== "user" || req.actor.user.role !== "admin") {
    return next(forbidden("Administrator access required."));
  }
  next();
}

/** Require the actor to own the document, otherwise 403. */
export function requireOwner(doc, req) {
  if (!doc || doc.ownerId !== req.actor.id) {
    throw forbidden("This resource belongs to another session.");
  }
  return doc;
}

/** Spend one export credit, or throw. */
export function spendCredit(req) {
  const user = req.actor.user;
  if ((user.credits ?? 0) <= 0) return false;
  update("users", (u) => u.id === user.id, { credits: user.credits - 1 });
  return true;
}
