import { config } from "../config.js";
import { ApiError } from "../lib/errors.js";
import { logger } from "../lib/logger.js";

export function notFoundHandler(req, res) {
  res.status(404).json({
    error: {
      code: "not_found",
      message: `No route matches ${req.method} ${req.originalUrl}.`,
      hint: "Browse the catalogue at GET /api/v1",
    },
  });
}

// eslint-disable-next-line no-unused-vars -- Express needs the 4-arg signature
export function errorHandler(err, req, res, _next) {
  if (err instanceof ApiError) {
    if (err.status >= 500) logger.error(`${err.code}: ${err.message}`);
    return res.status(err.status).json(err.toJSON());
  }

  if (err?.type === "entity.too.large") {
    return res.status(413).json({
      error: { code: "payload_too_large", message: "Request body is too large." },
    });
  }

  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({
      error: { code: "bad_json", message: "Request body is not valid JSON." },
    });
  }

  logger.error(`unhandled ${err?.name ?? "Error"}: ${err?.message ?? err}`);
  if (config.env !== "production" && err?.stack) console.error(err.stack);

  res.status(500).json({
    error: {
      code: "internal_error",
      message: "Something went wrong on our side.",
      ...(config.env === "production" ? {} : { debug: String(err?.message ?? err) }),
    },
  });
}
