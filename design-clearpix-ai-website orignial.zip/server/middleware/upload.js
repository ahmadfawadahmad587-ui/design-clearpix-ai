import crypto from "node:crypto";
import path from "node:path";
import multer from "multer";
import { config } from "../config.js";
import { UPLOAD_DIR } from "../lib/store.js";
import { payloadTooLarge, unsupportedMedia } from "../lib/errors.js";

const EXT = {
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/jpg": ".jpg",
  "image/webp": ".webp",
};

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) =>
    cb(null, `img_${crypto.randomBytes(9).toString("hex")}${EXT[file.mimetype] ?? ".bin"}`),
});

const multerUpload = multer({
  storage,
  limits: { fileSize: config.uploads.maxBytes, files: 25 },
  fileFilter: (_req, file, cb) => {
    if (!config.uploads.mimeTypes.includes(file.mimetype)) {
      cb(unsupportedMedia(`"${file.mimetype}" is not supported. Use PNG, JPG or WEBP.`));
      return;
    }
    cb(null, true);
  },
});

/** Normalises multer's own errors into our ApiError shape. */
const wrap = (handler) => (req, res, next) =>
  handler(req, res, (err) => {
    if (!err) return next();
    if (err.code === "LIMIT_FILE_SIZE") {
      return next(
        payloadTooLarge(
          `That file is larger than ${(config.uploads.maxBytes / 1048576).toFixed(0)} MB.`,
        ),
      );
    }
    if (err.code === "LIMIT_FILE_COUNT" || err.code === "LIMIT_UNEXPECTED_FILE") {
      return next(unsupportedMedia("Too many files in that request."));
    }
    next(err);
  });

export const uploadSingle = wrap(multerUpload.single("image"));
export const uploadMany = wrap(multerUpload.array("images", 25));
export const uploadPath = (file) => path.join(UPLOAD_DIR, file);
