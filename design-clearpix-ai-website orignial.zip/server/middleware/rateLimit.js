import { config } from "../config.js";
import { tooManyRequests } from "../lib/errors.js";

/**
 * In-memory sliding-window rate limiter keyed by bucket + client IP.
 * Good enough for a single-process prototype; swap for Redis to scale out.
 */
const windows = new Map();

const clientKey = (req) =>
  (req.get("x-forwarded-for")?.split(",")[0] ?? req.ip ?? req.socket.remoteAddress ?? "unknown").trim();

export function rateLimit(bucket, max = config.rateLimit.general, windowMs = config.rateLimit.windowMs) {
  return (req, res, next) => {
    const key = `${bucket}:${clientKey(req)}`;
    const nowMs = Date.now();
    const hits = (windows.get(key) ?? []).filter((t) => nowMs - t < windowMs);

    if (hits.length >= max) {
      const retryAfter = Math.ceil((windowMs - (nowMs - hits[0])) / 1000);
      res.set("retry-after", String(retryAfter));
      return next(
        tooManyRequests(`Too many requests on "${bucket}". Try again in ${retryAfter}s.`, retryAfter),
      );
    }

    hits.push(nowMs);
    windows.set(key, hits);
    res.set("x-ratelimit-limit", String(max));
    res.set("x-ratelimit-remaining", String(Math.max(0, max - hits.length)));
    next();
  };
}

/** Periodically drop empty buckets so the map cannot grow unbounded. */
const gc = setInterval(() => {
  const cutoff = Date.now() - config.rateLimit.windowMs;
  for (const [key, hits] of windows) {
    const live = hits.filter((t) => t > cutoff);
    if (live.length) windows.set(key, live);
    else windows.delete(key);
  }
}, config.rateLimit.windowMs);
gc.unref?.();
