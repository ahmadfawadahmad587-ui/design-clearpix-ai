import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const bool = (v, fallback) =>
  v === undefined ? fallback : ["1", "true", "yes", "on"].includes(String(v).toLowerCase());

export const config = {
  env: process.env.NODE_ENV ?? "development",
  port: Number(process.env.PORT ?? 8787),
  host: process.env.HOST ?? "0.0.0.0",

  /** Where the JSON store and uploaded/derived files live. */
  dataDir: process.env.CLEARPIX_DATA_DIR ?? path.join(__dirname, "data"),

  /**
   * Signing secret for session tokens. A random secret is generated at boot in
   * development so the server is runnable with zero configuration — set
   * CLEARPIX_SECRET in production so tokens survive a restart.
   */
  secret: process.env.CLEARPIX_SECRET ?? crypto.randomBytes(32).toString("hex"),
  tokenTtlSeconds: Number(process.env.CLEARPIX_TOKEN_TTL ?? 60 * 60 * 24 * 7),

  cors: {
    /** "*" accepts any origin, otherwise a comma separated allow-list. */
    origins: (process.env.CLEARPIX_CORS ?? "*").split(",").map((s) => s.trim()),
  },

  uploads: {
    maxBytes: Number(process.env.CLEARPIX_MAX_UPLOAD ?? 14 * 1024 * 1024),
    mimeTypes: ["image/png", "image/jpeg", "image/jpg", "image/webp"],
    /** Longest edge of the processed output. */
    maxEdge: Number(process.env.CLEARPIX_MAX_EDGE ?? 1600),
    /** Delete uploads + renders older than this (ms). 0 disables the sweep. */
    ttlMs: Number(process.env.CLEARPIX_ASSET_TTL ?? 1000 * 60 * 60 * 6),
  },

  rateLimit: {
    windowMs: 60_000,
    general: 240,
    write: 40,
    auth: 12,
  },

  /** Demo plan catalogue. No payment processor is connected to any of these. */
  plans: [
    {
      id: "free",
      name: "Free",
      price: 0,
      currency: "USD",
      cadence: "forever",
      exportCredits: 3,
      maxEdge: 1200,
      batchSize: 1,
      features: ["3 demo exports", "Standard preview quality", "Basic tools", "Transparent PNG download"],
    },
    {
      id: "pro",
      name: "Pro",
      price: 12,
      currency: "USD",
      cadence: "month",
      exportCredits: 500,
      maxEdge: 2400,
      batchSize: 10,
      features: [
        "More export credits",
        "HD export options",
        "Premium editing tools",
        "Backdrop replacement presets",
        "Priority processing queue",
        "Export history",
      ],
    },
    {
      id: "business",
      name: "Business",
      price: 39,
      currency: "USD",
      cadence: "month",
      exportCredits: 5000,
      maxEdge: 4000,
      batchSize: 50,
      features: [
        "Team workspace",
        "Batch workflow",
        "Business-oriented features",
        "Shared brand presets",
        "Role-based access",
        "Dedicated support channel",
      ],
    },
  ],

  /**
   * Honest capability flags surfaced on GET /api/health so the client never has
   * to guess what the server can actually do.
   */
  capabilities: {
    engine: "edge-aware-colour-matting",
    neuralNetwork: false,
    decode: ["image/png", "image/jpeg"],
    encode: ["image/png"],
    note:
      "Deterministic computer-vision matting (border flood-fill + feathering + colour decontamination). No trained model and no third-party AI service is used.",
  },

  verboseLogs: bool(process.env.CLEARPIX_VERBOSE, true),
};

export const planById = (id) => config.plans.find((p) => p.id === id) ?? config.plans[0];
