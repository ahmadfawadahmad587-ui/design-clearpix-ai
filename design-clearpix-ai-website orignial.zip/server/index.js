import { createApp } from "./app.js";
import { config } from "./config.js";
import { logger } from "./lib/logger.js";
import { queueStats } from "./lib/queue.js";
import { ADMIN_EMAIL, ensureAdmin } from "./lib/seed.js";
import { flushSync, initStore, startHousekeeping, sweepExpiredAssets } from "./lib/store.js";

async function main() {
  await initStore();
  ensureAdmin();
  await sweepExpiredAssets();
  const stopHousekeeping = startHousekeeping();

  const app = createApp();
  const server = app.listen(config.port, config.host, () => {
    const base = `http://localhost:${config.port}`;
    logger.banner([
      "CLEARPIX AI — API server",
      "",
      `env        ${config.env}`,
      `listening  ${base}`,
      `health     ${base}/api/health`,
      `catalogue  ${base}/api/v1`,
      `engine     ${config.capabilities.engine} (no neural network)`,
      `workers    ${queueStats().concurrency} concurrent cutout thread(s)`,
      `data dir   ${config.dataDir}`,
      `admin      ${base}/#/admin  (${ADMIN_EMAIL})`,
    ]);
    if (!process.env.CLEARPIX_SECRET) {
      logger.warn("CLEARPIX_SECRET is unset — a random token secret was generated for this run.");
    }
  });

  server.headersTimeout = 70_000;
  server.requestTimeout = 120_000;

  const shutdown = (signal) => {
    logger.info(`${signal} received — shutting down`);
    stopHousekeeping();
    flushSync();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 4000).unref();
  };

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("unhandledRejection", (reason) => logger.error(`unhandled rejection: ${reason}`));
  process.on("uncaughtException", (err) => {
    logger.error(`uncaught exception: ${err.message}`);
    flushSync();
  });
}

main().catch((err) => {
  logger.error(`failed to start: ${err.stack ?? err.message}`);
  process.exit(1);
});
