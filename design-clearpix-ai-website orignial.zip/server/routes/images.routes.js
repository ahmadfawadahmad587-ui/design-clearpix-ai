import fsp from "node:fs/promises";
import { Router } from "express";
import { config } from "../config.js";
import { asyncHandler, badRequest, notFound } from "../lib/errors.js";
import { sniffFormat } from "../lib/imageio.js";
import { UPLOAD_DIR, filter, find, id, insert, now, remove } from "../lib/store.js";
import { requireOwner } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rateLimit.js";
import { uploadMany, uploadPath, uploadSingle } from "../middleware/upload.js";
import path from "node:path";

export const imageRoutes = Router();

const publicImage = (img) => ({
  id: img.id,
  name: img.name,
  mimeType: img.mimeType,
  bytes: img.bytes,
  format: img.format,
  createdAt: img.createdAt,
  sourceUrl: `/api/v1/images/${img.id}/file`,
  expiresAt: img.expiresAt,
});

async function record(file, req) {
  const buf = await fsp.readFile(file.path);
  const format = sniffFormat(buf);
  if (format === "unknown") {
    await fsp.unlink(file.path).catch(() => {});
    throw badRequest(`"${file.originalname}" is not a readable PNG, JPEG or WEBP image.`);
  }
  return insert("images", {
    id: id("img"),
    ownerId: req.actor.id,
    name: file.originalname,
    file: path.basename(file.path),
    mimeType: file.mimetype,
    bytes: file.size,
    format,
    createdAt: now(),
    expiresAt: new Date(Date.now() + config.uploads.ttlMs).toISOString(),
  });
}

/** POST /api/v1/images — multipart field "image" */
imageRoutes.post(
  "/",
  rateLimit("upload", config.rateLimit.write),
  uploadSingle,
  asyncHandler(async (req, res) => {
    if (!req.file) throw badRequest('Attach a file in the multipart field "image".');
    const img = await record(req.file, req);
    res.status(201).json({ image: publicImage(img) });
  }),
);

/** POST /api/v1/images/batch — multipart field "images" (repeatable) */
imageRoutes.post(
  "/batch",
  rateLimit("upload", config.rateLimit.write),
  uploadMany,
  asyncHandler(async (req, res) => {
    const files = req.files ?? [];
    if (!files.length) throw badRequest('Attach one or more files in the multipart field "images".');
    const limit = req.actor.plan.batchSize;
    if (files.length > limit) {
      await Promise.all(files.map((f) => fsp.unlink(f.path).catch(() => {})));
      throw badRequest(
        `The ${req.actor.plan.name} plan accepts ${limit} image(s) per batch — you sent ${files.length}.`,
        { planLimit: limit },
      );
    }
    const images = [];
    for (const file of files) images.push(publicImage(await record(file, req)));
    res.status(201).json({ images, count: images.length });
  }),
);

/** GET /api/v1/images */
imageRoutes.get("/", (req, res) => {
  const images = filter("images", (i) => i.ownerId === req.actor.id).map(publicImage);
  res.json({ images, count: images.length });
});

/** GET /api/v1/images/:imageId */
imageRoutes.get("/:imageId", (req, res) => {
  const img = requireOwner(find("images", (i) => i.id === req.params.imageId), req);
  res.json({ image: publicImage(img) });
});

/** GET /api/v1/images/:imageId/file — original bytes */
imageRoutes.get(
  "/:imageId/file",
  asyncHandler(async (req, res) => {
    const img = requireOwner(find("images", (i) => i.id === req.params.imageId), req);
    const file = uploadPath(img.file);
    await fsp.access(file).catch(() => {
      throw notFound("That source file has already been swept from disk.");
    });
    res.type(img.mimeType);
    res.set("cache-control", "private, max-age=600");
    res.send(await fsp.readFile(file));
  }),
);

/** DELETE /api/v1/images/:imageId */
imageRoutes.delete(
  "/:imageId",
  asyncHandler(async (req, res) => {
    const img = requireOwner(find("images", (i) => i.id === req.params.imageId), req);
    await fsp.unlink(path.join(UPLOAD_DIR, img.file)).catch(() => {});
    remove("images", (i) => i.id === img.id);
    res.json({ ok: true, deleted: img.id });
  }),
);
