import fsp from "node:fs/promises";
import path from "node:path";
import { Router } from "express";
import { config } from "../config.js";
import { ApiError, asyncHandler, badRequest, notFound, paymentRequired } from "../lib/errors.js";
import { decode, encodePng, flatten } from "../lib/imageio.js";
import { enqueue, queueStats } from "../lib/queue.js";
import { RENDER_DIR, bump, data, filter, find, id, insert, now, remove } from "../lib/store.js";
import { validate } from "../lib/validate.js";
import { requireOwner, spendCredit } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rateLimit.js";

export const jobRoutes = Router();

const publicJob = (job) => ({
  id: job.id,
  imageId: job.imageId,
  status: job.status,
  progress: job.progress ?? 0,
  stage: job.stage ?? null,
  queuePosition: job.queuePosition ?? 0,
  sensitivity: job.sensitivity,
  maxEdge: job.maxEdge,
  width: job.width ?? null,
  height: job.height ?? null,
  sourceWidth: job.sourceWidth ?? null,
  sourceHeight: job.sourceHeight ?? null,
  coverage: job.coverage ?? null,
  backdrop: job.backdrop ?? null,
  backdropPurity: job.backdropPurity ?? null,
  engineMs: job.engineMs ?? null,
  totalMs: job.totalMs ?? null,
  bytes: job.bytes ?? null,
  error: job.error ?? null,
  createdAt: job.createdAt,
  finishedAt: job.finishedAt ?? null,
  resultUrl: job.status === "succeeded" ? `/api/v1/jobs/${job.id}/result.png` : null,
});

function createJob(req, imageId, sensitivity) {
  const settings = data().settings ?? {};
  if (settings.acceptingJobs === false && req.actor.user.role !== "admin") {
    throw new ApiError(
      503,
      "maintenance",
      settings.maintenanceMessage || "Processing is paused for maintenance. Please try again shortly.",
    );
  }
  const image = requireOwner(find("images", (i) => i.id === imageId), req);
  const maxEdge = Math.min(config.uploads.maxEdge, req.actor.plan.maxEdge);
  const job = insert("jobs", {
    id: id("job"),
    ownerId: req.actor.id,
    imageId: image.id,
    imageName: image.name,
    status: "queued",
    progress: 0,
    stage: "Queued",
    sensitivity,
    maxEdge,
    createdAt: now(),
    updatedAt: now(),
  });
  enqueue(job, image);
  return job;
}

/** POST /api/v1/jobs — queue a cutout */
jobRoutes.post(
  "/",
  rateLimit("jobs", config.rateLimit.write),
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      imageId: { type: "string", required: true },
      sensitivity: { type: "int", min: 8, max: 95, default: 50 },
    });
    const job = createJob(req, body.imageId, body.sensitivity);
    res.status(202).json({
      job: publicJob(find("jobs", (j) => j.id === job.id)),
      queue: queueStats(),
      pollUrl: `/api/v1/jobs/${job.id}`,
    });
  }),
);

/** POST /api/v1/jobs/batch — queue many cutouts at once */
jobRoutes.post(
  "/batch",
  rateLimit("jobs", config.rateLimit.write),
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      imageIds: { type: "array", required: true, min: 1, max: 50 },
      sensitivity: { type: "int", min: 8, max: 95, default: 50 },
    });
    const limit = req.actor.plan.batchSize;
    if (body.imageIds.length > limit) {
      throw badRequest(
        `Batch size ${body.imageIds.length} exceeds the ${req.actor.plan.name} plan limit of ${limit}.`,
        { planLimit: limit },
      );
    }
    const jobs = body.imageIds.map((imageId) =>
      publicJob(find("jobs", (j) => j.id === createJob(req, String(imageId), body.sensitivity).id)),
    );
    res.status(202).json({ jobs, count: jobs.length, queue: queueStats() });
  }),
);

/** GET /api/v1/jobs — history for this session */
jobRoutes.get("/", (req, res) => {
  const jobs = filter("jobs", (j) => j.ownerId === req.actor.id).map(publicJob);
  res.json({ jobs, count: jobs.length, queue: queueStats() });
});

/** GET /api/v1/jobs/:jobId — poll progress */
jobRoutes.get("/:jobId", (req, res) => {
  const job = requireOwner(find("jobs", (j) => j.id === req.params.jobId), req);
  res.set("cache-control", "no-store");
  res.json({ job: publicJob(job), queue: queueStats() });
});

/** GET /api/v1/jobs/:jobId/result.png — preview render (free, no credit spent) */
jobRoutes.get(
  "/:jobId/result.png",
  asyncHandler(async (req, res) => {
    const job = requireOwner(find("jobs", (j) => j.id === req.params.jobId), req);
    if (job.status !== "succeeded") {
      throw badRequest(`Job is "${job.status}" — no render is available yet.`);
    }
    const file = path.join(RENDER_DIR, job.file);
    const png = await fsp.readFile(file).catch(() => {
      throw notFound("That render has already been swept from disk.");
    });

    const backdrop = typeof req.query.backdrop === "string" ? req.query.backdrop : null;
    const body = backdrop
      ? encodePng(flatten(decode(png), validate({ backdrop }, { backdrop: { type: "hexColor" } }).backdrop))
      : png;

    res.type("image/png");
    res.set("cache-control", "private, max-age=300");
    res.set("x-clearpix-transparent", backdrop ? "false" : "true");
    res.send(body);
  }),
);

/** POST /api/v1/jobs/:jobId/export — spend a credit, mint a download link */
jobRoutes.post(
  "/:jobId/export",
  rateLimit("export", config.rateLimit.write),
  asyncHandler(async (req, res) => {
    const job = requireOwner(find("jobs", (j) => j.id === req.params.jobId), req);
    if (job.status !== "succeeded") throw badRequest("That job has not produced a render yet.");

    const body = validate(req.body, {
      backdrop: { type: "hexColor" },
      filename: { type: "string", max: 120 },
    });

    if (!spendCredit(req)) {
      throw paymentRequired(
        "Demo export allowance used up. Reset it from the credits panel — this prototype has no billing.",
        { plan: req.actor.plan.id, credits: 0 },
      );
    }

    const record = insert("exports", {
      id: id("exp"),
      ownerId: req.actor.id,
      jobId: job.id,
      backdrop: body.backdrop ?? null,
      filename:
        body.filename ??
        `clearpix-${(job.imageName ?? "image").replace(/\.[^.]+$/, "")}-cutout.png`,
      createdAt: now(),
      downloads: 0,
    });
    bump("exports");

    res.status(201).json({
      export: {
        id: record.id,
        filename: record.filename,
        backdrop: record.backdrop,
        transparent: !record.backdrop,
        downloadUrl: `/api/v1/downloads/${record.id}`,
      },
      creditsRemaining: req.actor.user.credits,
      notice: "No payment was taken. Export credits exist only to demonstrate plan limits.",
    });
  }),
);

/** DELETE /api/v1/jobs/:jobId */
jobRoutes.delete(
  "/:jobId",
  asyncHandler(async (req, res) => {
    const job = requireOwner(find("jobs", (j) => j.id === req.params.jobId), req);
    if (job.file) await fsp.unlink(path.join(RENDER_DIR, job.file)).catch(() => {});
    remove("jobs", (j) => j.id === job.id);
    res.json({ ok: true, deleted: job.id });
  }),
);

/* ------------------------------------------------------------------ */
/* Downloads                                                           */
/* ------------------------------------------------------------------ */
export const downloadRoutes = Router();

/** GET /api/v1/downloads/:exportId — the actual file transfer */
downloadRoutes.get(
  "/:exportId",
  asyncHandler(async (req, res) => {
    const record = requireOwner(find("exports", (e) => e.id === req.params.exportId), req);
    const job = find("jobs", (j) => j.id === record.jobId);
    if (!job?.file) throw notFound("The render behind this export is gone.");

    const png = await fsp.readFile(path.join(RENDER_DIR, job.file)).catch(() => {
      throw notFound("The render behind this export is gone.");
    });
    const body = record.backdrop ? encodePng(flatten(decode(png), record.backdrop)) : png;

    record.downloads += 1;
    res.type("image/png");
    res.set("content-disposition", `attachment; filename="${record.filename}"`);
    res.set("cache-control", "no-store");
    res.send(body);
  }),
);
