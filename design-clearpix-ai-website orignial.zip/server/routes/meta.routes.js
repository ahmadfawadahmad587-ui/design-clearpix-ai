import { Router } from "express";
import { config } from "../config.js";
import { asyncHandler } from "../lib/errors.js";
import { queueStats } from "../lib/queue.js";
import { data, id, insert, now } from "../lib/store.js";
import { validate } from "../lib/validate.js";
import { rateLimit } from "../middleware/rateLimit.js";
import { logger } from "../lib/logger.js";

export const metaRoutes = Router();
export const contactRoutes = Router();

const bootedAt = Date.now();

/** GET /api/health — liveness, capabilities and an honest engine description */
metaRoutes.get("/health", (_req, res) => {
  res.set("cache-control", "no-store");
  res.json({
    status: "ok",
    service: "clearpix-api",
    version: "1.0.0",
    env: config.env,
    uptimeSeconds: Math.round((Date.now() - bootedAt) / 1000),
    capabilities: config.capabilities,
    limits: {
      maxUploadBytes: config.uploads.maxBytes,
      maxEdge: config.uploads.maxEdge,
      mimeTypes: config.uploads.mimeTypes,
      assetTtlMs: config.uploads.ttlMs,
    },
    queue: queueStats(),
    maintenance: {
      acceptingJobs: data().settings?.acceptingJobs !== false,
      message: data().settings?.maintenanceMessage || null,
    },
  });
});

/** GET /api/v1 — self-describing route catalogue */
metaRoutes.get("/v1", (_req, res) => {
  res.json({
    name: "CLEARPIX AI API",
    version: "1.0.0",
    description:
      "Background removal API backing the CLEARPIX AI workspace. Deterministic colour matting, not a trained model.",
    authentication:
      'Bearer token in the Authorization header. Anonymous callers are issued a guest token in the "x-clearpix-session" response header.',
    endpoints: [
      { method: "GET", path: "/api/health", summary: "Liveness, capabilities and queue state" },
      { method: "POST", path: "/api/v1/auth/register", summary: "Create a demo account" },
      { method: "POST", path: "/api/v1/auth/login", summary: "Exchange credentials for a token" },
      { method: "POST", path: "/api/v1/auth/guest", summary: "Mint an anonymous session" },
      { method: "GET", path: "/api/v1/auth/me", summary: "Current identity and plan" },
      { method: "POST", path: "/api/v1/images", summary: "Upload one image (multipart: image)" },
      { method: "POST", path: "/api/v1/images/batch", summary: "Upload many images (multipart: images)" },
      { method: "GET", path: "/api/v1/images", summary: "List uploads for this session" },
      { method: "DELETE", path: "/api/v1/images/:imageId", summary: "Delete an upload" },
      { method: "POST", path: "/api/v1/jobs", summary: "Queue a cutout job" },
      { method: "POST", path: "/api/v1/jobs/batch", summary: "Queue a batch of cutout jobs" },
      { method: "GET", path: "/api/v1/jobs/:jobId", summary: "Poll job status and progress" },
      { method: "GET", path: "/api/v1/jobs/:jobId/result.png", summary: "Preview render (optional ?backdrop=)" },
      { method: "POST", path: "/api/v1/jobs/:jobId/export", summary: "Spend a credit, mint a download link" },
      { method: "GET", path: "/api/v1/downloads/:exportId", summary: "Download the exported PNG" },
      { method: "GET", path: "/api/v1/plans", summary: "Demo pricing catalogue" },
      { method: "GET", path: "/api/v1/account", summary: "Plan, credits and usage snapshot" },
      { method: "POST", path: "/api/v1/account/plan", summary: "Switch tier (no payment involved)" },
      { method: "POST", path: "/api/v1/account/credits/reset", summary: "Refill demo export credits" },
      { method: "GET", path: "/api/v1/stats", summary: "Aggregate processing counters" },
      { method: "POST", path: "/api/v1/contact", summary: "Store a contact message" },
      { method: "GET", path: "/api/v1/admin/overview", summary: "Admin · dashboard analytics (admin role)" },
      { method: "GET", path: "/api/v1/admin/users", summary: "Admin · list and search accounts" },
      { method: "PATCH", path: "/api/v1/admin/users/:userId", summary: "Admin · plan, credits, role, suspension" },
      { method: "GET", path: "/api/v1/admin/jobs", summary: "Admin · every job across all sessions" },
      { method: "POST", path: "/api/v1/admin/jobs/:jobId/retry", summary: "Admin · re-queue a job" },
      { method: "GET", path: "/api/v1/admin/messages", summary: "Admin · contact inbox" },
      { method: "GET", path: "/api/v1/admin/system", summary: "Admin · runtime, settings and logs" },
      { method: "PATCH", path: "/api/v1/admin/system/settings", summary: "Admin · pause/resume processing" },
    ],
  });
});

/** GET /api/v1/stats — aggregate counters for the marketing site */
metaRoutes.get("/v1/stats", (_req, res) => {
  const db = data();
  res.json({
    imagesProcessed: db.counters.imagesProcessed,
    pixelsCut: db.counters.pixelsCut,
    exports: db.counters.exports,
    sessions: db.users.length,
    jobsInFlight: queueStats().active + queueStats().queued,
    since: "server boot of the local JSON store",
  });
});

/** POST /api/v1/contact */
contactRoutes.post(
  "/",
  rateLimit("contact", 8),
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      name: { type: "string", required: true, min: 2, max: 80 },
      email: { type: "email", required: true },
      topic: { type: "enum", values: ["support", "sales", "privacy", "other"], default: "support" },
      message: { type: "string", required: true, min: 10, max: 2000 },
    });

    const msg = insert("messages", {
      id: id("msg"),
      ownerId: req.actor.id,
      ...body,
      createdAt: now(),
      status: "received",
    });
    logger.info(`contact message from ${body.email} (${body.topic})`);

    res.status(202).json({
      message: { id: msg.id, status: msg.status, createdAt: msg.createdAt },
      notice: "Stored locally for the prototype. No email is actually delivered.",
    });
  }),
);
