import fsp from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { Router } from "express";
import { config, planById } from "../config.js";
import { publicUser } from "../lib/auth.js";
import { asyncHandler, badRequest, notFound } from "../lib/errors.js";
import { logger, recentLogs } from "../lib/logger.js";
import { enqueue, queueStats } from "../lib/queue.js";
import { ADMIN_EMAIL, usingDefaultAdminPassword } from "../lib/seed.js";
import {
  RENDER_DIR,
  UPLOAD_DIR,
  data,
  filter,
  find,
  id,
  insert,
  now,
  persist,
  remove,
  sweepExpiredAssets,
  update,
} from "../lib/store.js";
import { validate } from "../lib/validate.js";
import { requireAdmin } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rateLimit.js";

export const adminRoutes = Router();
adminRoutes.use(requireAdmin);
adminRoutes.use(rateLimit("admin", 600));

const bootedAt = Date.now();

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
const countBy = (list, fn) =>
  list.reduce((acc, item) => {
    const k = fn(item) ?? "unknown";
    acc[k] = (acc[k] ?? 0) + 1;
    return acc;
  }, {});

async function dirStats(dir) {
  try {
    const names = await fsp.readdir(dir);
    let bytes = 0;
    for (const n of names) {
      const st = await fsp.stat(path.join(dir, n)).catch(() => null);
      if (st?.isFile()) bytes += st.size;
    }
    return { files: names.length, bytes };
  } catch {
    return { files: 0, bytes: 0 };
  }
}

const owner = (ownerId) => {
  const u = find("users", (x) => x.id === ownerId);
  return u ? { id: u.id, name: u.name, email: u.email, kind: u.kind, plan: u.plan } : null;
};

const adminJob = (j) => ({
  id: j.id,
  status: j.status,
  progress: j.progress ?? 0,
  stage: j.stage ?? null,
  imageId: j.imageId,
  imageName: j.imageName ?? null,
  sensitivity: j.sensitivity,
  width: j.width ?? null,
  height: j.height ?? null,
  coverage: j.coverage ?? null,
  backdrop: j.backdrop ?? null,
  engineMs: j.engineMs ?? null,
  bytes: j.bytes ?? null,
  error: j.error ?? null,
  createdAt: j.createdAt,
  finishedAt: j.finishedAt ?? null,
  owner: owner(j.ownerId),
  resultUrl: j.status === "succeeded" ? `/api/v1/admin/jobs/${j.id}/result.png` : null,
  sourceUrl: `/api/v1/admin/images/${j.imageId}/file`,
});

const adminUser = (u) => {
  const jobs = filter("jobs", (j) => j.ownerId === u.id);
  return {
    ...publicUser(u),
    usage: {
      images: filter("images", (i) => i.ownerId === u.id).length,
      jobs: jobs.length,
      succeeded: jobs.filter((j) => j.status === "succeeded").length,
      exports: filter("exports", (e) => e.ownerId === u.id).length,
    },
  };
};

const paginate = (list, q) => {
  const limit = Math.min(200, Math.max(1, Number(q.limit) || 50));
  const page = Math.max(1, Number(q.page) || 1);
  return {
    items: list.slice((page - 1) * limit, page * limit),
    page,
    limit,
    total: list.length,
    pages: Math.max(1, Math.ceil(list.length / limit)),
  };
};

const matches = (q, ...fields) => {
  if (!q) return true;
  const needle = q.toLowerCase();
  return fields.some((f) => typeof f === "string" && f.toLowerCase().includes(needle));
};

/* ------------------------------------------------------------------ */
/* overview                                                            */
/* ------------------------------------------------------------------ */
adminRoutes.get(
  "/overview",
  asyncHandler(async (_req, res) => {
    const db = data();
    const jobs = db.jobs;
    const succeeded = jobs.filter((j) => j.status === "succeeded");
    const finished = jobs.filter((j) => j.status === "succeeded" || j.status === "failed");

    const nowMs = Date.now();
    const series = Array.from({ length: 24 }, (_, i) => {
      const t = new Date(nowMs - (23 - i) * 3600e3);
      return { hour: `${String(t.getHours()).padStart(2, "0")}:00`, jobs: 0, failed: 0, exports: 0 };
    });
    const bucket = (iso) => {
      const age = nowMs - Date.parse(iso);
      if (!(age >= 0 && age < 24 * 3600e3)) return null;
      return series[23 - Math.floor(age / 3600e3)];
    };
    for (const j of jobs) {
      const b = bucket(j.createdAt);
      if (!b) continue;
      b.jobs++;
      if (j.status === "failed") b.failed++;
    }
    for (const e of db.exports) {
      const b = bucket(e.createdAt);
      if (b) b.exports++;
    }

    const [uploads, renders] = await Promise.all([dirStats(UPLOAD_DIR), dirStats(RENDER_DIR)]);
    const mem = process.memoryUsage();

    res.json({
      generatedAt: now(),
      counters: db.counters,
      totals: {
        users: db.users.length,
        members: db.users.filter((u) => u.kind === "user").length,
        guests: db.users.filter((u) => u.kind === "guest").length,
        admins: db.users.filter((u) => u.role === "admin").length,
        suspended: db.users.filter((u) => u.status === "suspended").length,
        images: db.images.length,
        jobs: jobs.length,
        jobs24h: series.reduce((a, b) => a + b.jobs, 0),
        exports: db.exports.length,
        exports24h: series.reduce((a, b) => a + b.exports, 0),
        messages: db.messages.length,
        unreadMessages: db.messages.filter((m) => m.status === "received").length,
      },
      jobs: {
        byStatus: countBy(jobs, (j) => j.status),
        successRate: finished.length ? succeeded.length / finished.length : null,
        avgEngineMs: succeeded.length
          ? Math.round(succeeded.reduce((a, j) => a + (j.engineMs ?? 0), 0) / succeeded.length)
          : null,
        avgCoverage: succeeded.length
          ? succeeded.reduce((a, j) => a + (j.coverage ?? 0), 0) / succeeded.length
          : null,
        series,
      },
      plans: countBy(db.users, (u) => u.plan),
      queue: queueStats(),
      settings: db.settings,
      storage: {
        uploads,
        renders,
        bytes: uploads.bytes + renders.bytes,
      },
      system: {
        node: process.version,
        env: config.env,
        uptimeSeconds: Math.round((Date.now() - bootedAt) / 1000),
        rssBytes: mem.rss,
        heapUsedBytes: mem.heapUsed,
        cpus: os.cpus()?.length ?? 1,
        loadAvg: os.loadavg().map((n) => Number(n.toFixed(2))),
      },
      recentJobs: jobs.slice(0, 8).map(adminJob),
      recentMessages: db.messages.slice(0, 5),
    });
  }),
);

/* ------------------------------------------------------------------ */
/* users                                                               */
/* ------------------------------------------------------------------ */
adminRoutes.get("/users", (req, res) => {
  const { q, kind, plan, role, status } = req.query;
  let list = data().users.filter(
    (u) =>
      (!kind || u.kind === kind) &&
      (!plan || u.plan === plan) &&
      (!role || u.role === role) &&
      (!status || u.status === status) &&
      matches(q, u.name, u.email ?? "", u.id),
  );
  const page = paginate(list, req.query);
  res.json({ ...page, items: page.items.map(adminUser) });
});

adminRoutes.get("/users/:userId", (req, res) => {
  const u = find("users", (x) => x.id === req.params.userId);
  if (!u) throw notFound("No such user.");
  res.json({
    user: adminUser(u),
    jobs: filter("jobs", (j) => j.ownerId === u.id).slice(0, 25).map(adminJob),
  });
});

adminRoutes.patch(
  "/users/:userId",
  asyncHandler(async (req, res) => {
    const target = find("users", (x) => x.id === req.params.userId);
    if (!target) throw notFound("No such user.");

    const body = validate(req.body, {
      plan: { type: "enum", values: config.plans.map((p) => p.id) },
      credits: { type: "int", min: 0, max: 1_000_000 },
      addCredits: { type: "int", min: -1_000_000, max: 1_000_000 },
      role: { type: "enum", values: ["member", "admin"] },
      status: { type: "enum", values: ["active", "suspended"] },
      name: { type: "string", min: 2, max: 60 },
    });

    if (target.id === req.actor.id && (body.role === "member" || body.status === "suspended")) {
      throw badRequest("You cannot demote or suspend the account you are signed in with.");
    }
    if (body.role === "admin" && target.kind !== "user") {
      throw badRequest("Guest sessions cannot be promoted to administrator.");
    }

    const patch = {};
    if (body.name) patch.name = body.name;
    if (body.role) patch.role = body.role;
    if (body.status) patch.status = body.status;
    if (body.plan) {
      patch.plan = body.plan;
      patch.credits = planById(body.plan).exportCredits;
    }
    if (body.credits !== undefined) patch.credits = body.credits;
    if (body.addCredits !== undefined) {
      patch.credits = Math.max(0, (patch.credits ?? target.credits ?? 0) + body.addCredits);
    }

    const user = update("users", (x) => x.id === target.id, patch);
    logger.info(`admin ${req.actor.user.email} updated ${target.id}: ${JSON.stringify(patch)}`);
    res.json({ user: adminUser(user) });
  }),
);

adminRoutes.delete(
  "/users/:userId",
  asyncHandler(async (req, res) => {
    const target = find("users", (x) => x.id === req.params.userId);
    if (!target) throw notFound("No such user.");
    if (target.id === req.actor.id) throw badRequest("You cannot delete your own account.");

    let files = 0;
    for (const img of filter("images", (i) => i.ownerId === target.id)) {
      await fsp.unlink(path.join(UPLOAD_DIR, img.file)).then(() => files++).catch(() => {});
    }
    for (const job of filter("jobs", (j) => j.ownerId === target.id)) {
      if (job.file) await fsp.unlink(path.join(RENDER_DIR, job.file)).then(() => files++).catch(() => {});
    }
    remove("images", (i) => i.ownerId === target.id);
    remove("jobs", (j) => j.ownerId === target.id);
    remove("exports", (e) => e.ownerId === target.id);
    remove("users", (u) => u.id === target.id);
    logger.warn(`admin ${req.actor.user.email} deleted ${target.id} (${files} file(s) removed)`);
    res.json({ ok: true, deleted: target.id, filesRemoved: files });
  }),
);

/* ------------------------------------------------------------------ */
/* jobs                                                                */
/* ------------------------------------------------------------------ */
adminRoutes.get("/jobs", (req, res) => {
  const { status, q } = req.query;
  const list = data().jobs.filter(
    (j) =>
      (!status || j.status === status) &&
      matches(q, j.id, j.imageName ?? "", owner(j.ownerId)?.email ?? "", owner(j.ownerId)?.name ?? ""),
  );
  const page = paginate(list, req.query);
  res.set("cache-control", "no-store");
  res.json({ ...page, items: page.items.map(adminJob), queue: queueStats() });
});

adminRoutes.get(
  "/jobs/:jobId/result.png",
  asyncHandler(async (req, res) => {
    const job = find("jobs", (j) => j.id === req.params.jobId);
    if (!job?.file) throw notFound("No render for that job.");
    const png = await fsp.readFile(path.join(RENDER_DIR, job.file)).catch(() => {
      throw notFound("Render has been swept from disk.");
    });
    res.type("image/png").set("cache-control", "private, max-age=300").send(png);
  }),
);

adminRoutes.post(
  "/jobs/:jobId/retry",
  asyncHandler(async (req, res) => {
    const prev = find("jobs", (j) => j.id === req.params.jobId);
    if (!prev) throw notFound("No such job.");
    const image = find("images", (i) => i.id === prev.imageId);
    if (!image) throw badRequest("The source image for that job no longer exists.");

    const body = validate(req.body, { sensitivity: { type: "int", min: 8, max: 95 } });
    const job = insert("jobs", {
      id: id("job"),
      ownerId: prev.ownerId,
      imageId: image.id,
      imageName: image.name,
      status: "queued",
      progress: 0,
      stage: "Queued",
      sensitivity: body.sensitivity ?? prev.sensitivity,
      maxEdge: prev.maxEdge,
      retryOf: prev.id,
      createdAt: now(),
      updatedAt: now(),
    });
    enqueue(job, image);
    logger.info(`admin re-queued ${prev.id} as ${job.id}`);
    res.status(202).json({ job: adminJob(find("jobs", (j) => j.id === job.id)) });
  }),
);

adminRoutes.delete(
  "/jobs/:jobId",
  asyncHandler(async (req, res) => {
    const job = find("jobs", (j) => j.id === req.params.jobId);
    if (!job) throw notFound("No such job.");
    if (job.file) await fsp.unlink(path.join(RENDER_DIR, job.file)).catch(() => {});
    remove("exports", (e) => e.jobId === job.id);
    remove("jobs", (j) => j.id === job.id);
    res.json({ ok: true, deleted: job.id });
  }),
);

/* ------------------------------------------------------------------ */
/* images + exports                                                    */
/* ------------------------------------------------------------------ */
adminRoutes.get("/images", (req, res) => {
  const list = data().images.filter((i) => matches(req.query.q, i.name, i.id, owner(i.ownerId)?.email ?? ""));
  const page = paginate(list, req.query);
  res.json({
    ...page,
    items: page.items.map((i) => ({
      id: i.id,
      name: i.name,
      mimeType: i.mimeType,
      format: i.format,
      bytes: i.bytes,
      createdAt: i.createdAt,
      expiresAt: i.expiresAt,
      owner: owner(i.ownerId),
      jobs: filter("jobs", (j) => j.imageId === i.id).length,
      fileUrl: `/api/v1/admin/images/${i.id}/file`,
    })),
  });
});

adminRoutes.get(
  "/images/:imageId/file",
  asyncHandler(async (req, res) => {
    const img = find("images", (i) => i.id === req.params.imageId);
    if (!img) throw notFound("No such image.");
    const buf = await fsp.readFile(path.join(UPLOAD_DIR, img.file)).catch(() => {
      throw notFound("Source has been swept from disk.");
    });
    res.type(img.mimeType).set("cache-control", "private, max-age=300").send(buf);
  }),
);

adminRoutes.delete(
  "/images/:imageId",
  asyncHandler(async (req, res) => {
    const img = find("images", (i) => i.id === req.params.imageId);
    if (!img) throw notFound("No such image.");
    await fsp.unlink(path.join(UPLOAD_DIR, img.file)).catch(() => {});
    remove("images", (i) => i.id === img.id);
    res.json({ ok: true, deleted: img.id });
  }),
);

adminRoutes.get("/exports", (req, res) => {
  const page = paginate(data().exports, req.query);
  res.json({
    ...page,
    items: page.items.map((e) => ({
      ...e,
      owner: owner(e.ownerId),
      job: (() => {
        const j = find("jobs", (x) => x.id === e.jobId);
        return j ? { id: j.id, imageName: j.imageName, width: j.width, height: j.height } : null;
      })(),
    })),
  });
});

/* ------------------------------------------------------------------ */
/* inbox                                                               */
/* ------------------------------------------------------------------ */
adminRoutes.get("/messages", (req, res) => {
  const { status, q } = req.query;
  const list = data().messages.filter(
    (m) => (!status || m.status === status) && matches(q, m.name, m.email, m.message, m.topic),
  );
  const page = paginate(list, req.query);
  res.json({ ...page, byStatus: countBy(data().messages, (m) => m.status) });
});

adminRoutes.patch(
  "/messages/:messageId",
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      status: { type: "enum", values: ["received", "read", "resolved"], required: true },
    });
    const msg = update("messages", (m) => m.id === req.params.messageId, {
      status: body.status,
      handledBy: req.actor.user.email,
    });
    if (!msg) throw notFound("No such message.");
    res.json({ message: msg });
  }),
);

adminRoutes.delete("/messages/:messageId", (req, res) => {
  const n = remove("messages", (m) => m.id === req.params.messageId);
  if (!n) throw notFound("No such message.");
  res.json({ ok: true, deleted: req.params.messageId });
});

/* ------------------------------------------------------------------ */
/* system                                                              */
/* ------------------------------------------------------------------ */
adminRoutes.get(
  "/system",
  asyncHandler(async (_req, res) => {
    const [uploads, renders] = await Promise.all([dirStats(UPLOAD_DIR), dirStats(RENDER_DIR)]);
    const mem = process.memoryUsage();
    res.set("cache-control", "no-store");
    res.json({
      settings: data().settings,
      queue: queueStats(),
      runtime: {
        node: process.version,
        platform: `${os.platform()} ${os.arch()}`,
        env: config.env,
        pid: process.pid,
        uptimeSeconds: Math.round((Date.now() - bootedAt) / 1000),
        rssBytes: mem.rss,
        heapUsedBytes: mem.heapUsed,
        heapTotalBytes: mem.heapTotal,
        cpus: os.cpus()?.length ?? 1,
        loadAvg: os.loadavg().map((n) => Number(n.toFixed(2))),
        freeMemBytes: os.freemem(),
        totalMemBytes: os.totalmem(),
      },
      config: {
        port: config.port,
        dataDir: config.dataDir,
        maxUploadBytes: config.uploads.maxBytes,
        maxEdge: config.uploads.maxEdge,
        assetTtlMs: config.uploads.ttlMs,
        tokenTtlSeconds: config.tokenTtlSeconds,
        corsOrigins: config.cors.origins,
        rateLimit: config.rateLimit,
        secretConfigured: Boolean(process.env.CLEARPIX_SECRET),
        adminEmail: ADMIN_EMAIL,
        defaultAdminPassword: usingDefaultAdminPassword,
      },
      capabilities: config.capabilities,
      storage: { uploads, renders, bytes: uploads.bytes + renders.bytes },
      logs: recentLogs(120),
    });
  }),
);

adminRoutes.get("/logs", (req, res) => {
  const limit = Math.min(400, Number(req.query.limit) || 200);
  const level = typeof req.query.level === "string" ? req.query.level : undefined;
  res.set("cache-control", "no-store");
  res.json({ logs: recentLogs(limit, level) });
});

adminRoutes.patch(
  "/system/settings",
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      acceptingJobs: { type: "bool" },
      maintenanceMessage: { type: "string", max: 240 },
    });
    const db = data();
    db.settings = {
      ...db.settings,
      ...(body.acceptingJobs !== undefined ? { acceptingJobs: body.acceptingJobs } : {}),
      ...(body.maintenanceMessage !== undefined ? { maintenanceMessage: body.maintenanceMessage } : {}),
      updatedAt: now(),
      updatedBy: req.actor.user.email,
    };
    persist();
    logger.warn(
      `admin ${req.actor.user.email} set processing ${db.settings.acceptingJobs ? "ON" : "PAUSED"}`,
    );
    res.json({ settings: db.settings });
  }),
);

adminRoutes.post(
  "/system/sweep",
  asyncHandler(async (req, res) => {
    const removed = await sweepExpiredAssets();
    logger.info(`admin ${req.actor.user.email} ran housekeeping — ${removed} file(s) removed`);
    res.json({ ok: true, removed });
  }),
);

adminRoutes.post(
  "/system/purge-guests",
  asyncHandler(async (req, res) => {
    const idle = Date.now() - 24 * 3600e3;
    const victims = data().users.filter(
      (u) => u.kind === "guest" && Date.parse(u.updatedAt ?? u.createdAt) < idle,
    );
    const ids = new Set(victims.map((v) => v.id));
    let files = 0;
    for (const img of filter("images", (i) => ids.has(i.ownerId))) {
      await fsp.unlink(path.join(UPLOAD_DIR, img.file)).then(() => files++).catch(() => {});
    }
    for (const job of filter("jobs", (j) => ids.has(j.ownerId))) {
      if (job.file) await fsp.unlink(path.join(RENDER_DIR, job.file)).then(() => files++).catch(() => {});
    }
    remove("images", (i) => ids.has(i.ownerId));
    remove("jobs", (j) => ids.has(j.ownerId));
    remove("exports", (e) => ids.has(e.ownerId));
    remove("users", (u) => ids.has(u.id));
    logger.warn(`admin ${req.actor.user.email} purged ${ids.size} idle guest session(s)`);
    res.json({ ok: true, removedSessions: ids.size, filesRemoved: files });
  }),
);
