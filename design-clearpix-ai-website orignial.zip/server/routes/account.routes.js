import { Router } from "express";
import { config, planById } from "../config.js";
import { publicUser } from "../lib/auth.js";
import { asyncHandler } from "../lib/errors.js";
import { filter, update } from "../lib/store.js";
import { validate } from "../lib/validate.js";
import { rateLimit } from "../middleware/rateLimit.js";

export const planRoutes = Router();
export const accountRoutes = Router();

/** GET /api/v1/plans — the demo catalogue */
planRoutes.get("/", (_req, res) => {
  res.json({
    plans: config.plans,
    notice:
      "Pricing is illustrative. This prototype has no payment processor, no checkout and no active subscriptions.",
  });
});

/** GET /api/v1/account — session, plan and usage snapshot */
accountRoutes.get("/", (req, res) => {
  const jobs = filter("jobs", (j) => j.ownerId === req.actor.id);
  const exports = filter("exports", (e) => e.ownerId === req.actor.id);
  const images = filter("images", (i) => i.ownerId === req.actor.id);

  res.json({
    session: { kind: req.actor.kind, id: req.actor.id },
    user: publicUser(req.actor.user),
    plan: req.actor.plan,
    usage: {
      images: images.length,
      jobs: jobs.length,
      succeeded: jobs.filter((j) => j.status === "succeeded").length,
      failed: jobs.filter((j) => j.status === "failed").length,
      exports: exports.length,
      creditsRemaining: req.actor.user.credits,
      creditsIncluded: req.actor.plan.exportCredits,
    },
  });
});

/** POST /api/v1/account/plan — switch tier (demo only, nothing is charged) */
accountRoutes.post(
  "/plan",
  rateLimit("account", config.rateLimit.write),
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      planId: { type: "enum", values: config.plans.map((p) => p.id), required: true },
    });
    const plan = planById(body.planId);
    const user = update("users", (u) => u.id === req.actor.id, {
      plan: plan.id,
      credits: plan.exportCredits,
    });
    res.json({
      user: publicUser(user),
      plan,
      notice: "Plan switched locally for demonstration. No payment was requested or taken.",
    });
  }),
);

/** POST /api/v1/account/credits/reset — refill the demo allowance */
accountRoutes.post(
  "/credits/reset",
  rateLimit("account", config.rateLimit.write),
  asyncHandler(async (req, res) => {
    const user = update("users", (u) => u.id === req.actor.id, {
      credits: req.actor.plan.exportCredits,
    });
    res.json({ credits: user.credits, plan: req.actor.plan.id });
  }),
);
