import { Router } from "express";
import { planById } from "../config.js";
import { hashPassword, issueGuestToken, issueToken, publicUser, verifyPassword } from "../lib/auth.js";
import { asyncHandler, conflict, unauthorized } from "../lib/errors.js";
import { find, id, insert, now, update } from "../lib/store.js";
import { validate } from "../lib/validate.js";
import { rateLimit } from "../middleware/rateLimit.js";
import { config } from "../config.js";

export const authRoutes = Router();

const limiter = rateLimit("auth", config.rateLimit.auth);

/** POST /api/v1/auth/register */
authRoutes.post(
  "/register",
  limiter,
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      name: { type: "string", required: true, min: 2, max: 60 },
      email: { type: "email", required: true },
      password: { type: "string", required: true, min: 8, max: 128 },
      plan: { type: "enum", values: ["free", "pro", "business"], default: "free" },
    });

    if (find("users", (u) => u.email === body.email)) {
      throw conflict("An account with that email already exists.");
    }

    const plan = planById(body.plan);
    const user = insert("users", {
      id: id("usr"),
      kind: "user",
      role: "member",
      status: "active",
      name: body.name,
      email: body.email,
      passwordHash: hashPassword(body.password),
      plan: plan.id,
      credits: plan.exportCredits,
      createdAt: now(),
      updatedAt: now(),
    });

    res.status(201).json({
      token: issueToken({ sub: user.id, kind: "user" }),
      user: publicUser(user),
      plan,
      notice:
        "Demo account created in a local JSON store. No billing is attached to any plan in this prototype.",
    });
  }),
);

/** POST /api/v1/auth/login */
authRoutes.post(
  "/login",
  limiter,
  asyncHandler(async (req, res) => {
    const body = validate(req.body, {
      email: { type: "email", required: true },
      password: { type: "string", required: true, min: 1 },
    });

    const user = find("users", (u) => u.email === body.email && u.kind === "user");
    if (!user || !verifyPassword(body.password, user.passwordHash)) {
      throw unauthorized("Those credentials did not match an account.");
    }
    if (user.status === "suspended") {
      throw unauthorized("This account has been suspended by an administrator.");
    }

    update("users", (u) => u.id === user.id, { lastLoginAt: now() });

    res.json({
      token: issueToken({ sub: user.id, kind: "user" }),
      user: publicUser(user),
      plan: planById(user.plan),
    });
  }),
);

/** POST /api/v1/auth/guest — explicit anonymous session */
authRoutes.post("/guest", (req, res) => {
  res.status(201).json({
    token: req.actor.token ?? issueGuestToken(req.actor.id),
    user: publicUser(req.actor.user),
    plan: req.actor.plan,
  });
});

/** GET /api/v1/auth/me */
authRoutes.get("/me", (req, res) => {
  res.json({
    authenticated: req.actor.kind === "user",
    kind: req.actor.kind,
    user: publicUser(req.actor.user),
    plan: req.actor.plan,
  });
});

/** POST /api/v1/auth/logout — tokens are stateless, so this is an acknowledgement */
authRoutes.post("/logout", (_req, res) => {
  res.json({ ok: true, message: "Token discarded client-side. Stateless sessions expire on their own." });
});
