import { Router } from "express";
import { config } from "../config.js";
import { identify } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rateLimit.js";
import { accountRoutes, planRoutes } from "./account.routes.js";
import { adminRoutes } from "./admin.routes.js";
import { authRoutes } from "./auth.routes.js";
import { imageRoutes } from "./images.routes.js";
import { downloadRoutes, jobRoutes } from "./jobs.routes.js";
import { contactRoutes, metaRoutes } from "./meta.routes.js";

export const api = Router();

/* Public, unauthenticated surface */
api.use(metaRoutes);

/* Everything below gets an identity (real user or signed guest) */
api.use(rateLimit("general", config.rateLimit.general));
api.use(identify);

api.use("/v1/auth", authRoutes);
api.use("/v1/images", imageRoutes);
api.use("/v1/jobs", jobRoutes);
api.use("/v1/downloads", downloadRoutes);
api.use("/v1/plans", planRoutes);
api.use("/v1/account", accountRoutes);
api.use("/v1/contact", contactRoutes);
api.use("/v1/admin", adminRoutes);
