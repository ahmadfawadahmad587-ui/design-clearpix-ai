import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import cors from "cors";
import express from "express";
import { config } from "./config.js";
import { requestLogger } from "./lib/logger.js";
import { errorHandler, notFoundHandler } from "./middleware/error.js";
import { api } from "./routes/index.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(__dirname, "..", "dist");

export function createApp() {
  const app = express();

  app.disable("x-powered-by");
  app.set("trust proxy", true);

  /* ---- security headers (hand-rolled; no helmet dependency) ---- */
  app.use((_req, res, next) => {
    res.set("x-content-type-options", "nosniff");
    res.set("referrer-policy", "strict-origin-when-cross-origin");
    res.set("x-frame-options", "SAMEORIGIN");
    res.set("cross-origin-resource-policy", "cross-origin");
    res.set("permissions-policy", "geolocation=(), microphone=(), camera=()");
    next();
  });

  app.use(
    cors({
      origin: config.cors.origins.includes("*") ? true : config.cors.origins,
      credentials: false,
      exposedHeaders: ["x-clearpix-session", "x-ratelimit-remaining", "retry-after"],
      maxAge: 86400,
    }),
  );

  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: false, limit: "1mb" }));
  app.use(requestLogger);

  /* ---- REST API ---- */
  app.use("/api", api);

  /* ---- Serve the built front-end when it exists ---- */
  if (fs.existsSync(path.join(DIST, "index.html"))) {
    app.use(express.static(DIST, { index: false, maxAge: "1h" }));
    app.get(/^\/(?!api\/).*/, (_req, res) => res.sendFile(path.join(DIST, "index.html")));
  } else {
    app.get("/", (_req, res) =>
      res.json({
        service: "clearpix-api",
        message: 'Run "npm run build" to have this server also host the front-end.',
        api: "/api/v1",
        health: "/api/health",
      }),
    );
  }

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
