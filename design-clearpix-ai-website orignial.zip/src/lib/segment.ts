/**
 * CLEARPIX AI — Demo segmentation engine.
 *
 * IMPORTANT / HONEST NOTE:
 * This is NOT a neural network. It is a real, deterministic computer-vision
 * routine that runs 100% inside the browser:
 *
 *   1. estimate the dominant backdrop colour from the image border
 *   2. tolerance-based flood fill (magic-wand) from the border inwards,
 *      with gradient-following so soft studio backdrops are handled
 *   3. enclosed-hole recovery (gaps inside handles, straps, etc.)
 *   4. speckle clean-up on tiny disconnected islands
 *   5. edge-band feathering for anti-aliased, non-jagged cutouts
 *   6. colour decontamination so the old backdrop does not fringe the subject
 *
 * It produces excellent results on studio / product / portrait photography
 * with a reasonably even backdrop — which is exactly what the demo samples are.
 */

export interface CutoutResult {
  /** object URL for a real transparent PNG */
  url: string;
  width: number;
  height: number;
  /** 0 → 1, share of pixels kept as subject */
  coverage: number;
  backdrop: string;
  ms: number;
}

export interface SegmentOptions {
  /** longest edge of the processed output */
  maxSize?: number;
  /** 10 (conservative) → 90 (aggressive) */
  sensitivity?: number;
  onProgress?: (pct: number, stage: string) => void;
}

const nextFrame = () =>
  new Promise<void>((r) => {
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(() => r());
    else setTimeout(r, 0);
  });

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.decoding = "async";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not decode that image file."));
    img.src = src;
  });
}

function toHex(r: number, g: number, b: number) {
  return (
    "#" +
    [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("")
  );
}

/** Dominant colour of the outer frame, found with a coarse colour histogram. */
function estimateBackdrop(data: Uint8ClampedArray, w: number, h: number) {
  const ring = Math.max(2, Math.round(Math.min(w, h) * 0.012));
  const buckets = new Map<number, { n: number; r: number; g: number; b: number }>();

  const add = (i: number) => {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
    const e = buckets.get(key);
    if (e) { e.n++; e.r += r; e.g += g; e.b += b; }
    else buckets.set(key, { n: 1, r, g, b });
  };

  for (let y = 0; y < h; y++) {
    const edgeRow = y < ring || y >= h - ring;
    for (let x = 0; x < w; x++) {
      if (!edgeRow && x >= ring && x < w - ring) { x = w - ring - 1; continue; }
      add((y * w + x) * 4);
    }
  }

  let best = { n: 0, r: 255, g: 255, b: 255 };
  let total = 0;
  buckets.forEach((e) => { total += e.n; if (e.n > best.n) best = e; });

  return {
    r: best.r / best.n,
    g: best.g / best.n,
    b: best.b / best.n,
    /** how uniform the border is, 0 → 1 */
    purity: total ? best.n / total : 0,
  };
}

export async function removeBackground(
  image: HTMLImageElement,
  { maxSize = 1400, sensitivity = 52, onProgress }: SegmentOptions = {},
): Promise<CutoutResult> {
  const started = performance.now();
  const report = (p: number, s: string) => onProgress?.(p, s);

  report(6, "Reading pixels");
  const scale = Math.min(1, maxSize / Math.max(image.naturalWidth, image.naturalHeight));
  const w = Math.max(1, Math.round(image.naturalWidth * scale));
  const h = Math.max(1, Math.round(image.naturalHeight * scale));

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(image, 0, 0, w, h);

  const imageData = ctx.getImageData(0, 0, w, h);
  const data = imageData.data;
  const n = w * h;

  await nextFrame();
  report(18, "Profiling backdrop");
  const bg = estimateBackdrop(data, w, h);
  const bgR = bg.r, bgG = bg.g, bgB = bg.b;

  // Tolerances derived from the sensitivity slider.
  const s = Math.max(8, Math.min(95, sensitivity));
  const tIn = 10 + s * 0.62;                 // definitely backdrop
  const tOut = tIn * (bg.purity > 0.55 ? 2.5 : 2.0); // possibly backdrop
  const tIn2 = tIn * tIn;
  const tOut2 = tOut * tOut;
  const local = 7 + s * 0.16;                // gradient-following step
  const local2 = local * local;

  const d2bg = (i: number) => {
    const dr = data[i] - bgR, dg = data[i + 1] - bgG, db = data[i + 2] - bgB;
    return dr * dr + dg * dg + db * db;
  };

  await nextFrame();
  report(34, "Tracing subject outline");

  // ---- 1. flood fill from the border --------------------------------------
  const BG = 1, SEEN = 2;
  const state = new Uint8Array(n);
  const queue = new Int32Array(n);
  let qh = 0, qt = 0;

  const push = (p: number) => {
    if (state[p] & SEEN) return;
    if (d2bg(p * 4) > tIn2) return;
    state[p] = BG | SEEN;
    queue[qt++] = p;
  };

  for (let x = 0; x < w; x++) { push(x); push((h - 1) * w + x); }
  for (let y = 0; y < h; y++) { push(y * w); push(y * w + w - 1); }

  while (qh < qt) {
    const p = queue[qh++];
    const px = p % w, py = (p / w) | 0;
    const pi = p * 4;
    for (let k = 0; k < 4; k++) {
      const nx = px + (k === 0 ? -1 : k === 1 ? 1 : 0);
      const ny = py + (k === 2 ? -1 : k === 3 ? 1 : 0);
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
      const q = ny * w + nx;
      if (state[q] & SEEN) continue;
      const qi = q * 4;
      const dist = d2bg(qi);
      let ok = dist <= tIn2;
      if (!ok && dist <= tOut2) {
        const dr = data[qi] - data[pi], dg = data[qi + 1] - data[pi + 1], db = data[qi + 2] - data[pi + 2];
        ok = dr * dr + dg * dg + db * db <= local2;
      }
      if (!ok) continue;
      state[q] = BG | SEEN;
      queue[qt++] = q;
    }
  }

  await nextFrame();
  report(55, "Recovering enclosed gaps");

  // ---- 2. enclosed holes (handle gaps, between-arm space, …) ---------------
  const visited = new Uint8Array(n);
  const stack = new Int32Array(n);
  for (let p = 0; p < n; p++) {
    if (state[p] & BG || visited[p]) continue;
    if (d2bg(p * 4) > tIn2) continue;
    let sp = 0, count = 0, head = 0;
    stack[sp++] = p; visited[p] = 1;
    const members: number[] = [];
    while (sp > head) {
      const c = stack[head++];
      members.push(c); count++;
      const cx = c % w, cy = (c / w) | 0;
      for (let k = 0; k < 4; k++) {
        const nx = cx + (k === 0 ? -1 : k === 1 ? 1 : 0);
        const ny = cy + (k === 2 ? -1 : k === 3 ? 1 : 0);
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
        const q = ny * w + nx;
        if (visited[q] || state[q] & BG) continue;
        if (d2bg(q * 4) > tIn2) continue;
        visited[q] = 1; stack[sp++] = q;
      }
    }
    if (count > Math.max(48, n * 0.00008)) for (const m of members) state[m] |= BG;
  }

  await nextFrame();
  report(70, "Removing speckles");

  // ---- 3. drop tiny disconnected subject islands ---------------------------
  visited.fill(0);
  const minIsland = Math.max(60, Math.round(n * 0.0004));
  for (let p = 0; p < n; p++) {
    if (state[p] & BG || visited[p]) continue;
    let sp = 0, head = 0, count = 0;
    stack[sp++] = p; visited[p] = 1;
    const members: number[] = [];
    while (sp > head) {
      const c = stack[head++];
      members.push(c); count++;
      if (count > minIsland) break;
      const cx = c % w, cy = (c / w) | 0;
      for (let k = 0; k < 4; k++) {
        const nx = cx + (k === 0 ? -1 : k === 1 ? 1 : 0);
        const ny = cy + (k === 2 ? -1 : k === 3 ? 1 : 0);
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
        const q = ny * w + nx;
        if (visited[q] || state[q] & BG) continue;
        visited[q] = 1; stack[sp++] = q;
      }
    }
    if (count <= minIsland) for (const m of members) state[m] |= BG;
  }

  await nextFrame();
  report(82, "Feathering edges");

  // ---- 4. alpha matte with a soft edge band --------------------------------
  const alpha = new Float32Array(n);
  for (let p = 0; p < n; p++) alpha[p] = state[p] & BG ? 0 : 1;

  // band = subject pixels within R px of the backdrop region
  const R = Math.max(1, Math.round(Math.min(w, h) / 700) + 1);
  const band = new Uint8Array(n);
  let frontier: number[] = [];
  for (let p = 0; p < n; p++) {
    if (alpha[p] === 0) continue;
    const px = p % w, py = (p / w) | 0;
    if (
      (px > 0 && alpha[p - 1] === 0) || (px < w - 1 && alpha[p + 1] === 0) ||
      (py > 0 && alpha[p - w] === 0) || (py < h - 1 && alpha[p + w] === 0)
    ) { band[p] = 1; frontier.push(p); }
  }
  for (let r = 1; r < R; r++) {
    const next: number[] = [];
    for (const p of frontier) {
      const px = p % w, py = (p / w) | 0;
      for (let k = 0; k < 4; k++) {
        const nx = px + (k === 0 ? -1 : k === 1 ? 1 : 0);
        const ny = py + (k === 2 ? -1 : k === 3 ? 1 : 0);
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
        const q = ny * w + nx;
        if (band[q] || alpha[q] === 0) continue;
        band[q] = 1; next.push(q);
      }
    }
    frontier = next;
  }

  const spanIn = Math.sqrt(tIn2) * 0.55;
  const spanOut = Math.sqrt(tOut2) * 0.95;
  for (let p = 0; p < n; p++) {
    if (!band[p]) continue;
    const d = Math.sqrt(d2bg(p * 4));
    const t = (d - spanIn) / Math.max(1, spanOut - spanIn);
    alpha[p] = Math.max(0, Math.min(1, t));
  }

  // 3×3 smoothing on the band only → clean anti-aliased silhouette
  const smooth = Float32Array.from(alpha);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const p = y * w + x;
      // never let the blur bleed outside the silhouette (that would re-introduce
      // a halo of old backdrop colour), and skip the solid interior entirely
      if (alpha[p] === 0) continue;
      if (!band[p] && alpha[p] === 1) continue;
      let sum = 0;
      sum += alpha[p - w - 1] + alpha[p - w] + alpha[p - w + 1];
      sum += alpha[p - 1] + alpha[p] + alpha[p + 1];
      sum += alpha[p + w - 1] + alpha[p + w] + alpha[p + w + 1];
      smooth[p] = sum / 9;
    }
  }

  await nextFrame();
  report(92, "Decontaminating colour");

  // ---- 5. write out, un-spilling the old backdrop colour -------------------
  let kept = 0;
  for (let p = 0; p < n; p++) {
    let a = smooth[p];
    if (a <= 0.004) {
      data[p * 4 + 3] = 0;
      continue;
    }
    if (a > 0.996) a = 1;
    const i = p * 4;
    if (a < 0.985) {
      // c = (observed − (1−a)·backdrop) / a
      data[i] = Math.max(0, Math.min(255, (data[i] - (1 - a) * bgR) / a));
      data[i + 1] = Math.max(0, Math.min(255, (data[i + 1] - (1 - a) * bgG) / a));
      data[i + 2] = Math.max(0, Math.min(255, (data[i + 2] - (1 - a) * bgB) / a));
    }
    data[i + 3] = Math.round(a * 255);
    kept += a;
  }

  ctx.putImageData(imageData, 0, 0);

  const url: string = await new Promise((resolve) => {
    canvas.toBlob((blob) => {
      resolve(blob ? URL.createObjectURL(blob) : canvas.toDataURL("image/png"));
    }, "image/png");
  });

  report(100, "Done");
  return {
    url,
    width: w,
    height: h,
    coverage: kept / n,
    backdrop: toHex(bgR, bgG, bgB),
    ms: Math.round(performance.now() - started),
  };
}

/* ------------------------------------------------------------------ */
/* Small cache so the marketing galleries only ever process once.      */
/* ------------------------------------------------------------------ */
const cache = new Map<string, Promise<CutoutResult>>();

export function getCutout(src: string, maxSize = 900, sensitivity = 52) {
  const key = `${src}|${maxSize}|${sensitivity}`;
  if (!cache.has(key)) {
    cache.set(
      key,
      loadImage(src).then((img) => removeBackground(img, { maxSize, sensitivity })),
    );
  }
  return cache.get(key)!;
}

/** Flatten a transparent PNG onto a solid colour (used by the backdrop previews). */
export async function compositeOnColor(url: string, color: string): Promise<string> {
  const img = await loadImage(url);
  const c = document.createElement("canvas");
  c.width = img.naturalWidth;
  c.height = img.naturalHeight;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(img, 0, 0);
  return new Promise((resolve) => {
    c.toBlob((b) => resolve(b ? URL.createObjectURL(b) : c.toDataURL("image/png")), "image/png");
  });
}
