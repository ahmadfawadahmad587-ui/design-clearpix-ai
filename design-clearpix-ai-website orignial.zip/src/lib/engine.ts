/**
 * Engine façade.
 *
 * One API for the workspace, two possible execution paths:
 *
 *   • "server" — the CLEARPIX REST API is reachable, so the image is uploaded,
 *     a job is queued, progress is polled and the render is streamed back.
 *   • "local"  — no backend, so the identical matting pipeline runs in the tab.
 *
 * The result shape is the same either way, and the UI always says which path
 * produced the cutout.
 */

import { api, ApiError, apiBase, type HealthInfo } from "./api";
import { compositeOnColor, loadImage, removeBackground } from "./segment";

export type EngineMode = "server" | "local";

export interface EngineResult {
  mode: EngineMode;
  url: string;
  width: number;
  height: number;
  coverage: number;
  backdrop: string;
  ms: number;
  jobId?: string;
}

export interface EngineInput {
  src: string;
  name: string;
  file?: File | null;
}

export interface RunOptions {
  sensitivity: number;
  onProgress?: (pct: number, stage: string) => void;
}

/* ------------------------------------------------------------------ */
/* Backend discovery                                                   */
/* ------------------------------------------------------------------ */
let healthPromise: Promise<HealthInfo | null> | null = null;
let health: HealthInfo | null = null;

export function detectBackend(force = false): Promise<HealthInfo | null> {
  if (force) healthPromise = null;
  if (!healthPromise) {
    healthPromise = api
      .health()
      .then((info) => {
        health = info;
        return info;
      })
      .catch(() => {
        health = null;
        return null;
      });
  }
  return healthPromise;
}

export const backendInfo = () => health;
export const backendBase = apiBase;

/** The server cannot decode WEBP; those files always use the local engine. */
const serverCanDecode = (type: string) =>
  !!health?.capabilities.decode.includes(type === "image/jpg" ? "image/jpeg" : type);

async function asFile(input: EngineInput): Promise<File> {
  if (input.file) return input.file;
  const res = await fetch(input.src);
  const blob = await res.blob();
  return new File([blob], input.name, { type: blob.type || "image/jpeg" });
}

/* ------------------------------------------------------------------ */
/* Run                                                                 */
/* ------------------------------------------------------------------ */
export async function runCutout(input: EngineInput, opts: RunOptions): Promise<EngineResult> {
  const info = await detectBackend();

  if (info) {
    try {
      const file = await asFile(input);
      if (serverCanDecode(file.type)) return await runOnServer(file, opts);
    } catch (err) {
      // Fall through to the local engine, but keep credit errors visible.
      if (err instanceof ApiError && err.code === "credits_exhausted") throw err;
    }
  }
  return runLocally(input, opts);
}

async function runOnServer(file: File, { sensitivity, onProgress }: RunOptions): Promise<EngineResult> {
  const started = performance.now();
  onProgress?.(4, "Uploading to API");

  const { image } = await api.uploadImage(file);
  onProgress?.(10, "Queued");

  const { job } = await api.createJob(image.id, sensitivity);

  let current = job;
  const deadline = Date.now() + 90_000;
  while (current.status === "queued" || current.status === "processing") {
    if (Date.now() > deadline) throw new ApiError(504, "timeout", "The job took too long.");
    await new Promise((r) => setTimeout(r, 420));
    current = (await api.getJob(current.id)).job;
    onProgress?.(
      Math.max(10, current.progress),
      current.status === "queued"
        ? `Queued (position ${current.queuePosition})`
        : (current.stage ?? "Working"),
    );
  }

  if (current.status === "failed") {
    throw new ApiError(500, current.error?.code ?? "engine_failed", current.error?.message ?? "Job failed.");
  }

  onProgress?.(97, "Downloading render");
  const blob = await api.result(current.id);
  onProgress?.(100, "Done");

  return {
    mode: "server",
    url: URL.createObjectURL(blob),
    width: current.width ?? 0,
    height: current.height ?? 0,
    coverage: current.coverage ?? 0,
    backdrop: current.backdrop ?? "#FFFFFF",
    ms: current.engineMs ?? Math.round(performance.now() - started),
    jobId: current.id,
  };
}

async function runLocally(input: EngineInput, { sensitivity, onProgress }: RunOptions): Promise<EngineResult> {
  const img = await loadImage(input.src);
  const res = await removeBackground(img, { maxSize: 1500, sensitivity, onProgress });
  return { mode: "local", ...res };
}

/* ------------------------------------------------------------------ */
/* Export                                                              */
/* ------------------------------------------------------------------ */
export interface ExportOutcome {
  mode: EngineMode;
  blobUrl: string;
  filename: string;
  revoke: boolean;
  creditsRemaining?: number;
}

export async function exportCutout(
  result: EngineResult,
  backdrop: string | null,
  baseName: string,
): Promise<ExportOutcome> {
  const filename = `clearpix-${baseName.replace(/\.[^.]+$/, "") || "image"}-cutout.png`;

  if (result.mode === "server" && result.jobId) {
    const { export: record, creditsRemaining } = await api.exportJob(result.jobId, backdrop, filename);
    const blob = await api.download(record.downloadUrl);
    return {
      mode: "server",
      blobUrl: URL.createObjectURL(blob),
      filename: record.filename,
      revoke: true,
      creditsRemaining,
    };
  }

  if (backdrop) {
    return { mode: "local", blobUrl: await compositeOnColor(result.url, backdrop), filename, revoke: true };
  }
  return { mode: "local", blobUrl: result.url, filename, revoke: false };
}

/** Triggers the browser download for an export outcome. */
export function saveFile({ blobUrl, filename, revoke }: ExportOutcome) {
  const a = document.createElement("a");
  a.href = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  if (revoke) setTimeout(() => URL.revokeObjectURL(blobUrl), 10_000);
}
