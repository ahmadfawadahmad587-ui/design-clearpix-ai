/**
 * Admin console client — every call here requires a token whose user carries
 * the "admin" role. Backed by /server/routes/admin.routes.js.
 */
import { apiBase, type UserInfo } from "./api";

const TOKEN_KEY = "clearpix.token";
const token = () => {
  try {
    return localStorage.getItem(TOKEN_KEY) ?? "";
  } catch {
    return "";
  }
};

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */
export interface Owner {
  id: string;
  name: string;
  email: string | null;
  kind: "user" | "guest";
  plan: string;
}

export interface AdminJob {
  id: string;
  status: "queued" | "processing" | "succeeded" | "failed";
  progress: number;
  stage: string | null;
  imageId: string;
  imageName: string | null;
  sensitivity: number;
  width: number | null;
  height: number | null;
  coverage: number | null;
  backdrop: string | null;
  engineMs: number | null;
  bytes: number | null;
  error: { code: string; message: string } | null;
  createdAt: string;
  finishedAt: string | null;
  owner: Owner | null;
  resultUrl: string | null;
  sourceUrl: string;
}

export interface AdminUser extends UserInfo {
  usage: { images: number; jobs: number; succeeded: number; exports: number };
}

export interface AdminImage {
  id: string;
  name: string;
  mimeType: string;
  format: string;
  bytes: number;
  createdAt: string;
  expiresAt: string;
  owner: Owner | null;
  jobs: number;
  fileUrl: string;
}

export interface AdminExport {
  id: string;
  jobId: string;
  filename: string;
  backdrop: string | null;
  downloads: number;
  createdAt: string;
  owner: Owner | null;
  job: { id: string; imageName: string | null; width: number | null; height: number | null } | null;
}

export interface AdminMessage {
  id: string;
  name: string;
  email: string;
  topic: string;
  message: string;
  status: "received" | "read" | "resolved";
  createdAt: string;
  handledBy?: string;
}

export interface Settings {
  acceptingJobs: boolean;
  maintenanceMessage: string;
  updatedAt: string | null;
  updatedBy?: string;
}

export interface QueueInfo {
  concurrency: number;
  queued: number;
  active: number;
  stages: string[];
}

export interface LogLine {
  ts: string;
  level: "info" | "ok" | "warn" | "error" | "http";
  msg: string;
}

export interface Overview {
  generatedAt: string;
  counters: { imagesProcessed: number; pixelsCut: number; exports: number };
  totals: {
    users: number;
    members: number;
    guests: number;
    admins: number;
    suspended: number;
    images: number;
    jobs: number;
    jobs24h: number;
    exports: number;
    exports24h: number;
    messages: number;
    unreadMessages: number;
  };
  jobs: {
    byStatus: Record<string, number>;
    successRate: number | null;
    avgEngineMs: number | null;
    avgCoverage: number | null;
    series: { hour: string; jobs: number; failed: number; exports: number }[];
  };
  plans: Record<string, number>;
  queue: QueueInfo;
  settings: Settings;
  storage: { uploads: { files: number; bytes: number }; renders: { files: number; bytes: number }; bytes: number };
  system: {
    node: string;
    env: string;
    uptimeSeconds: number;
    rssBytes: number;
    heapUsedBytes: number;
    cpus: number;
    loadAvg: number[];
  };
  recentJobs: AdminJob[];
  recentMessages: AdminMessage[];
}

export interface SystemInfo {
  settings: Settings;
  queue: QueueInfo;
  runtime: {
    node: string;
    platform: string;
    env: string;
    pid: number;
    uptimeSeconds: number;
    rssBytes: number;
    heapUsedBytes: number;
    heapTotalBytes: number;
    cpus: number;
    loadAvg: number[];
    freeMemBytes: number;
    totalMemBytes: number;
  };
  config: {
    port: number;
    dataDir: string;
    maxUploadBytes: number;
    maxEdge: number;
    assetTtlMs: number;
    tokenTtlSeconds: number;
    corsOrigins: string[];
    rateLimit: Record<string, number>;
    secretConfigured: boolean;
    adminEmail: string;
    defaultAdminPassword: boolean;
  };
  capabilities: { engine: string; neuralNetwork: boolean; note: string };
  storage: { uploads: { files: number; bytes: number }; renders: { files: number; bytes: number }; bytes: number };
  logs: LogLine[];
}

export interface Page<T> {
  items: T[];
  page: number;
  limit: number;
  total: number;
  pages: number;
}

export class AdminApiError extends Error {
  status: number;
  code: string;
  details?: unknown;
  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/* ------------------------------------------------------------------ */
/* Request                                                             */
/* ------------------------------------------------------------------ */
async function call<T>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = { accept: "application/json" };
  const t = token();
  if (t) headers.authorization = `Bearer ${t}`;
  if (init.body !== undefined) headers["content-type"] = "application/json";

  let res: Response;
  try {
    res = await fetch(`${apiBase}${path}`, {
      method: init.method ?? "GET",
      headers,
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
    });
  } catch {
    throw new AdminApiError(0, "network_unreachable", "Could not reach the CLEARPIX API.");
  }
  const text = await res.text();
  let json: unknown = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {};
  }
  if (!res.ok) {
    const e = (json as { error?: { code: string; message: string; details?: unknown } }).error;
    throw new AdminApiError(res.status, e?.code ?? "request_failed", e?.message ?? res.statusText, e?.details);
  }
  return json as T;
}

const qs = (params: Record<string, string | number | undefined>) => {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== "") sp.set(k, String(v));
  const s = sp.toString();
  return s ? `?${s}` : "";
};

/** Absolute, token-bearing URL for <img src> usage. */
export const assetUrl = (relative: string | null | undefined) =>
  relative ? `${apiBase}${relative}${relative.includes("?") ? "&" : "?"}token=${encodeURIComponent(token())}` : "";

export const adminApi = {
  overview: () => call<Overview>("/api/v1/admin/overview"),

  users: (p: { q?: string; kind?: string; plan?: string; status?: string; page?: number; limit?: number }) =>
    call<Page<AdminUser>>(`/api/v1/admin/users${qs(p)}`),
  updateUser: (id: string, patch: Partial<Pick<AdminUser, "plan" | "credits" | "role" | "status" | "name">> & { addCredits?: number }) =>
    call<{ user: AdminUser }>(`/api/v1/admin/users/${id}`, { method: "PATCH", body: patch }),
  deleteUser: (id: string) => call<{ ok: boolean }>(`/api/v1/admin/users/${id}`, { method: "DELETE" }),

  jobs: (p: { status?: string; q?: string; page?: number; limit?: number }) =>
    call<Page<AdminJob> & { queue: QueueInfo }>(`/api/v1/admin/jobs${qs(p)}`),
  retryJob: (id: string, sensitivity?: number) =>
    call<{ job: AdminJob }>(`/api/v1/admin/jobs/${id}/retry`, { method: "POST", body: { sensitivity } }),
  deleteJob: (id: string) => call<{ ok: boolean }>(`/api/v1/admin/jobs/${id}`, { method: "DELETE" }),

  images: (p: { q?: string; page?: number; limit?: number }) => call<Page<AdminImage>>(`/api/v1/admin/images${qs(p)}`),
  deleteImage: (id: string) => call<{ ok: boolean }>(`/api/v1/admin/images/${id}`, { method: "DELETE" }),
  exports: (p: { page?: number; limit?: number }) => call<Page<AdminExport>>(`/api/v1/admin/exports${qs(p)}`),

  messages: (p: { status?: string; q?: string; page?: number; limit?: number }) =>
    call<Page<AdminMessage> & { byStatus: Record<string, number> }>(`/api/v1/admin/messages${qs(p)}`),
  updateMessage: (id: string, status: AdminMessage["status"]) =>
    call<{ message: AdminMessage }>(`/api/v1/admin/messages/${id}`, { method: "PATCH", body: { status } }),
  deleteMessage: (id: string) => call<{ ok: boolean }>(`/api/v1/admin/messages/${id}`, { method: "DELETE" }),

  system: () => call<SystemInfo>("/api/v1/admin/system"),
  logs: (limit = 200, level?: string) => call<{ logs: LogLine[] }>(`/api/v1/admin/logs${qs({ limit, level })}`),
  updateSettings: (patch: Partial<Pick<Settings, "acceptingJobs" | "maintenanceMessage">>) =>
    call<{ settings: Settings }>("/api/v1/admin/system/settings", { method: "PATCH", body: patch }),
  sweep: () => call<{ ok: boolean; removed: number }>("/api/v1/admin/system/sweep", { method: "POST" }),
  purgeGuests: () =>
    call<{ ok: boolean; removedSessions: number; filesRemoved: number }>("/api/v1/admin/system/purge-guests", {
      method: "POST",
    }),
};

/* ------------------------------------------------------------------ */
/* Formatters shared by the console                                    */
/* ------------------------------------------------------------------ */
export const fmtBytes = (b: number | null | undefined) => {
  if (!b) return "0 B";
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(0)} KB`;
  if (b < 1073741824) return `${(b / 1048576).toFixed(1)} MB`;
  return `${(b / 1073741824).toFixed(2)} GB`;
};

export const fmtAgo = (iso: string | null | undefined) => {
  if (!iso) return "—";
  const s = Math.max(0, (Date.now() - Date.parse(iso)) / 1000);
  if (s < 45) return "just now";
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
};

export const fmtUptime = (s: number) => {
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m ${s % 60}s`;
};

export const fmtNum = (n: number | null | undefined) =>
  n === null || n === undefined ? "—" : n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}k` : String(n);
