/**
 * Typed client for the CLEARPIX AI REST API (see /server).
 *
 * The site is built as a static single file, so the backend may or may not be
 * running. Every call goes through `request()`, which surfaces structured
 * ApiError objects; the engine layer uses that to fall back to the in-browser
 * pipeline when the server is unreachable.
 */

const TOKEN_KEY = "clearpix.token";
const BASE_KEY = "clearpix.apiBase";

export interface HealthInfo {
  status: string;
  service: string;
  version: string;
  env: string;
  uptimeSeconds: number;
  capabilities: {
    engine: string;
    neuralNetwork: boolean;
    decode: string[];
    encode: string[];
    note: string;
  };
  limits: { maxUploadBytes: number; maxEdge: number; mimeTypes: string[]; assetTtlMs: number };
  queue: { concurrency: number; queued: number; active: number; stages: string[] };
}

export interface ImageRecord {
  id: string;
  name: string;
  mimeType: string;
  bytes: number;
  format: string;
  sourceUrl: string;
}

export interface JobRecord {
  id: string;
  imageId: string;
  status: "queued" | "processing" | "succeeded" | "failed";
  progress: number;
  stage: string | null;
  queuePosition: number;
  sensitivity: number;
  width: number | null;
  height: number | null;
  coverage: number | null;
  backdrop: string | null;
  engineMs: number | null;
  totalMs: number | null;
  bytes: number | null;
  error: { code: string; message: string } | null;
  resultUrl: string | null;
}

export interface UserInfo {
  id: string;
  kind: "user" | "guest";
  role: "member" | "admin";
  status: "active" | "suspended";
  name: string;
  email: string | null;
  plan: string;
  credits: number;
  createdAt: string;
  lastLoginAt: string | null;
}

export interface AccountInfo {
  session: { kind: "user" | "guest"; id: string };
  user: UserInfo;
  plan: { id: string; name: string; exportCredits: number; maxEdge: number; batchSize: number };
  usage: {
    images: number;
    jobs: number;
    succeeded: number;
    failed: number;
    exports: number;
    creditsRemaining: number;
    creditsIncluded: number;
  };
}

export class ApiError extends Error {
  code: string;
  status: number;
  details?: unknown;
  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/* ------------------------------------------------------------------ */
/* Base URL + token                                                    */
/* ------------------------------------------------------------------ */
function resolveBase(): string {
  try {
    const stored = localStorage.getItem(BASE_KEY);
    if (stored) return stored.replace(/\/$/, "");
  } catch {
    /* storage unavailable */
  }
  const env = (import.meta as { env?: Record<string, string> }).env?.VITE_API_URL;
  if (env) return env.replace(/\/$/, "");
  if (typeof location !== "undefined") {
    const local = ["localhost", "127.0.0.1", "0.0.0.0"].includes(location.hostname);
    // Vite dev server runs on 5173; the API defaults to 8787.
    if (local && location.port && location.port !== "8787") return `${location.protocol}//${location.hostname}:8787`;
    return location.origin;
  }
  return "http://localhost:8787";
}

export const apiBase = resolveBase();

export const setApiBase = (url: string) => {
  try {
    localStorage.setItem(BASE_KEY, url);
  } catch {
    /* ignore */
  }
};

const readToken = () => {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
};

const writeToken = (token: string) => {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* ignore */
  }
};

export const clearToken = () => {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
};

/* ------------------------------------------------------------------ */
/* Core request helper                                                 */
/* ------------------------------------------------------------------ */
interface RequestOptions {
  method?: string;
  body?: unknown;
  timeoutMs?: number;
  raw?: boolean;
  signal?: AbortSignal;
}

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, timeoutMs = 30_000, raw = false } = opts;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  opts.signal?.addEventListener("abort", () => controller.abort());

  const headers: Record<string, string> = { accept: "application/json" };
  const token = readToken();
  if (token) headers.authorization = `Bearer ${token}`;

  let payload: BodyInit | undefined;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) {
    headers["content-type"] = "application/json";
    payload = JSON.stringify(body);
  }

  let res: Response;
  try {
    res = await fetch(`${apiBase}${path}`, {
      method,
      headers,
      body: payload,
      signal: controller.signal,
      mode: "cors",
    });
  } catch (err) {
    clearTimeout(timer);
    throw new ApiError(
      0,
      "network_unreachable",
      err instanceof Error && err.name === "AbortError"
        ? "The API did not respond in time."
        : "Could not reach the CLEARPIX API.",
    );
  }
  clearTimeout(timer);

  const issued = res.headers.get("x-clearpix-session");
  if (issued) writeToken(issued);

  if (raw) {
    if (!res.ok) throw await toError(res);
    return (await res.blob()) as unknown as T;
  }

  const text = await res.text();
  const json = text ? safeParse(text) : {};
  if (!res.ok) {
    const e = (json as { error?: { code: string; message: string; details?: unknown } }).error;
    throw new ApiError(res.status, e?.code ?? "request_failed", e?.message ?? res.statusText, e?.details);
  }
  return json as T;
}

const safeParse = (text: string) => {
  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
};

async function toError(res: Response) {
  const body = await res.text().catch(() => "");
  const parsed = body ? safeParse(body) : {};
  const e = (parsed as { error?: { code: string; message: string } }).error;
  return new ApiError(res.status, e?.code ?? "request_failed", e?.message ?? res.statusText);
}

/* ------------------------------------------------------------------ */
/* Endpoints                                                           */
/* ------------------------------------------------------------------ */
export const api = {
  base: apiBase,

  health: (timeoutMs = 2500) => request<HealthInfo>("/api/health", { timeoutMs }),

  catalogue: () =>
    request<{ name: string; version: string; endpoints: { method: string; path: string; summary: string }[] }>(
      "/api/v1",
    ),

  stats: () =>
    request<{ imagesProcessed: number; pixelsCut: number; exports: number; sessions: number }>(
      "/api/v1/stats",
    ),

  account: () => request<AccountInfo>("/api/v1/account"),

  resetCredits: () =>
    request<{ credits: number; plan: string }>("/api/v1/account/credits/reset", { method: "POST" }),

  switchPlan: (planId: string) =>
    request<{ plan: AccountInfo["plan"]; notice: string }>("/api/v1/account/plan", {
      method: "POST",
      body: { planId },
    }),

  plans: () => request<{ plans: AccountInfo["plan"][]; notice: string }>("/api/v1/plans"),

  uploadImage: (file: File) => {
    const form = new FormData();
    form.append("image", file);
    return request<{ image: ImageRecord }>("/api/v1/images", {
      method: "POST",
      body: form,
      timeoutMs: 60_000,
    });
  },

  createJob: (imageId: string, sensitivity: number) =>
    request<{ job: JobRecord; pollUrl: string }>("/api/v1/jobs", {
      method: "POST",
      body: { imageId, sensitivity },
    }),

  getJob: (jobId: string) => request<{ job: JobRecord }>(`/api/v1/jobs/${jobId}`, { timeoutMs: 10_000 }),

  listJobs: () => request<{ jobs: JobRecord[] }>("/api/v1/jobs"),

  result: (jobId: string, backdrop?: string | null) =>
    request<Blob>(
      `/api/v1/jobs/${jobId}/result.png${backdrop ? `?backdrop=${encodeURIComponent(backdrop)}` : ""}`,
      { raw: true, timeoutMs: 60_000 },
    ),

  exportJob: (jobId: string, backdrop: string | null, filename?: string) =>
    request<{
      export: { id: string; filename: string; transparent: boolean; downloadUrl: string };
      creditsRemaining: number;
    }>(`/api/v1/jobs/${jobId}/export`, { method: "POST", body: { backdrop, filename } }),

  download: (downloadUrl: string) => request<Blob>(downloadUrl, { raw: true, timeoutMs: 60_000 }),

  contact: (payload: { name: string; email: string; topic: string; message: string }) =>
    request<{ message: { id: string; status: string }; notice: string }>("/api/v1/contact", {
      method: "POST",
      body: payload,
    }),

  me: () =>
    request<{ authenticated: boolean; kind: "user" | "guest"; user: UserInfo }>("/api/v1/auth/me", {
      timeoutMs: 6000,
    }),

  logout: () => {
    clearToken();
    return request<{ ok: boolean }>("/api/v1/auth/logout", { method: "POST" }).catch(() => ({ ok: true }));
  },

  register: (payload: { name: string; email: string; password: string }) =>
    request<{ token: string; user: AccountInfo["user"] }>("/api/v1/auth/register", {
      method: "POST",
      body: payload,
    }).then((r) => {
      writeToken(r.token);
      return r;
    }),

  login: (payload: { email: string; password: string }) =>
    request<{ token: string; user: AccountInfo["user"] }>("/api/v1/auth/login", {
      method: "POST",
      body: payload,
    }).then((r) => {
      writeToken(r.token);
      return r;
    }),
};
