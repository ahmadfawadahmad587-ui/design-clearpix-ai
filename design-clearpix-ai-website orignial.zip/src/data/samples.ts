import sneaker from "@/assets/sample-sneaker.jpg";
import portrait from "@/assets/sample-portrait.jpg";
import bag from "@/assets/sample-bag.jpg";
import camera from "@/assets/sample-camera.jpg";
import headphones from "@/assets/sample-headphones.jpg";

export interface Sample {
  id: string;
  name: string;
  category: string;
  note: string;
  src: string;
  /** engine sensitivity tuned per sample */
  sensitivity: number;
}

export const SAMPLES: Sample[] = [
  {
    id: "sneaker",
    name: "Athletic Sneaker",
    category: "Product photography",
    note: "Hard edges, bright seamless backdrop",
    src: sneaker,
    sensitivity: 50,
  },
  {
    id: "portrait",
    name: "Studio Portrait",
    category: "Portrait photography",
    note: "Curly hair detail on a neutral sweep",
    src: portrait,
    sensitivity: 44,
  },
  {
    id: "bag",
    name: "Leather Handbag",
    category: "Fashion product",
    note: "Soft leather grain and metal hardware",
    src: bag,
    sensitivity: 48,
  },
  {
    id: "camera",
    name: "Vintage Camera",
    category: "Creative object",
    note: "Reflective chrome and tight cut-ins",
    src: camera,
    sensitivity: 46,
  },
  {
    id: "headphones",
    name: "Studio Headphones",
    category: "Tech product",
    note: "Matte surfaces against pastel mint",
    src: headphones,
    sensitivity: 48,
  },
];

export const byId = (id: string) => SAMPLES.find((s) => s.id === id)!;
