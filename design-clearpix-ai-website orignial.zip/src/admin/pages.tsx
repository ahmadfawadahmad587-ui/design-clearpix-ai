import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import {
  adminApi,
  assetUrl,
  fmtAgo,
  fmtBytes,
  fmtNum,
  fmtUptime,
  type AdminJob,
  type AdminMessage,
  type AdminUser,
  type Settings,
} from "@/lib/adminApi";
import { Bolt, Cpu, Download, Grid, Hd, Layers, Lock, Portrait, Reset, Scissors, Shield } from "@/components/Icons";
import {
  Badge,
  BarChart,
  Btn,
  Card,
  Chips,
  Confirm,
  Distribution,
  Empty,
  Input,
  Pager,
  Select,
  Stat,
  Table,
  Thumb,
  Toggle,
  usePoll,
} from "./ui";

type Notify = (msg: string, tone?: "ok" | "warn") => void;

const PLAN_COLORS = { free: "#98A2B3", pro: "#7457FF", business: "#101828" };
const STATUS_COLORS = { queued: "#F59E0B", processing: "#36D9E8", succeeded: "#10B981", failed: "#F43F5E" };

/* ================================================================== */
/* Overview                                                            */
/* ================================================================== */
export function OverviewPage({ notify, go }: { notify: Notify; go: (p: string) => void }) {
  const { data, error, refresh } = usePoll(() => adminApi.overview(), 6000);

  if (error && !data) return <ErrorState message={error} />;
  if (!data) return <Skeleton />;

  const { totals, jobs, queue, settings, storage, system } = data;
  const paused = settings?.acceptingJobs === false;

  const toggleProcessing = async () => {
    try {
      await adminApi.updateSettings({ acceptingJobs: paused });
      notify(paused ? "Processing resumed." : "Processing paused — new jobs will be refused.", paused ? "ok" : "warn");
      refresh();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Update failed", "warn");
    }
  };

  return (
    <div className="space-y-5">
      {paused && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3.5">
          <p className="text-[0.86rem] font-600 text-amber-700">
            Processing is <strong>paused</strong>. Non-admin job requests receive <code>503 maintenance</code>.
            {settings.maintenanceMessage && <span className="ml-2 font-500 text-amber-600">“{settings.maintenanceMessage}”</span>}
          </p>
          <Btn tone="dark" onClick={toggleProcessing}>Resume</Btn>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Jobs · 24h" value={totals.jobs24h} hint={`${totals.jobs} all time`} tone="brand" icon={<Scissors className="h-5 w-5" />} />
        <Stat
          label="Success rate"
          value={jobs.successRate === null ? "—" : `${Math.round(jobs.successRate * 100)}%`}
          hint={`${jobs.byStatus.failed ?? 0} failed · ${jobs.avgEngineMs ?? "—"} ms avg engine`}
          tone="emerald"
          icon={<Bolt className="h-5 w-5" />}
        />
        <Stat label="Exports · 24h" value={totals.exports24h} hint={`${totals.exports} all time`} tone="aqua" icon={<Download className="h-5 w-5" />} />
        <Stat
          label="Sessions"
          value={totals.users}
          hint={`${totals.members} accounts · ${totals.guests} guests · ${totals.suspended} suspended`}
          icon={<Portrait className="h-5 w-5" />}
        />
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.6fr_1fr]">
        <Card title="Throughput — last 24 hours" action={<span className="text-[0.72rem] text-ink-muted">violet = jobs · red = failed</span>}>
          <BarChart series={jobs.series} />
        </Card>

        <Card
          title="Worker queue"
          action={
            <span className={cn("inline-flex items-center gap-1.5 text-[0.72rem] font-700", paused ? "text-amber-600" : "text-emerald-600")}>
              <span className={cn("h-1.5 w-1.5 rounded-full", paused ? "bg-amber-500" : "animate-pulse bg-emerald-500")} />
              {paused ? "Paused" : "Accepting"}
            </span>
          }
        >
          <div className="grid grid-cols-3 gap-3">
            {[
              { k: "Active", v: queue.active },
              { k: "Queued", v: queue.queued },
              { k: "Threads", v: queue.concurrency },
            ].map((x) => (
              <div key={x.k} className="rounded-xl bg-mist px-3 py-3 text-center">
                <p className="font-display text-[1.4rem] leading-none font-700 text-ink">{x.v}</p>
                <p className="mt-1 text-[0.66rem] font-700 tracking-[0.12em] text-ink-muted uppercase">{x.k}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between rounded-xl border border-line px-4 py-3">
            <div>
              <p className="text-[0.84rem] font-700 text-ink">Accept new jobs</p>
              <p className="text-[0.74rem] text-ink-muted">Admins bypass the pause.</p>
            </div>
            <Toggle on={!paused} onChange={toggleProcessing} label="Accept new jobs" />
          </div>
          <div className="mt-4">
            <p className="mb-2 text-[0.66rem] font-700 tracking-[0.14em] text-ink-muted uppercase">Job status mix</p>
            <Distribution data={jobs.byStatus} colors={STATUS_COLORS} />
          </div>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <Card title="Plan distribution">
          <Distribution data={data.plans} colors={PLAN_COLORS} />
        </Card>
        <Card title="Storage">
          <p className="font-display text-[1.7rem] leading-none font-700 text-ink">{fmtBytes(storage.bytes)}</p>
          <ul className="mt-4 space-y-2 text-[0.82rem]">
            <li className="flex justify-between"><span className="text-ink-soft">Uploads</span><span className="font-700 text-ink">{storage.uploads.files} · {fmtBytes(storage.uploads.bytes)}</span></li>
            <li className="flex justify-between"><span className="text-ink-soft">Renders</span><span className="font-700 text-ink">{storage.renders.files} · {fmtBytes(storage.renders.bytes)}</span></li>
            <li className="flex justify-between"><span className="text-ink-soft">Pixels cut</span><span className="font-700 text-ink">{fmtNum(data.counters.pixelsCut)}</span></li>
          </ul>
          <Btn className="mt-4 w-full" onClick={() => go("system")}>Housekeeping →</Btn>
        </Card>
        <Card title="Runtime">
          <ul className="space-y-2 text-[0.82rem]">
            <li className="flex justify-between"><span className="text-ink-soft">Node</span><span className="font-700 text-ink">{system.node}</span></li>
            <li className="flex justify-between"><span className="text-ink-soft">Uptime</span><span className="font-700 text-ink">{fmtUptime(system.uptimeSeconds)}</span></li>
            <li className="flex justify-between"><span className="text-ink-soft">RSS memory</span><span className="font-700 text-ink">{fmtBytes(system.rssBytes)}</span></li>
            <li className="flex justify-between"><span className="text-ink-soft">Load (1m)</span><span className="font-700 text-ink">{system.loadAvg[0]} / {system.cpus} cpu</span></li>
            <li className="flex justify-between"><span className="text-ink-soft">Env</span><Badge value={system.env} /></li>
          </ul>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.6fr_1fr]">
        <Card title="Recent jobs" action={<Btn onClick={() => go("jobs")}>All jobs →</Btn>} padded={false}>
          {data.recentJobs.length ? (
            <Table head={["Image", "Owner", "Status", "Result", "When"]}>
              {data.recentJobs.map((j) => (
                <tr key={j.id} className="hover:bg-mist/50">
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-3">
                      <Thumb src={assetUrl(j.resultUrl ?? j.sourceUrl)} alt={j.imageName ?? j.id} />
                      <div className="min-w-0">
                        <p className="truncate font-600 text-ink">{j.imageName ?? "—"}</p>
                        <p className="font-mono text-[0.68rem] text-ink-muted">{j.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-ink-soft">{j.owner?.email ?? j.owner?.name ?? "—"}</td>
                  <td className="px-4 py-2.5"><Badge value={j.status} /></td>
                  <td className="px-4 py-2.5 text-ink-soft">{j.width ? `${j.width}×${j.height} · ${j.engineMs}ms` : j.stage ?? "—"}</td>
                  <td className="px-4 py-2.5 text-ink-muted whitespace-nowrap">{fmtAgo(j.createdAt)}</td>
                </tr>
              ))}
            </Table>
          ) : (
            <Empty title="No jobs yet" body="Run a cutout from the public workspace and it will appear here." />
          )}
        </Card>

        <Card title="Inbox" action={<Btn onClick={() => go("inbox")}>{totals.unreadMessages} unread →</Btn>} padded={false}>
          {data.recentMessages.length ? (
            <ul className="divide-y divide-line">
              {data.recentMessages.map((m) => (
                <li key={m.id} className="px-5 py-3">
                  <div className="flex items-center justify-between gap-3">
                    <p className="truncate text-[0.84rem] font-700 text-ink">{m.name}</p>
                    <Badge value={m.status} />
                  </div>
                  <p className="mt-0.5 line-clamp-2 text-[0.78rem] text-ink-soft">{m.message}</p>
                  <p className="mt-1 text-[0.68rem] text-ink-muted">{m.topic} · {fmtAgo(m.createdAt)}</p>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="Inbox is empty" />
          )}
        </Card>
      </div>
    </div>
  );
}

/* ================================================================== */
/* Jobs                                                                */
/* ================================================================== */
export function JobsPage({ notify }: { notify: Notify }) {
  const [status, setStatus] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [preview, setPreview] = useState<AdminJob | null>(null);
  const { data, error, refresh } = usePoll(() => adminApi.jobs({ status, q, page, limit: 25 }), 4000, [status, q, page]);

  const act = async (fn: () => Promise<unknown>, ok: string) => {
    try {
      await fn();
      notify(ok);
      refresh();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Action failed", "warn");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Chips
          value={status}
          onChange={(v) => { setStatus(v); setPage(1); }}
          options={[
            { id: "", label: "All" },
            { id: "queued", label: "Queued" },
            { id: "processing", label: "Processing" },
            { id: "succeeded", label: "Succeeded" },
            { id: "failed", label: "Failed" },
          ]}
        />
        <div className="flex items-center gap-2">
          <Input placeholder="Search id, filename, owner…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} className="w-64" />
          <Btn onClick={refresh}><Reset className="h-3.5 w-3.5" /> Refresh</Btn>
        </div>
      </div>

      {error && !data && <ErrorState message={error} />}
      {data && (
        <Card padded={false} title={`${data.total} job(s)`} action={<span className="text-[0.72rem] text-ink-muted">{data.queue.active} active · {data.queue.queued} queued · auto-refresh 4s</span>}>
          {data.items.length ? (
            <Table head={["Image", "Owner", "Status", "Output", "Subject", "Engine", "Created", ""]}>
              {data.items.map((j) => (
                <tr key={j.id} className="hover:bg-mist/50">
                  <td className="px-4 py-2.5">
                    <button type="button" onClick={() => setPreview(j)} className="flex items-center gap-3 text-left">
                      <Thumb src={assetUrl(j.resultUrl ?? j.sourceUrl)} alt={j.imageName ?? j.id} />
                      <div className="min-w-0">
                        <p className="max-w-[160px] truncate font-600 text-ink">{j.imageName ?? "—"}</p>
                        <p className="font-mono text-[0.68rem] text-ink-muted">{j.id}</p>
                      </div>
                    </button>
                  </td>
                  <td className="px-4 py-2.5">
                    <p className="text-ink-soft">{j.owner?.email ?? j.owner?.name ?? "—"}</p>
                    {j.owner && <Badge value={j.owner.kind} className="mt-0.5" />}
                  </td>
                  <td className="px-4 py-2.5">
                    <Badge value={j.status} />
                    {(j.status === "queued" || j.status === "processing") && (
                      <div className="mt-1.5 h-1 w-24 overflow-hidden rounded-full bg-mist">
                        <div className="h-full bg-gradient-to-r from-brand to-aqua transition-[width]" style={{ width: `${j.progress}%` }} />
                      </div>
                    )}
                    {j.error && <p className="mt-1 max-w-[180px] text-[0.68rem] text-rose-500">{j.error.message}</p>}
                  </td>
                  <td className="px-4 py-2.5 text-ink-soft whitespace-nowrap">{j.width ? `${j.width}×${j.height}` : "—"}<br /><span className="text-[0.7rem] text-ink-muted">{fmtBytes(j.bytes)}</span></td>
                  <td className="px-4 py-2.5 text-ink-soft">{j.coverage !== null ? `${Math.round(j.coverage * 100)}%` : "—"}</td>
                  <td className="px-4 py-2.5 text-ink-soft whitespace-nowrap">{j.engineMs !== null ? `${j.engineMs} ms` : "—"}<br /><span className="text-[0.7rem] text-ink-muted">sens {j.sensitivity}</span></td>
                  <td className="px-4 py-2.5 text-ink-muted whitespace-nowrap">{fmtAgo(j.createdAt)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex justify-end gap-1.5">
                      <Btn onClick={() => act(() => adminApi.retryJob(j.id), "Job re-queued.")} disabled={j.status === "processing" || j.status === "queued"}>Retry</Btn>
                      <Confirm label="Delete" onConfirm={() => act(() => adminApi.deleteJob(j.id), "Job deleted.")} />
                    </div>
                  </td>
                </tr>
              ))}
            </Table>
          ) : (
            <Empty title="No jobs match" body="Try a different status filter or search term." />
          )}
          <Pager page={data.page} pages={data.pages} onPage={setPage} />
        </Card>
      )}

      {preview && <JobDrawer job={preview} onClose={() => setPreview(null)} />}
    </div>
  );
}

function JobDrawer({ job, onClose }: { job: AdminJob; onClose: () => void }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-ink/40 backdrop-blur-sm" onClick={onClose}>
      <aside className="thin-scroll h-full w-full max-w-md overflow-y-auto bg-white p-6 shadow-float" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-[0.7rem] text-ink-muted">{job.id}</p>
            <h3 className="font-display mt-1 text-[1.1rem] font-700 text-ink">{job.imageName ?? "Untitled"}</h3>
          </div>
          <Btn onClick={onClose}>Close</Btn>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <figure>
            <div className="aspect-square overflow-hidden rounded-xl bg-mist ring-1 ring-line">
              <img src={assetUrl(job.sourceUrl)} alt="Source" className="h-full w-full object-contain" />
            </div>
            <figcaption className="mt-1.5 text-center text-[0.68rem] font-700 tracking-[0.12em] text-ink-muted uppercase">Source</figcaption>
          </figure>
          <figure>
            <div className="checkerboard-sm aspect-square overflow-hidden rounded-xl ring-1 ring-line">
              {job.resultUrl ? <img src={assetUrl(job.resultUrl)} alt="Cutout" className="h-full w-full object-contain" /> : <div className="flex h-full items-center justify-center text-[0.72rem] text-ink-muted">No render</div>}
            </div>
            <figcaption className="mt-1.5 text-center text-[0.68rem] font-700 tracking-[0.12em] text-ink-muted uppercase">Cutout</figcaption>
          </figure>
        </div>
        <dl className="mt-5 grid grid-cols-2 gap-2 text-[0.8rem]">
          {[
            ["Status", <Badge key="s" value={job.status} />],
            ["Owner", job.owner?.email ?? job.owner?.name ?? "—"],
            ["Output", job.width ? `${job.width}×${job.height}` : "—"],
            ["Size", fmtBytes(job.bytes)],
            ["Subject", job.coverage !== null ? `${Math.round(job.coverage * 100)}%` : "—"],
            ["Backdrop", job.backdrop ?? "—"],
            ["Engine", job.engineMs !== null ? `${job.engineMs} ms` : "—"],
            ["Sensitivity", job.sensitivity],
            ["Created", new Date(job.createdAt).toLocaleString()],
            ["Finished", job.finishedAt ? new Date(job.finishedAt).toLocaleString() : "—"],
          ].map(([k, v]) => (
            <div key={String(k)} className="rounded-lg bg-mist px-3 py-2">
              <dt className="text-[0.62rem] font-700 tracking-[0.12em] text-ink-muted uppercase">{k}</dt>
              <dd className="mt-0.5 truncate font-600 text-ink">{v}</dd>
            </div>
          ))}
        </dl>
        {job.error && <p className="mt-4 rounded-lg bg-rose-50 px-3 py-2 text-[0.78rem] text-rose-600">{job.error.code}: {job.error.message}</p>}
        {job.resultUrl && (
          <a href={assetUrl(job.resultUrl)} download className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-ink px-4 py-2.5 text-[0.84rem] font-700 text-white">
            <Download className="h-4 w-4" /> Download render
          </a>
        )}
      </aside>
    </div>
  );
}

/* ================================================================== */
/* Users                                                               */
/* ================================================================== */
export function UsersPage({ notify, selfId }: { notify: Notify; selfId: string }) {
  const [kind, setKind] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const { data, error, refresh } = usePoll(() => adminApi.users({ kind, q, page, limit: 25 }), 10000, [kind, q, page]);

  const patch = async (u: AdminUser, body: Parameters<typeof adminApi.updateUser>[1], ok: string) => {
    try {
      await adminApi.updateUser(u.id, body);
      notify(ok);
      refresh();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Update failed", "warn");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Chips value={kind} onChange={(v) => { setKind(v); setPage(1); }} options={[{ id: "", label: "All" }, { id: "user", label: "Accounts" }, { id: "guest", label: "Guest sessions" }]} />
        <Input placeholder="Search name, email, id…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} className="w-64" />
      </div>
      {error && !data && <ErrorState message={error} />}
      {data && (
        <Card padded={false} title={`${data.total} session(s)`}>
          {data.items.length ? (
            <Table head={["Identity", "Type", "Plan", "Credits", "Usage", "Status", "Seen", ""]}>
              {data.items.map((u) => {
                const self = u.id === selfId;
                return (
                  <tr key={u.id} className="hover:bg-mist/50">
                    <td className="px-4 py-2.5">
                      <p className="font-600 text-ink">{u.name}{self && <span className="ml-1.5 text-[0.66rem] text-brand">(you)</span>}</p>
                      <p className="text-[0.72rem] text-ink-muted">{u.email ?? <span className="font-mono">{u.id}</span>}</p>
                    </td>
                    <td className="px-4 py-2.5"><div className="flex flex-col gap-1"><Badge value={u.kind} /><Badge value={u.role} /></div></td>
                    <td className="px-4 py-2.5">
                      <Select value={u.plan} onChange={(e) => patch(u, { plan: e.target.value }, `Plan set to ${e.target.value}.`)}>
                        <option value="free">Free</option>
                        <option value="pro">Pro</option>
                        <option value="business">Business</option>
                      </Select>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1">
                        <Btn onClick={() => patch(u, { addCredits: -1 }, "Credit removed.")} disabled={u.credits <= 0}>−</Btn>
                        <span className="w-10 text-center font-700 text-ink tabular-nums">{u.credits}</span>
                        <Btn onClick={() => patch(u, { addCredits: 5 }, "5 credits granted.")}>+5</Btn>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-ink-soft whitespace-nowrap">{u.usage.jobs} jobs · {u.usage.exports} exports<br /><span className="text-[0.7rem] text-ink-muted">{u.usage.images} uploads</span></td>
                    <td className="px-4 py-2.5"><Badge value={u.status} /></td>
                    <td className="px-4 py-2.5 text-ink-muted whitespace-nowrap">{fmtAgo(u.lastLoginAt ?? u.createdAt)}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex justify-end gap-1.5">
                        {u.kind === "user" && !self && (
                          <Btn onClick={() => patch(u, { role: u.role === "admin" ? "member" : "admin" }, u.role === "admin" ? "Admin role removed." : "Promoted to admin.")}>
                            {u.role === "admin" ? "Demote" : "Make admin"}
                          </Btn>
                        )}
                        {!self && (
                          <Btn tone={u.status === "suspended" ? "dark" : "ghost"} onClick={() => patch(u, { status: u.status === "suspended" ? "active" : "suspended" }, u.status === "suspended" ? "Reinstated." : "Suspended.")}>
                            {u.status === "suspended" ? "Reinstate" : "Suspend"}
                          </Btn>
                        )}
                        {!self && (
                          <Confirm label="Delete" onConfirm={async () => {
                            try { await adminApi.deleteUser(u.id); notify("Session deleted with all its assets."); refresh(); }
                            catch (e) { notify(e instanceof Error ? e.message : "Delete failed", "warn"); }
                          }} />
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </Table>
          ) : (
            <Empty title="No sessions match" />
          )}
          <Pager page={data.page} pages={data.pages} onPage={setPage} />
        </Card>
      )}
    </div>
  );
}

/* ================================================================== */
/* Assets                                                              */
/* ================================================================== */
export function AssetsPage({ notify }: { notify: Notify }) {
  const [tab, setTab] = useState<"images" | "exports">("images");
  const [page, setPage] = useState(1);
  const images = usePoll(() => adminApi.images({ page, limit: 25 }), tab === "images" ? 8000 : 0, [page, tab]);
  const exports = usePoll(() => adminApi.exports({ page, limit: 25 }), tab === "exports" ? 8000 : 0, [page, tab]);

  return (
    <div className="space-y-4">
      <Chips value={tab} onChange={(v) => { setTab(v); setPage(1); }} options={[{ id: "images", label: "Uploads", count: images.data?.total }, { id: "exports", label: "Exports", count: exports.data?.total }]} />

      {tab === "images" && images.data && (
        <Card padded={false} title="Uploaded sources" action={<span className="text-[0.72rem] text-ink-muted">auto-expire via TTL sweep</span>}>
          {images.data.items.length ? (
            <Table head={["File", "Owner", "Format", "Size", "Jobs", "Uploaded", "Expires", ""]}>
              {images.data.items.map((i) => (
                <tr key={i.id} className="hover:bg-mist/50">
                  <td className="px-4 py-2.5"><div className="flex items-center gap-3"><Thumb src={assetUrl(i.fileUrl)} alt={i.name} checker={false} /><div><p className="max-w-[200px] truncate font-600 text-ink">{i.name}</p><p className="font-mono text-[0.68rem] text-ink-muted">{i.id}</p></div></div></td>
                  <td className="px-4 py-2.5 text-ink-soft">{i.owner?.email ?? i.owner?.name ?? "—"}</td>
                  <td className="px-4 py-2.5 uppercase text-ink-soft">{i.format}</td>
                  <td className="px-4 py-2.5 text-ink-soft">{fmtBytes(i.bytes)}</td>
                  <td className="px-4 py-2.5 text-ink-soft">{i.jobs}</td>
                  <td className="px-4 py-2.5 text-ink-muted whitespace-nowrap">{fmtAgo(i.createdAt)}</td>
                  <td className="px-4 py-2.5 text-ink-muted whitespace-nowrap">{new Date(i.expiresAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</td>
                  <td className="px-4 py-2.5 text-right"><Confirm label="Delete" onConfirm={async () => { await adminApi.deleteImage(i.id).then(() => notify("Upload deleted.")).catch((e) => notify(e.message, "warn")); images.refresh(); }} /></td>
                </tr>
              ))}
            </Table>
          ) : <Empty title="No uploads on disk" />}
          <Pager page={images.data.page} pages={images.data.pages} onPage={setPage} />
        </Card>
      )}

      {tab === "exports" && exports.data && (
        <Card padded={false} title="Export ledger" action={<span className="text-[0.72rem] text-ink-muted">each row consumed one credit</span>}>
          {exports.data.items.length ? (
            <Table head={["Filename", "Owner", "Job", "Backdrop", "Downloads", "When"]}>
              {exports.data.items.map((e) => (
                <tr key={e.id} className="hover:bg-mist/50">
                  <td className="px-4 py-2.5"><p className="font-600 text-ink">{e.filename}</p><p className="font-mono text-[0.68rem] text-ink-muted">{e.id}</p></td>
                  <td className="px-4 py-2.5 text-ink-soft">{e.owner?.email ?? e.owner?.name ?? "—"}</td>
                  <td className="px-4 py-2.5 text-ink-soft">{e.job ? `${e.job.imageName ?? e.job.id} · ${e.job.width}×${e.job.height}` : "—"}</td>
                  <td className="px-4 py-2.5">{e.backdrop ? <span className="inline-flex items-center gap-1.5 text-ink-soft"><span className="h-3.5 w-3.5 rounded ring-1 ring-line" style={{ background: e.backdrop }} />{e.backdrop}</span> : <span className="text-ink-muted">transparent</span>}</td>
                  <td className="px-4 py-2.5 text-ink-soft">{e.downloads}</td>
                  <td className="px-4 py-2.5 text-ink-muted whitespace-nowrap">{fmtAgo(e.createdAt)}</td>
                </tr>
              ))}
            </Table>
          ) : <Empty title="No exports yet" />}
          <Pager page={exports.data.page} pages={exports.data.pages} onPage={setPage} />
        </Card>
      )}
      {((tab === "images" && images.error && !images.data) || (tab === "exports" && exports.error && !exports.data)) && <ErrorState message={images.error ?? exports.error ?? ""} />}
    </div>
  );
}

/* ================================================================== */
/* Inbox                                                               */
/* ================================================================== */
export function InboxPage({ notify }: { notify: Notify }) {
  const [status, setStatus] = useState("");
  const [open, setOpen] = useState<AdminMessage | null>(null);
  const { data, error, refresh } = usePoll(() => adminApi.messages({ status, limit: 50 }), 8000, [status]);

  const setState = async (m: AdminMessage, s: AdminMessage["status"]) => {
    try {
      await adminApi.updateMessage(m.id, s);
      notify(`Marked as ${s}.`);
      refresh();
      setOpen((o) => (o && o.id === m.id ? { ...o, status: s } : o));
    } catch (e) {
      notify(e instanceof Error ? e.message : "Update failed", "warn");
    }
  };

  return (
    <div className="space-y-4">
      <Chips
        value={status}
        onChange={setStatus}
        options={[
          { id: "", label: "All", count: data?.total },
          { id: "received", label: "New", count: data?.byStatus.received ?? 0 },
          { id: "read", label: "Read", count: data?.byStatus.read ?? 0 },
          { id: "resolved", label: "Resolved", count: data?.byStatus.resolved ?? 0 },
        ]}
      />
      {error && !data && <ErrorState message={error} />}
      {data && (
        <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
          <Card padded={false} title="Messages">
            {data.items.length ? (
              <ul className="divide-y divide-line">
                {data.items.map((m) => (
                  <li key={m.id}>
                    <button type="button" onClick={() => { setOpen(m); if (m.status === "received") void setState(m, "read"); }} className={cn("w-full px-5 py-3.5 text-left transition-colors hover:bg-mist/60", open?.id === m.id && "bg-brand-wash/60")}>
                      <div className="flex items-center justify-between gap-3">
                        <p className={cn("truncate text-[0.86rem] text-ink", m.status === "received" ? "font-700" : "font-600")}>{m.name}</p>
                        <Badge value={m.status} />
                      </div>
                      <p className="mt-0.5 line-clamp-1 text-[0.78rem] text-ink-soft">{m.message}</p>
                      <p className="mt-1 text-[0.68rem] text-ink-muted">{m.topic} · {m.email} · {fmtAgo(m.createdAt)}</p>
                    </button>
                  </li>
                ))}
              </ul>
            ) : <Empty title="Nothing here" body="Messages posted from the site's contact form land in this inbox." />}
          </Card>
          <Card title={open ? "Message" : "Select a message"}>
            {open ? (
              <div>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-[1.05rem] font-700 text-ink">{open.name}</p>
                    <a href={`mailto:${open.email}`} className="text-[0.82rem] text-brand">{open.email}</a>
                  </div>
                  <div className="flex gap-1.5">
                    <Badge value={open.topic} />
                    <Badge value={open.status} />
                  </div>
                </div>
                <p className="mt-4 rounded-xl bg-mist px-4 py-3 text-[0.9rem] leading-relaxed whitespace-pre-wrap text-ink-soft">{open.message}</p>
                <p className="mt-2 text-[0.7rem] text-ink-muted">{new Date(open.createdAt).toLocaleString()}{open.handledBy && ` · handled by ${open.handledBy}`}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  <Btn tone="primary" size="md" onClick={() => setState(open, "resolved")} disabled={open.status === "resolved"}>Mark resolved</Btn>
                  <Btn size="md" onClick={() => setState(open, "received")} disabled={open.status === "received"}>Mark unread</Btn>
                  <Confirm size="md" label="Delete" onConfirm={async () => { await adminApi.deleteMessage(open.id); notify("Message deleted."); setOpen(null); refresh(); }} />
                </div>
                <p className="mt-4 text-[0.72rem] text-ink-muted">No email is delivered from this prototype — replies happen in your own mail client.</p>
              </div>
            ) : <Empty title="Pick a message to read it" />}
          </Card>
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/* System                                                              */
/* ================================================================== */
export function SystemPage({ notify }: { notify: Notify }) {
  const { data, error, refresh } = usePoll(() => adminApi.system(), 5000);
  const [draft, setDraft] = useState<Partial<Settings> | null>(null);
  const [level, setLevel] = useState("");
  const logs = usePoll(() => adminApi.logs(200, level || undefined), 3000, [level]);

  useEffect(() => {
    if (data && !draft) setDraft({ maintenanceMessage: data.settings.maintenanceMessage });
  }, [data, draft]);

  if (error && !data) return <ErrorState message={error} />;
  if (!data) return <Skeleton />;

  const run = async (fn: () => Promise<{ [k: string]: unknown }>, fmt: (r: { [k: string]: unknown }) => string) => {
    try {
      const r = await fn();
      notify(fmt(r));
      refresh();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Action failed", "warn");
    }
  };

  const { runtime, config, storage, settings } = data;

  return (
    <div className="space-y-5">
      {config.defaultAdminPassword && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3.5 text-[0.84rem] text-amber-700">
          <Shield className="mt-0.5 h-4 w-4 shrink-0" />
          <p>The admin account is using the <strong>default password</strong>. Set <code>CLEARPIX_ADMIN_PASSWORD</code> (and <code>CLEARPIX_SECRET</code>) before exposing this server anywhere public.</p>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Uptime" value={fmtUptime(runtime.uptimeSeconds)} hint={`pid ${runtime.pid} · ${runtime.node}`} icon={<Cpu className="h-5 w-5" />} />
        <Stat label="Memory" value={fmtBytes(runtime.rssBytes)} hint={`heap ${fmtBytes(runtime.heapUsedBytes)} / ${fmtBytes(runtime.heapTotalBytes)}`} tone="brand" icon={<Layers className="h-5 w-5" />} />
        <Stat label="Load" value={runtime.loadAvg.join(" · ")} hint={`${runtime.cpus} cpu · ${fmtBytes(runtime.freeMemBytes)} free`} tone="aqua" icon={<Bolt className="h-5 w-5" />} />
        <Stat label="Disk" value={fmtBytes(storage.bytes)} hint={`${storage.uploads.files} uploads · ${storage.renders.files} renders`} tone="emerald" icon={<Hd className="h-5 w-5" />} />
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card title="Processing controls">
          <div className="flex items-center justify-between rounded-xl border border-line px-4 py-3">
            <div>
              <p className="text-[0.86rem] font-700 text-ink">Accept new jobs</p>
              <p className="text-[0.74rem] text-ink-muted">{settings.acceptingJobs ? "Queue is open to all sessions." : "Paused — non-admins get 503 maintenance."}</p>
            </div>
            <Toggle on={settings.acceptingJobs} onChange={(v) => run(() => adminApi.updateSettings({ acceptingJobs: v }), () => (v ? "Processing resumed." : "Processing paused."))} />
          </div>
          <label className="mt-4 block text-[0.7rem] font-700 tracking-[0.12em] text-ink-muted uppercase">Maintenance message</label>
          <div className="mt-1.5 flex gap-2">
            <Input className="flex-1" placeholder="Shown to clients while paused" value={draft?.maintenanceMessage ?? ""} onChange={(e) => setDraft({ maintenanceMessage: e.target.value })} />
            <Btn tone="dark" size="md" onClick={() => run(() => adminApi.updateSettings({ maintenanceMessage: draft?.maintenanceMessage ?? "" }), () => "Message saved.")}>Save</Btn>
          </div>
          {settings.updatedAt && <p className="mt-2 text-[0.7rem] text-ink-muted">Last changed {fmtAgo(settings.updatedAt)}{settings.updatedBy && ` by ${settings.updatedBy}`}</p>}

          <div className="mt-6 grid gap-2 sm:grid-cols-2">
            <Btn size="md" onClick={() => run(() => adminApi.sweep(), (r) => `Housekeeping removed ${r.removed} expired file(s).`)}>
              <Reset className="h-4 w-4" /> Sweep expired assets
            </Btn>
            <Confirm size="md" tone="ghost" label={<><Grid className="h-4 w-4" /> Purge idle guests (24h+)</>} confirmLabel="Purge now" onConfirm={() => run(() => adminApi.purgeGuests(), (r) => `Purged ${r.removedSessions} guest session(s), ${r.filesRemoved} file(s).`)} />
          </div>
        </Card>

        <Card title="Configuration">
          <dl className="grid grid-cols-2 gap-2 text-[0.8rem]">
            {[
              ["Port", config.port],
              ["Environment", runtime.env],
              ["Max upload", fmtBytes(config.maxUploadBytes)],
              ["Max edge", `${config.maxEdge}px`],
              ["Asset TTL", fmtUptime(config.assetTtlMs / 1000)],
              ["Token TTL", fmtUptime(config.tokenTtlSeconds)],
              ["CORS", config.corsOrigins.join(", ")],
              ["Workers", data.queue.concurrency],
              ["Secret", config.secretConfigured ? "configured" : "random per boot"],
              ["Admin", config.adminEmail],
            ].map(([k, v]) => (
              <div key={String(k)} className="rounded-lg bg-mist px-3 py-2">
                <dt className="text-[0.62rem] font-700 tracking-[0.12em] text-ink-muted uppercase">{k}</dt>
                <dd className="mt-0.5 truncate font-600 text-ink">{String(v)}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 truncate font-mono text-[0.7rem] text-ink-muted" title={config.dataDir}>data: {config.dataDir}</p>
          <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-line px-4 py-3 text-[0.76rem] text-ink-soft">
            <Lock className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
            <p><strong className="text-ink">Engine:</strong> {data.capabilities.engine} — neural network: <strong>{String(data.capabilities.neuralNetwork)}</strong>. {data.capabilities.note}</p>
          </div>
        </Card>
      </div>

      <Card
        title="Server log"
        padded={false}
        action={
          <div className="flex items-center gap-2">
            <Chips value={level} onChange={setLevel} options={[{ id: "", label: "All" }, { id: "http", label: "HTTP" }, { id: "info", label: "Info" }, { id: "warn", label: "Warn" }, { id: "error", label: "Error" }]} />
          </div>
        }
      >
        <div className="thin-scroll max-h-[380px] overflow-auto bg-[#0B111E] p-4 font-mono text-[0.72rem] leading-[1.7]">
          {logs.data?.logs.length ? (
            [...logs.data.logs].reverse().map((l, i) => (
              <div key={`${l.ts}-${i}`} className="flex gap-3 whitespace-nowrap">
                <span className="text-white/30">{l.ts.slice(11, 23)}</span>
                <span className={cn("w-10 shrink-0 uppercase", l.level === "error" ? "text-rose-400" : l.level === "warn" ? "text-amber-300" : l.level === "ok" ? "text-emerald-400" : l.level === "http" ? "text-white/40" : "text-aqua")}>{l.level}</span>
                <span className="text-white/80">{l.msg}</span>
              </div>
            ))
          ) : (
            <p className="text-white/40">No log lines yet.</p>
          )}
        </div>
      </Card>
    </div>
  );
}

/* ================================================================== */
/* shared states                                                       */
/* ================================================================== */
function ErrorState({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-rose-200 bg-rose-50 px-5 py-6 text-center">
      <p className="text-[0.9rem] font-700 text-rose-600">Could not load this view</p>
      <p className="mt-1 text-[0.8rem] text-rose-500">{message}</p>
    </div>
  );
}

function Skeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="h-24 animate-pulse rounded-2xl border border-line bg-white" />
      ))}
    </div>
  );
}
