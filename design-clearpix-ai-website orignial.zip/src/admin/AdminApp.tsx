import { useCallback, useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { api, ApiError, clearToken, type UserInfo } from "@/lib/api";
import { backendBase, detectBackend } from "@/lib/engine";
import { Bolt, Check, Cpu, Grid, Layers, Lock, Logo, Mail, Portrait, Scissors, Shield, Wordmark } from "@/components/Icons";
import { AssetsPage, InboxPage, JobsPage, OverviewPage, SystemPage, UsersPage } from "./pages";
import { Btn } from "./ui";

type PageId = "overview" | "jobs" | "users" | "assets" | "inbox" | "system";

const PAGES: { id: PageId; label: string; icon: typeof Grid; blurb: string }[] = [
  { id: "overview", label: "Overview", icon: Grid, blurb: "Throughput, queue and health at a glance" },
  { id: "jobs", label: "Jobs", icon: Scissors, blurb: "Every cutout across every session" },
  { id: "users", label: "Users", icon: Portrait, blurb: "Accounts, guest sessions, plans and credits" },
  { id: "assets", label: "Assets", icon: Layers, blurb: "Uploads on disk and the export ledger" },
  { id: "inbox", label: "Inbox", icon: Mail, blurb: "Messages from the contact form" },
  { id: "system", label: "System", icon: Cpu, blurb: "Runtime, settings, housekeeping and logs" },
];

const readPage = (): PageId => {
  const m = location.hash.match(/^#\/admin\/?([a-z]*)/);
  const id = (m?.[1] || "overview") as PageId;
  return PAGES.some((p) => p.id === id) ? id : "overview";
};

/* ------------------------------------------------------------------ */
export function AdminApp() {
  const [phase, setPhase] = useState<"probing" | "offline" | "login" | "ready">("probing");
  const [user, setUser] = useState<UserInfo | null>(null);
  const [page, setPage] = useState<PageId>(readPage);
  const [toast, setToast] = useState<{ msg: string; tone: "ok" | "warn" } | null>(null);

  const notify = useCallback((msg: string, tone: "ok" | "warn" = "ok") => setToast({ msg, tone }), []);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3400);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    const previous = document.title;
    document.title = "CLEARPIX AI — Admin Console";
    const onHash = () => setPage(readPage());
    window.addEventListener("hashchange", onHash);
    return () => {
      document.title = previous;
      window.removeEventListener("hashchange", onHash);
    };
  }, []);

  const bootstrap = useCallback(async () => {
    setPhase("probing");
    const info = await detectBackend(true);
    if (!info) return setPhase("offline");
    try {
      const me = await api.me();
      if (me.kind === "user" && me.user.role === "admin") {
        setUser(me.user);
        return setPhase("ready");
      }
    } catch {
      /* fall through to login */
    }
    setPhase("login");
  }, []);

  useEffect(() => {
    void bootstrap();
  }, [bootstrap]);

  const go = (p: string) => {
    location.hash = `#/admin/${p}`;
    setPage(p as PageId);
  };

  const signOut = async () => {
    await api.logout();
    clearToken();
    setUser(null);
    setPhase("login");
  };

  if (phase === "probing") return <Splash label="Connecting to the CLEARPIX API…" />;
  if (phase === "offline") return <Offline retry={bootstrap} />;
  if (phase === "login" || !user) return <Login onSuccess={(u) => { setUser(u); setPhase("ready"); }} />;

  const current = PAGES.find((p) => p.id === page)!;

  return (
    <div className="min-h-screen bg-mist text-ink lg:grid lg:grid-cols-[256px_1fr]">
      {/* ---------- sidebar ---------- */}
      <aside className="flex flex-col border-b border-white/8 bg-ink text-white lg:sticky lg:top-0 lg:h-screen lg:border-r lg:border-b-0">
        <a href="#home" className="flex items-center gap-2.5 px-5 py-5">
          <Logo className="h-9 w-9" />
          <div>
            <Wordmark dark className="block leading-none" />
            <span className="text-[10px] font-700 tracking-[0.22em] text-aqua uppercase">Admin console</span>
          </div>
        </a>
        <nav className="thin-scroll flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:overflow-visible lg:pb-0">
          {PAGES.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => go(p.id)}
              className={cn(
                "flex shrink-0 items-center gap-3 rounded-xl px-3.5 py-2.5 text-left text-[0.86rem] font-600 transition-colors",
                page === p.id ? "bg-white/12 text-white" : "text-white/55 hover:bg-white/6 hover:text-white",
              )}
            >
              <p.icon className={cn("h-[18px] w-[18px]", page === p.id ? "text-aqua" : "")} />
              {p.label}
            </button>
          ))}
        </nav>
        <div className="mt-auto hidden p-4 lg:block">
          <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-4">
            <div className="flex items-center gap-3">
              <span className="font-display flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-brand to-aqua text-[0.78rem] font-700 text-white">
                {user.name.slice(0, 2).toUpperCase()}
              </span>
              <div className="min-w-0">
                <p className="truncate text-[0.84rem] font-700">{user.name}</p>
                <p className="truncate text-[0.7rem] text-white/50">{user.email}</p>
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              <a href="#home" className="flex-1 rounded-lg border border-white/15 px-3 py-1.5 text-center text-[0.74rem] font-700 text-white/70 hover:text-white">
                View site
              </a>
              <button type="button" onClick={signOut} className="flex-1 rounded-lg bg-white/10 px-3 py-1.5 text-[0.74rem] font-700 text-white hover:bg-white/20">
                Sign out
              </button>
            </div>
          </div>
          <p className="mt-3 px-1 text-[0.66rem] text-white/30">API · {backendBase}</p>
        </div>
      </aside>

      {/* ---------- main ---------- */}
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-line bg-white/85 px-5 py-4 backdrop-blur-md sm:px-8">
          <div>
            <h1 className="font-display text-[1.25rem] leading-none font-700 tracking-[-0.02em]">{current.label}</h1>
            <p className="mt-1 text-[0.78rem] text-ink-muted">{current.blurb}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-[10px] font-700 tracking-[0.1em] text-emerald-600 uppercase ring-1 ring-emerald-200 sm:inline-flex">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" /> live
            </span>
            <button type="button" onClick={signOut} className="rounded-lg border border-line px-3 py-1.5 text-[0.76rem] font-700 text-ink-soft lg:hidden">
              Sign out
            </button>
          </div>
        </header>

        <main className="p-5 sm:p-8">
          {page === "overview" && <OverviewPage notify={notify} go={go} />}
          {page === "jobs" && <JobsPage notify={notify} />}
          {page === "users" && <UsersPage notify={notify} selfId={user.id} />}
          {page === "assets" && <AssetsPage notify={notify} />}
          {page === "inbox" && <InboxPage notify={notify} />}
          {page === "system" && <SystemPage notify={notify} />}
        </main>
      </div>

      {/* toast */}
      <div aria-live="polite" className={cn("pointer-events-none fixed inset-x-0 bottom-6 z-50 flex justify-center px-4 transition-all duration-300", toast ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0")}>
        {toast && (
          <div className={cn("glass-dark flex items-center gap-2.5 rounded-full border px-5 py-2.5 text-[0.84rem] font-600 text-white shadow-float", toast.tone === "warn" ? "border-amber-300/40" : "border-white/15")}>
            <span className={cn("flex h-5 w-5 items-center justify-center rounded-full", toast.tone === "warn" ? "bg-amber-400 text-ink" : "bg-aqua text-ink")}>
              <Check className="h-3 w-3" />
            </span>
            {toast.msg}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Screens                                                             */
/* ------------------------------------------------------------------ */
function Frame({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink px-5 py-16">
      <div aria-hidden className="pointer-events-none absolute -top-40 -left-32 h-[520px] w-[520px] rounded-full blur-[100px]" style={{ background: "radial-gradient(circle, rgba(116,87,255,.55), transparent 70%)" }} />
      <div aria-hidden className="pointer-events-none absolute -right-32 -bottom-40 h-[480px] w-[480px] rounded-full blur-[100px]" style={{ background: "radial-gradient(circle, rgba(54,217,232,.35), transparent 70%)" }} />
      <div className="relative w-full max-w-md">{children}</div>
    </div>
  );
}

function Splash({ label }: { label: string }) {
  return (
    <Frame>
      <div className="flex flex-col items-center text-center">
        <Logo className="h-14 w-14 animate-pulse" />
        <p className="mt-5 text-[0.9rem] text-white/60">{label}</p>
      </div>
    </Frame>
  );
}

function Offline({ retry }: { retry: () => void }) {
  return (
    <Frame>
      <div className="rounded-[1.6rem] border border-white/12 bg-white/[0.06] p-8 text-white backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <Logo className="h-10 w-10" />
          <Wordmark dark />
        </div>
        <h1 className="font-display mt-6 text-[1.5rem] font-700">The admin console needs the API</h1>
        <p className="mt-2 text-[0.9rem] leading-relaxed text-white/60">
          Nothing answered at <code className="font-mono text-aqua">{backendBase}/api/health</code>. Start the backend, then retry.
        </p>
        <pre className="mt-5 rounded-xl border border-white/10 bg-black/40 p-4 font-mono text-[0.78rem] leading-relaxed text-white/80">{`npm run build\nnode server/index.js\n# → http://localhost:8787/#/admin`}</pre>
        <div className="mt-5 flex gap-2">
          <Btn tone="primary" size="md" onClick={retry}>Retry connection</Btn>
          <a href="#home" className="inline-flex items-center rounded-lg border border-white/15 px-4 py-2.5 text-[0.86rem] font-600 text-white/80 hover:text-white">Back to site</a>
        </div>
      </div>
    </Frame>
  );
}

function Login({ onSuccess }: { onSuccess: (u: UserInfo) => void }) {
  const [email, setEmail] = useState("admin@clearpix.ai");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { user } = await api.login({ email, password });
      if (user.role !== "admin") {
        clearToken();
        throw new ApiError(403, "forbidden", "That account is not an administrator.");
      }
      onSuccess(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    } finally {
      setBusy(false);
    }
  };

  const field = "w-full rounded-xl border border-white/12 bg-white/[0.06] px-4 py-3 text-[0.9rem] text-white placeholder:text-white/35 focus:border-brand-light focus:bg-white/10 focus:outline-none";

  return (
    <Frame>
      <div className="rounded-[1.6rem] border border-white/12 bg-white/[0.06] p-8 text-white shadow-float backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <Logo className="h-10 w-10" />
          <div>
            <Wordmark dark className="block leading-none" />
            <span className="text-[10px] font-700 tracking-[0.22em] text-aqua uppercase">Admin console</span>
          </div>
        </div>
        <h1 className="font-display mt-7 text-[1.6rem] leading-tight font-700 tracking-[-0.02em]">Sign in to the console</h1>
        <p className="mt-2 text-[0.88rem] text-white/55">Administrator accounts only. Sessions are HMAC-signed and expire automatically.</p>

        <form onSubmit={submit} className="mt-6 space-y-3">
          <input type="email" required autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@clearpix.ai" className={field} aria-label="Email" />
          <input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className={field} aria-label="Password" />
          {error && <p className="rounded-lg bg-rose-400/10 px-3 py-2 text-[0.8rem] text-rose-200">{error}</p>}
          <button type="submit" disabled={busy} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-brand to-brand-dark px-5 py-3.5 text-[0.92rem] font-700 text-white shadow-[0_14px_34px_-12px_rgba(116,87,255,1)] transition-transform hover:-translate-y-0.5 disabled:opacity-60">
            <Lock className="h-4 w-4" /> {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <div className="mt-6 rounded-xl border border-white/10 bg-black/25 p-4 text-[0.78rem] leading-relaxed text-white/60">
          <p className="flex items-center gap-2 font-700 text-white/80"><Shield className="h-4 w-4 text-aqua" /> Default development credentials</p>
          <p className="mt-1.5">
            <code className="text-aqua">admin@clearpix.ai</code> / <code className="text-aqua">clearpix-admin</code> — seeded on first boot unless
            <code className="ml-1 text-white/80">CLEARPIX_ADMIN_EMAIL</code> / <code className="text-white/80">CLEARPIX_ADMIN_PASSWORD</code> are set.
          </p>
        </div>
        <div className="mt-4 flex items-center justify-between text-[0.78rem] text-white/45">
          <span className="inline-flex items-center gap-1.5"><Bolt className="h-3.5 w-3.5 text-aqua" /> {backendBase}</span>
          <a href="#home" className="font-600 text-white/70 hover:text-white">← Back to site</a>
        </div>
      </div>
    </Frame>
  );
}
