import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ */
/* Polling hook                                                        */
/* ------------------------------------------------------------------ */
export function usePoll<T>(fetcher: () => Promise<T>, intervalMs: number, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const run = async () => {
      try {
        const d = await fetcher();
        if (!alive.current) return;
        setData(d);
        setError(null);
      } catch (e) {
        if (alive.current) setError(e instanceof Error ? e.message : "Request failed");
      } finally {
        if (alive.current) {
          setLoading(false);
          if (intervalMs > 0 && document.visibilityState === "visible") timer = setTimeout(run, intervalMs);
          else if (intervalMs > 0) timer = setTimeout(run, intervalMs * 3);
        }
      }
    };
    setLoading(true);
    void run();
    return () => {
      alive.current = false;
      if (timer) clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick, intervalMs]);

  return { data, error, loading, refresh: () => setTick((t) => t + 1) };
}

/* ------------------------------------------------------------------ */
/* Atoms                                                               */
/* ------------------------------------------------------------------ */
export function Card({
  title,
  action,
  children,
  className,
  padded = true,
}: {
  title?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  padded?: boolean;
}) {
  return (
    <section className={cn("overflow-hidden rounded-2xl border border-line bg-white shadow-soft", className)}>
      {(title || action) && (
        <header className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <h3 className="font-display text-[0.74rem] font-700 tracking-[0.16em] text-ink uppercase">{title}</h3>
          {action}
        </header>
      )}
      <div className={padded ? "p-5" : ""}>{children}</div>
    </section>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "ink",
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: "ink" | "brand" | "aqua" | "emerald" | "amber" | "rose";
  icon?: ReactNode;
}) {
  const tones: Record<string, string> = {
    ink: "from-ink to-[#1f2a40]",
    brand: "from-brand to-brand-dark",
    aqua: "from-aqua-dark to-aqua",
    emerald: "from-emerald-500 to-emerald-600",
    amber: "from-amber-400 to-amber-500",
    rose: "from-rose-500 to-rose-600",
  };
  return (
    <div className="flex items-start gap-4 rounded-2xl border border-line bg-white p-5 shadow-soft">
      {icon && (
        <span className={cn("flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br text-white", tones[tone])}>
          {icon}
        </span>
      )}
      <div className="min-w-0">
        <p className="text-[0.7rem] font-700 tracking-[0.14em] text-ink-muted uppercase">{label}</p>
        <p className="font-display mt-1 truncate text-[1.6rem] leading-none font-700 tracking-[-0.02em] text-ink">{value}</p>
        {hint && <p className="mt-1.5 text-[0.76rem] text-ink-muted">{hint}</p>}
      </div>
    </div>
  );
}

const BADGE: Record<string, string> = {
  queued: "bg-amber-50 text-amber-600 ring-amber-200",
  processing: "bg-aqua-wash text-aqua-dark ring-aqua/40",
  succeeded: "bg-emerald-50 text-emerald-600 ring-emerald-200",
  failed: "bg-rose-50 text-rose-600 ring-rose-200",
  active: "bg-emerald-50 text-emerald-600 ring-emerald-200",
  suspended: "bg-rose-50 text-rose-600 ring-rose-200",
  admin: "bg-brand-wash text-brand ring-brand/25",
  member: "bg-mist text-ink-soft ring-line",
  user: "bg-ink text-white ring-ink",
  guest: "bg-mist text-ink-muted ring-line",
  free: "bg-mist text-ink-soft ring-line",
  pro: "bg-brand-wash text-brand ring-brand/25",
  business: "bg-ink text-white ring-ink",
  received: "bg-amber-50 text-amber-600 ring-amber-200",
  read: "bg-aqua-wash text-aqua-dark ring-aqua/40",
  resolved: "bg-emerald-50 text-emerald-600 ring-emerald-200",
  info: "bg-aqua-wash text-aqua-dark ring-aqua/40",
  ok: "bg-emerald-50 text-emerald-600 ring-emerald-200",
  warn: "bg-amber-50 text-amber-600 ring-amber-200",
  error: "bg-rose-50 text-rose-600 ring-rose-200",
  http: "bg-mist text-ink-muted ring-line",
};

export function Badge({ value, className }: { value: string; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-700 tracking-[0.08em] uppercase ring-1",
        BADGE[value] ?? "bg-mist text-ink-soft ring-line",
        className,
      )}
    >
      {value === "processing" && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-current" />}
      {value}
    </span>
  );
}

export function Btn({
  children,
  tone = "ghost",
  size = "sm",
  className,
  ...rest
}: { tone?: "primary" | "ghost" | "danger" | "dark"; size?: "sm" | "md" } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-lg font-600 whitespace-nowrap transition-all duration-200 disabled:pointer-events-none disabled:opacity-40",
        size === "sm" ? "px-2.5 py-1.5 text-[0.76rem]" : "px-4 py-2.5 text-[0.86rem]",
        tone === "primary" && "bg-gradient-to-r from-brand to-brand-dark text-white shadow-[0_8px_20px_-10px_rgba(116,87,255,.9)] hover:-translate-y-px",
        tone === "dark" && "bg-ink text-white hover:bg-[#1b2538]",
        tone === "ghost" && "border border-line bg-white text-ink-soft hover:border-brand/30 hover:text-brand",
        tone === "danger" && "border border-rose-200 bg-white text-rose-500 hover:bg-rose-50",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

/** Two-step destructive button — first click arms, second confirms. */
export function Confirm({
  label,
  confirmLabel = "Confirm",
  onConfirm,
  tone = "danger",
  size = "sm",
}: {
  label: ReactNode;
  confirmLabel?: string;
  onConfirm: () => void | Promise<void>;
  tone?: "danger" | "ghost" | "dark";
  size?: "sm" | "md";
}) {
  const [armed, setArmed] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!armed) return;
    const t = setTimeout(() => setArmed(false), 3500);
    return () => clearTimeout(t);
  }, [armed]);
  return (
    <Btn
      tone={armed ? "danger" : tone}
      size={size}
      disabled={busy}
      className={armed ? "bg-rose-500 text-white hover:bg-rose-600" : undefined}
      onClick={async () => {
        if (!armed) return setArmed(true);
        setBusy(true);
        try {
          await onConfirm();
        } finally {
          setBusy(false);
          setArmed(false);
        }
      }}
    >
      {busy ? "…" : armed ? confirmLabel : label}
    </Btn>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300",
        on ? "bg-gradient-to-r from-brand to-aqua" : "bg-line",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-300",
          on && "translate-x-5",
        )}
      />
    </button>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "rounded-lg border border-line bg-white px-3 py-2 text-[0.84rem] text-ink placeholder:text-ink-muted/70 focus:border-brand/50 focus:outline-none",
        props.className,
      )}
    />
  );
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cn(
        "rounded-lg border border-line bg-white px-2.5 py-2 text-[0.82rem] text-ink focus:border-brand/50 focus:outline-none",
        props.className,
      )}
    />
  );
}

export function Chips<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { id: T; label: string; count?: number }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.76rem] font-700 transition-colors",
            value === o.id ? "bg-ink text-white" : "bg-mist text-ink-soft hover:bg-line/70",
          )}
        >
          {o.label}
          {o.count !== undefined && (
            <span className={cn("rounded-full px-1.5 text-[10px]", value === o.id ? "bg-white/20" : "bg-white")}>{o.count}</span>
          )}
        </button>
      ))}
    </div>
  );
}

export function Empty({ title, body }: { title: string; body?: string }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-mist text-ink-muted">
        <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.6}>
          <rect x="3.5" y="5" width="17" height="14" rx="3" />
          <path d="M3.5 10h17" />
        </svg>
      </span>
      <p className="mt-4 text-[0.95rem] font-700 text-ink">{title}</p>
      {body && <p className="mt-1 max-w-sm text-[0.82rem] text-ink-muted">{body}</p>}
    </div>
  );
}

export function Table({ head, children }: { head: ReactNode[]; children: ReactNode }) {
  return (
    <div className="thin-scroll overflow-x-auto">
      <table className="w-full min-w-[720px] text-left text-[0.82rem]">
        <thead>
          <tr className="border-b border-line bg-mist/60">
            {head.map((h, i) => (
              <th key={i} className="px-4 py-2.5 text-[0.66rem] font-700 tracking-[0.14em] whitespace-nowrap text-ink-muted uppercase">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line">{children}</tbody>
      </table>
    </div>
  );
}

export function Pager({ page, pages, onPage }: { page: number; pages: number; onPage: (p: number) => void }) {
  if (pages <= 1) return null;
  return (
    <div className="flex items-center justify-between border-t border-line px-4 py-3 text-[0.78rem] text-ink-muted">
      <span>
        Page {page} of {pages}
      </span>
      <div className="flex gap-1.5">
        <Btn disabled={page <= 1} onClick={() => onPage(page - 1)}>
          Prev
        </Btn>
        <Btn disabled={page >= pages} onClick={() => onPage(page + 1)}>
          Next
        </Btn>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Charts (dependency-free SVG)                                        */
/* ------------------------------------------------------------------ */
export function BarChart({
  series,
  height = 160,
}: {
  series: { hour: string; jobs: number; failed: number; exports: number }[];
  height?: number;
}) {
  const max = Math.max(1, ...series.map((s) => s.jobs));
  const w = 100 / series.length;
  return (
    <div>
      <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" className="h-40 w-full">
        <defs>
          <linearGradient id="adm-bar" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#7457FF" />
            <stop offset="100%" stopColor="#36D9E8" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1="0" x2="100" y1={height * f} y2={height * f} stroke="#E4E9F2" strokeWidth="0.4" />
        ))}
        {series.map((s, i) => {
          const h = (s.jobs / max) * (height - 8);
          const fh = (s.failed / max) * (height - 8);
          const x = i * w + w * 0.2;
          return (
            <g key={s.hour}>
              <rect x={x} y={height - h} width={w * 0.6} height={h} rx="0.8" fill="url(#adm-bar)" opacity={s.jobs ? 1 : 0.18} />
              {fh > 0 && <rect x={x} y={height - fh} width={w * 0.6} height={fh} rx="0.8" fill="#F43F5E" />}
              <title>{`${s.hour} — ${s.jobs} job(s), ${s.failed} failed, ${s.exports} export(s)`}</title>
            </g>
          );
        })}
      </svg>
      <div className="mt-1.5 flex justify-between text-[0.66rem] font-600 text-ink-muted">
        <span>{series[0]?.hour}</span>
        <span>{series[Math.floor(series.length / 2)]?.hour}</span>
        <span>{series[series.length - 1]?.hour}</span>
      </div>
    </div>
  );
}

export function Distribution({ data, colors }: { data: Record<string, number>; colors: Record<string, string> }) {
  const total = Object.values(data).reduce((a, b) => a + b, 0) || 1;
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1]);
  return (
    <div>
      <div className="flex h-2.5 overflow-hidden rounded-full bg-mist">
        {entries.map(([k, v]) => (
          <span key={k} style={{ width: `${(v / total) * 100}%`, background: colors[k] ?? "#98A2B3" }} />
        ))}
      </div>
      <ul className="mt-3 space-y-1.5">
        {entries.map(([k, v]) => (
          <li key={k} className="flex items-center justify-between text-[0.8rem]">
            <span className="flex items-center gap-2 text-ink-soft capitalize">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: colors[k] ?? "#98A2B3" }} />
              {k}
            </span>
            <span className="font-700 text-ink tabular-nums">
              {v} <span className="text-ink-muted">· {Math.round((v / total) * 100)}%</span>
            </span>
          </li>
        ))}
        {!entries.length && <li className="text-[0.8rem] text-ink-muted">No data yet.</li>}
      </ul>
    </div>
  );
}

export function Thumb({ src, alt, checker = true }: { src: string; alt: string; checker?: boolean }) {
  const [ok, setOk] = useState(true);
  return (
    <span className={cn("flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-lg ring-1 ring-line", checker ? "checkerboard-sm" : "bg-mist")}>
      {ok && src ? (
        <img src={src} alt={alt} className="h-full w-full object-cover" onError={() => setOk(false)} loading="lazy" />
      ) : (
        <span className="text-[9px] font-700 text-ink-muted">N/A</span>
      )}
    </span>
  );
}
