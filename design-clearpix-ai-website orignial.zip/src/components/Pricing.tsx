import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { ArrowRight, Check, Sparkle, Tag } from "./Icons";
import { Reveal, SectionHeading } from "./ui";

const PLANS = [
  {
    name: "Free",
    price: "$0",
    cadence: "forever",
    blurb: "Everything you need to try the cutout engine end to end.",
    features: ["3 demo exports", "Standard preview quality", "Basic tools", "Transparent PNG download", "On-device processing"],
    cta: "Open the Workspace",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$12",
    cadence: "per month",
    blurb: "For creators and sellers shipping images every single day.",
    features: [
      "More export credits",
      "HD export options",
      "Premium editing tools",
      "Backdrop replacement presets",
      "Priority processing queue",
      "Export history",
    ],
    cta: "Request access",
    highlight: true,
  },
  {
    name: "Business",
    price: "$39",
    cadence: "per month",
    blurb: "Shared workflows for catalogue, studio and marketing teams.",
    features: [
      "Team workspace",
      "Batch workflow",
      "Business-oriented features",
      "Shared brand presets",
      "Role-based access",
      "Dedicated support channel",
    ],
    cta: "Talk to us",
    highlight: false,
  },
];

export function Pricing() {
  const [note, setNote] = useState<string | null>(null);

  useEffect(() => {
    if (!note) return;
    const t = setTimeout(() => setNote(null), 3800);
    return () => clearTimeout(t);
  }, [note]);

  const act = (plan: string) => {
    if (plan === "Free") {
      document.getElementById("studio")?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }
    setNote(`${plan} is a concept tier in this prototype — no checkout or subscription is connected.`);
  };

  return (
    <section id="pricing" className="relative scroll-mt-24 bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
        <SectionHeading
          eyebrow={
            <>
              <Tag className="h-3.5 w-3.5" /> Pricing
            </>
          }
          title={
            <>
              Simple tiers, <span className="text-gradient">no surprises</span>.
            </>
          }
          lead="Indicative pricing shown for demonstration. This prototype has no payment integration — nothing can be purchased and no subscription is active."
        />

        <div className="mt-14 grid items-stretch gap-6 lg:grid-cols-3">
          {PLANS.map((p, i) => (
            <Reveal key={p.name} delay={i * 90}>
              <div
                className={cn(
                  "relative flex h-full flex-col overflow-hidden rounded-[1.7rem] border p-8 transition-all duration-400",
                  p.highlight
                    ? "border-brand/30 bg-ink text-white shadow-float lg:-translate-y-4 lg:scale-[1.025]"
                    : "border-line bg-mist/50 hover:-translate-y-1.5 hover:border-brand/25 hover:bg-white hover:shadow-card",
                )}
              >
                {p.highlight && (
                  <>
                    <div
                      aria-hidden
                      className="pointer-events-none absolute -top-24 -right-20 h-64 w-64 rounded-full blur-[80px]"
                      style={{ background: "radial-gradient(circle, rgba(116,87,255,.8), transparent 70%)" }}
                    />
                    <span className="absolute top-6 right-6 inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-aqua px-3 py-1 text-[10px] font-700 tracking-[0.14em] text-white uppercase">
                      <Sparkle className="h-3 w-3" /> Popular
                    </span>
                  </>
                )}

                <h3
                  className={cn(
                    "font-display relative text-[1.05rem] font-700 tracking-[0.12em] uppercase",
                    p.highlight ? "text-aqua" : "text-brand",
                  )}
                >
                  {p.name}
                </h3>

                <div className="relative mt-4 flex items-end gap-2">
                  <span
                    className={cn(
                      "font-display text-[3rem] leading-none font-700 tracking-[-0.03em]",
                      p.highlight ? "text-white" : "text-ink",
                    )}
                  >
                    {p.price}
                  </span>
                  <span
                    className={cn(
                      "pb-1.5 text-[0.84rem] font-500",
                      p.highlight ? "text-white/50" : "text-ink-muted",
                    )}
                  >
                    {p.cadence}
                  </span>
                </div>

                <p
                  className={cn(
                    "relative mt-3.5 text-[0.9rem] leading-relaxed",
                    p.highlight ? "text-white/60" : "text-ink-soft",
                  )}
                >
                  {p.blurb}
                </p>

                <ul className="relative mt-7 space-y-3">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3">
                      <span
                        className={cn(
                          "mt-0.5 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full",
                          p.highlight ? "bg-aqua/20 text-aqua" : "bg-brand-wash text-brand",
                        )}
                      >
                        <Check className="h-3 w-3" strokeWidth={2.6} />
                      </span>
                      <span
                        className={cn(
                          "text-[0.89rem] leading-snug",
                          p.highlight ? "text-white/80" : "text-ink-soft",
                        )}
                      >
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>

                <button
                  type="button"
                  onClick={() => act(p.name)}
                  className={cn(
                    "group relative mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3.5 text-[0.92rem] font-700 transition-all duration-300 hover:-translate-y-0.5",
                    p.highlight
                      ? "bg-gradient-to-r from-brand to-brand-dark text-white shadow-[0_14px_34px_-12px_rgba(116,87,255,1)]"
                      : "border border-line bg-white text-ink hover:border-brand/35 hover:text-brand",
                  )}
                >
                  {p.cta}
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                </button>
              </div>
            </Reveal>
          ))}
        </div>

        <div
          className={cn(
            "mx-auto mt-8 max-w-xl overflow-hidden rounded-2xl border border-brand/20 bg-brand-wash text-center transition-all duration-400",
            note ? "max-h-24 px-5 py-3.5 opacity-100" : "max-h-0 border-transparent px-5 py-0 opacity-0",
          )}
          aria-live="polite"
        >
          <p className="text-[0.85rem] font-600 text-brand">{note}</p>
        </div>
      </div>
    </section>
  );
}
