import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";

interface Props {
  before: string;
  after?: string | null;
  loading?: boolean;
  initial?: number;
  className?: string;
  fit?: "cover" | "contain";
  checker?: "sm" | "md";
  /** solid colour behind the cutout instead of the transparency checkerboard */
  backdrop?: string | null;
  labels?: boolean;
  alt?: string;
}

export function CompareSlider({
  before,
  after,
  loading = false,
  initial = 52,
  className,
  fit = "cover",
  checker = "md",
  backdrop = null,
  labels = true,
  alt = "Comparison",
}: Props) {
  const wrap = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(initial);
  const [dragging, setDragging] = useState(false);

  const update = useCallback((clientX: number) => {
    const el = wrap.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const p = ((clientX - r.left) / r.width) * 100;
    setPos(Math.max(0, Math.min(100, p)));
  }, []);

  useEffect(() => {
    if (!dragging) return;
    const move = (e: PointerEvent) => update(e.clientX);
    const up = () => setDragging(false);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [dragging, update]);

  const imgCls = cn(
    "absolute inset-0 h-full w-full select-none",
    fit === "cover" ? "object-cover" : "object-contain",
  );

  return (
    <div
      ref={wrap}
      onPointerDown={(e) => {
        setDragging(true);
        update(e.clientX);
      }}
      className={cn(
        "group relative touch-none overflow-hidden select-none",
        dragging ? "cursor-ew-resize" : "cursor-ew-resize",
        className,
      )}
    >
      {/* AFTER (base layer) */}
      <div
        className={cn(
          "absolute inset-0",
          !backdrop && (checker === "sm" ? "checkerboard-sm" : "checkerboard"),
        )}
        style={backdrop ? { background: backdrop } : undefined}
      >
        {after ? (
          <img src={after} alt={`${alt} — background removed`} className={imgCls} draggable={false} />
        ) : (
          <img
            src={before}
            alt=""
            aria-hidden
            className={cn(imgCls, "opacity-25 grayscale")}
            draggable={false}
          />
        )}
      </div>

      {/* BEFORE (clipped overlay) */}
      <div
        className="absolute inset-0"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
      >
        <img src={before} alt={alt} className={imgCls} draggable={false} />
      </div>

      {/* processing shimmer */}
      {loading && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="animate-scan absolute inset-x-0 h-[26%] bg-gradient-to-b from-transparent via-aqua/35 to-transparent" />
          <div className="absolute inset-0 bg-ink/10" />
        </div>
      )}

      {/* labels */}
      {labels && (
        <>
          <span className="pointer-events-none absolute top-3 left-3 rounded-full bg-ink/70 px-2.5 py-1 text-[10px] font-700 tracking-[0.14em] text-white/90 uppercase backdrop-blur-sm">
            Before
          </span>
          <span className="pointer-events-none absolute top-3 right-3 rounded-full bg-brand/85 px-2.5 py-1 text-[10px] font-700 tracking-[0.14em] text-white uppercase backdrop-blur-sm">
            After
          </span>
        </>
      )}

      {/* handle */}
      <div
        className="pointer-events-none absolute inset-y-0 z-10 w-0"
        style={{ left: `${pos}%` }}
      >
        <div className="absolute inset-y-0 -left-px w-0.5 bg-white/90 shadow-[0_0_16px_rgba(16,24,40,.45)]" />
        <button
          type="button"
          role="slider"
          aria-label="Drag to compare before and after"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(pos)}
          onPointerDown={(e) => {
            e.stopPropagation();
            setDragging(true);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowLeft") setPos((p) => Math.max(0, p - 4));
            if (e.key === "ArrowRight") setPos((p) => Math.min(100, p + 4));
          }}
          className={cn(
            "pointer-events-auto absolute top-1/2 left-1/2 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center",
            "cursor-ew-resize rounded-full border border-white bg-white/95 shadow-[0_8px_26px_-6px_rgba(16,24,40,.5)]",
            "transition-transform duration-200 hover:scale-110 active:scale-95",
          )}
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-ink" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
            <path d="m10 7-4 5 4 5M14 7l4 5-4 5" />
          </svg>
        </button>
      </div>
    </div>
  );
}
