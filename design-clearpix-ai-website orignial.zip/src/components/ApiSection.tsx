import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { Bolt, Check, Cpu, Layers, Lock, Shield } from "./Icons";
import { Reveal, SectionHeading } from "./ui";
import { api, type HealthInfo } from "@/lib/api";
import { backendBase, detectBackend } from "@/lib/engine";

interface Endpoint {
  method: string;
  path: string;
  summary: string;
}

const FALLBACK: Endpoint[] = [
  { method: "GET", path: "/api/health", summary: "Liveness, capabilities and queue state" },
  { method: "POST", path: "/api/v1/auth/register", summary: "Create a demo account" },
  { method: "POST", path: "/api/v1/auth/login", summary: "Exchange credentials for a token" },
  { method: "POST", path: "/api/v1/images", summary: "Upload one image (multipart: image)" },
  { method: "POST", path: "/api/v1/images/batch", summary: "Upload many images (multipart: images)" },
  { method: "POST", path: "/api/v1/jobs", summary: "Queue a cutout job" },
  { method: "POST", path: "/api/v1/jobs/batch", summary: "Queue a batch of cutout jobs" },
  { method: "GET", path: "/api/v1/jobs/:jobId", summary: "Poll job status and progress" },
  { method: "GET", path: "/api/v1/jobs/:jobId/result.png", summary: "Preview render (optional ?backdrop=)" },
  { method: "POST", path: "/api/v1/jobs/:jobId/export", summary: "Spend a credit, mint a download link" },
  { method: "GET", path: "/api/v1/downloads/:exportId", summary: "Download the exported PNG" },
  { method: "GET", path: "/api/v1/account", summary: "Plan, credits and usage snapshot" },
  { method: "GET", path: "/api/v1/plans", summary: "Demo pricing catalogue" },
  { method: "POST", path: "/api/v1/contact", summary: "Store a contact message" },
];

const METHOD_TONE: Record<string, string> = {
  GET: "bg-aqua/15 text-aqua-dark",
  POST: "bg-brand/15 text-brand",
  DELETE: "bg-rose-100 text-rose-500",
};

const SNIPPET = `# 1 — upload (a guest token comes back in x-clearpix-session)
curl -sS -F image=@sneaker.jpg \\
  http://localhost:8787/api/v1/images

# 2 — queue the cutout
curl -sS -X POST http://localhost:8787/api/v1/jobs \\
  -H 'authorization: Bearer $TOKEN' \\
  -H 'content-type: application/json' \\
  -d '{"imageId":"img_…","sensitivity":50}'

# 3 — poll until status is "succeeded"
curl -sS http://localhost:8787/api/v1/jobs/job_… \\
  -H 'authorization: Bearer $TOKEN'

# 4 — transparent PNG, straight to disk
curl -sS http://localhost:8787/api/v1/jobs/job_…/result.png \\
  -H 'authorization: Bearer $TOKEN' -o cutout.png`;

const STACK = [
  { icon: Cpu, label: "Node + Express", note: "Versioned REST surface under /api/v1" },
  { icon: Bolt, label: "Worker threads", note: "Segmentation never blocks the event loop" },
  { icon: Layers, label: "Job queue", note: "Queued → processing → succeeded, with live progress" },
  { icon: Lock, label: "Signed sessions", note: "scrypt passwords, HMAC tokens, per-owner access" },
  { icon: Shield, label: "Guardrails", note: "Rate limits, MIME sniffing, size caps, TTL sweeps" },
  { icon: Check, label: "Zero-config", note: "JSON store on disk — no database to provision" },
];

export function ApiSection() {
  const [health, setHealth] = useState<HealthInfo | null>(null);
  const [endpoints, setEndpoints] = useState<Endpoint[]>(FALLBACK);
  const [probing, setProbing] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let alive = true;
    detectBackend()
      .then(async (info) => {
        if (!alive) return;
        setHealth(info);
        if (!info) return;
        const cat = await api.catalogue().catch(() => null);
        if (alive && cat?.endpoints?.length) setEndpoints(cat.endpoints);
      })
      .finally(() => alive && setProbing(false));
    return () => {
      alive = false;
    };
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(SNIPPET);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard blocked */
    }
  };

  return (
    <section id="api" className="relative scroll-mt-24 overflow-hidden bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
        <SectionHeading
          eyebrow={
            <>
              <Cpu className="h-3.5 w-3.5" /> Developer API
            </>
          }
          title={
            <>
              A real backend, <span className="text-gradient">not a mock</span>.
            </>
          }
          lead="CLEARPIX ships with a Node + Express service that uploads, queues, segments and exports — the same workspace you just used, driven entirely over HTTP."
        />

        {/* live status */}
        <Reveal delay={80}>
          <div className="mx-auto mt-10 flex max-w-3xl flex-wrap items-center justify-center gap-3 rounded-2xl border border-line bg-mist/70 px-5 py-4">
            <span
              className={cn(
                "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-[11px] font-700 tracking-[0.1em] uppercase",
                probing
                  ? "bg-white text-ink-muted"
                  : health
                    ? "bg-emerald-50 text-emerald-600"
                    : "bg-brand-wash text-brand",
              )}
            >
              <span
                className={cn(
                  "h-1.5 w-1.5 rounded-full",
                  probing ? "animate-pulse bg-ink-muted" : health ? "bg-emerald-500" : "bg-brand",
                )}
              />
              {probing ? "Probing" : health ? "API online" : "API offline"}
            </span>
            <code className="rounded-lg bg-white px-3 py-1.5 font-mono text-[0.78rem] text-ink-soft ring-1 ring-line">
              {backendBase}
            </code>
            <span className="text-[0.82rem] text-ink-soft">
              {health
                ? `v${health.version} · ${health.queue.concurrency} worker thread(s) · ${health.queue.active + health.queue.queued} job(s) in flight`
                : "Run “node server/index.js” to bring it up — the site works either way."}
            </span>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
          {/* endpoints */}
          <Reveal delay={120}>
            <div className="h-full overflow-hidden rounded-[1.6rem] border border-line bg-mist/50">
              <div className="flex items-center justify-between border-b border-line px-6 py-4">
                <h3 className="font-display text-[0.78rem] font-700 tracking-[0.16em] text-ink uppercase">
                  Endpoints
                </h3>
                <span className="text-[0.72rem] font-600 text-ink-muted">
                  {endpoints.length} routes {health ? "· live" : "· documented"}
                </span>
              </div>
              <ul className="thin-scroll max-h-[420px] divide-y divide-line overflow-y-auto">
                {endpoints.map((e) => (
                  <li
                    key={`${e.method}-${e.path}`}
                    className="flex items-start gap-3 px-6 py-3 transition-colors duration-200 hover:bg-white"
                  >
                    <span
                      className={cn(
                        "mt-0.5 w-14 shrink-0 rounded-md px-2 py-1 text-center text-[10px] font-700 tracking-[0.06em]",
                        METHOD_TONE[e.method] ?? "bg-mist text-ink-muted",
                      )}
                    >
                      {e.method}
                    </span>
                    <div className="min-w-0">
                      <code className="block truncate font-mono text-[0.8rem] font-600 text-ink">
                        {e.path}
                      </code>
                      <p className="mt-0.5 text-[0.78rem] text-ink-muted">{e.summary}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          {/* snippet + stack */}
          <div className="flex flex-col gap-6">
            <Reveal delay={160}>
              <div className="relative overflow-hidden rounded-[1.6rem] border border-white/10 bg-ink shadow-float">
                <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FF6058]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#FFBD2E]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#2ACB42]" />
                    <span className="font-display ml-3 text-[10px] font-600 tracking-[0.18em] text-white/40 uppercase">
                      quickstart.sh
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={copy}
                    className="rounded-md border border-white/15 px-2.5 py-1 text-[10px] font-700 tracking-[0.1em] text-white/60 uppercase transition-colors hover:border-white/40 hover:text-white"
                  >
                    {copied ? "Copied" : "Copy"}
                  </button>
                </div>
                <pre className="thin-scroll overflow-x-auto px-5 py-5 font-mono text-[0.74rem] leading-[1.75] text-white/70">
                  {SNIPPET}
                </pre>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="grid gap-3 sm:grid-cols-2">
                {STACK.map(({ icon: Icon, label, note }) => (
                  <div
                    key={label}
                    className="group rounded-2xl border border-line bg-mist/50 p-4 transition-all duration-300 hover:-translate-y-1 hover:border-brand/25 hover:bg-white"
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-white">
                      <Icon className="h-[18px] w-[18px]" />
                    </span>
                    <p className="mt-3 text-[0.88rem] font-700 text-ink">{label}</p>
                    <p className="mt-1 text-[0.78rem] leading-relaxed text-ink-muted">{note}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
