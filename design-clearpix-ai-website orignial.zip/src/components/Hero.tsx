import { useEffect, useState } from "react";
import { CompareSlider } from "./CompareSlider";
import { ArrowRight, Bolt, Hd, Layers, Lock, Scissors, Sparkle } from "./Icons";
import { GlowOrb } from "./ui";
import { byId } from "@/data/samples";
import { getCutout } from "@/lib/segment";

const hero = byId("sneaker");

const FLOATERS = [
  { label: "AI Precision", icon: Scissors, cls: "-left-4 top-[14%] sm:-left-9", delay: "0s" },
  { label: "HD Quality", icon: Hd, cls: "-right-3 top-[42%] sm:-right-10", delay: "1.1s" },
  { label: "Transparent PNG", icon: Layers, cls: "left-[8%] -bottom-5", delay: "2.1s" },
];

export function Hero() {
  const [cut, setCut] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    getCutout(hero.src, 900, hero.sensitivity)
      .then((r) => alive && setCut(r.url))
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  const scrollTo = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="home" className="relative overflow-hidden bg-ink pt-[112px] pb-24 sm:pt-[132px] lg:pb-32">
      {/* ambience */}
      <div
        aria-hidden
        className="animate-grid-fade pointer-events-none absolute inset-0 opacity-50"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.045) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.045) 1px, transparent 1px)",
          backgroundSize: "62px 62px",
          maskImage: "radial-gradient(ellipse 85% 65% at 50% 25%, #000 35%, transparent 80%)",
          WebkitMaskImage: "radial-gradient(ellipse 85% 65% at 50% 25%, #000 35%, transparent 80%)",
        }}
      />
      <GlowOrb className="-top-32 -left-24 h-[520px] w-[520px]" color="116,87,255" opacity={0.55} />
      <GlowOrb className="top-10 -right-28 h-[460px] w-[460px]" color="54,217,232" opacity={0.3} />
      <GlowOrb className="bottom-[-180px] left-1/3 h-[420px] w-[420px]" color="116,87,255" opacity={0.28} />
      <div
        aria-hidden
        className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-mist"
      />

      <div className="relative mx-auto grid max-w-[1240px] items-center gap-14 px-5 sm:px-7 lg:grid-cols-[1.02fr_0.98fr] lg:gap-10">
        {/* ---------- copy ---------- */}
        <div className="max-w-xl">
          <div
            data-reveal="in"
            className="inline-flex items-center gap-2.5 rounded-full border border-white/12 bg-white/[0.06] py-1.5 pr-4 pl-1.5 backdrop-blur-md"
          >
            <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-aqua px-2.5 py-1 text-[10px] font-700 tracking-[0.14em] text-white uppercase">
              <Sparkle className="h-3 w-3" /> New
            </span>
            <span className="text-[0.8rem] font-500 text-white/70">
              Edge-aware cutout engine v2 — live in your browser
            </span>
          </div>

          <h1 className="font-display mt-7 text-[2.6rem] leading-[1.04] font-700 tracking-[-0.03em] text-white sm:text-[3.4rem] lg:text-[3.75rem]">
            Remove Backgrounds.
            <br />
            <span className="text-gradient">Reveal Possibilities.</span>
          </h1>

          <p className="mt-6 max-w-lg text-[1.06rem] leading-[1.7] text-white/62">
            Transform ordinary images into professional, transparent masterpieces with
            intelligent AI precision. Fast, simple, and ready for anything.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3.5">
            <a
              href="#studio"
              onClick={scrollTo("studio")}
              className="group inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-brand to-brand-dark px-7 py-4 text-[0.95rem] font-700 text-white shadow-[0_18px_44px_-14px_rgba(116,87,255,.95)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_24px_56px_-14px_rgba(116,87,255,1)]"
            >
              <Scissors className="h-[18px] w-[18px]" />
              Remove Background
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
            <a
              href="#features"
              onClick={scrollTo("features")}
              className="inline-flex items-center gap-2 rounded-full border border-white/18 bg-white/[0.06] px-6 py-4 text-[0.95rem] font-600 text-white backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:border-white/40 hover:bg-white/12"
            >
              Explore Features
            </a>
          </div>

          <ul className="mt-11 flex flex-wrap items-center gap-x-7 gap-y-3.5">
            {[
              { icon: Lock, t: "Images never leave your device" },
              { icon: Bolt, t: "Result in about a second" },
              { icon: Layers, t: "PNG · JPG · WEBP" },
            ].map(({ icon: Icon, t }) => (
              <li key={t} className="flex items-center gap-2 text-[0.82rem] font-500 text-white/55">
                <Icon className="h-4 w-4 text-aqua" />
                {t}
              </li>
            ))}
          </ul>
        </div>

        {/* ---------- visual ---------- */}
        <div className="relative mx-auto w-full max-w-[520px]">
          <div className="animate-float-slow relative">
            <div
              aria-hidden
              className="absolute -inset-5 rounded-[2.4rem] bg-gradient-to-br from-brand/35 via-transparent to-aqua/30 blur-2xl"
            />
            <div className="relative rounded-[1.9rem] border border-white/12 bg-white/[0.07] p-3 shadow-float backdrop-blur-xl">
              <div className="mb-3 flex items-center justify-between px-1.5 pt-1">
                <div className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-[#FF6058]" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#FFBD2E]" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#2ACB42]" />
                </div>
                <span className="font-display text-[10px] font-600 tracking-[0.18em] text-white/45 uppercase">
                  clearpix · live preview
                </span>
              </div>

              <CompareSlider
                before={hero.src}
                after={cut}
                loading={!cut}
                initial={50}
                fit="cover"
                alt="Premium sneaker product photo"
                className="aspect-[4/5] w-full rounded-[1.35rem] sm:aspect-[5/5]"
              />

              <div className="mt-3 flex items-center justify-between px-1.5 pb-1">
                <span className="text-[11px] font-500 text-white/45">
                  Drag the handle to compare
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-aqua/15 px-2.5 py-1 text-[10px] font-700 tracking-[0.1em] text-aqua uppercase">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-aqua" />
                  {cut ? "cutout ready" : "processing"}
                </span>
              </div>
            </div>
          </div>

          {/* floating glass labels */}
          {FLOATERS.map(({ label, icon: Icon, cls, delay }) => (
            <div
              key={label}
              style={{ animationDelay: delay }}
              className={`animate-float absolute z-20 hidden items-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-3.5 py-2.5 shadow-[0_14px_34px_-14px_rgba(0,0,0,.7)] backdrop-blur-xl sm:flex ${cls}`}
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-aqua text-white">
                <Icon className="h-4 w-4" />
              </span>
              <span className="text-[0.78rem] font-700 tracking-[0.02em] text-white">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
