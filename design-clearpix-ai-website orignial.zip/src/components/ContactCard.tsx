import { useState } from "react";
import { cn } from "@/utils/cn";
import { Check, Mail } from "./Icons";
import { api, ApiError } from "@/lib/api";
import { detectBackend } from "@/lib/engine";

type State = "idle" | "sending" | "sent" | "error";

const TOPICS = [
  { id: "support", label: "Support" },
  { id: "sales", label: "Sales" },
  { id: "privacy", label: "Privacy" },
];

export function ContactCard() {
  const [form, setForm] = useState({ name: "", email: "", topic: "support", message: "" });
  const [state, setState] = useState<State>("idle");
  const [note, setNote] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setState("sending");
    setFieldErrors({});

    const online = await detectBackend();
    if (!online) {
      setState("sent");
      setNote("The API is offline, so this message was not stored anywhere. Nothing was sent.");
      return;
    }

    try {
      await api.contact(form);
      setState("sent");
      setNote("Received and stored by the API. No email is actually delivered in this prototype.");
      setForm({ name: "", email: "", topic: "support", message: "" });
    } catch (err) {
      setState("error");
      if (err instanceof ApiError) {
        setNote(err.message);
        if (err.details && typeof err.details === "object") {
          setFieldErrors(err.details as Record<string, string>);
        }
      } else {
        setNote("Could not reach the API.");
      }
    }
  };

  const field =
    "w-full rounded-xl border border-white/12 bg-white/[0.06] px-3.5 py-2.5 text-[0.86rem] text-white placeholder:text-white/35 transition-colors focus:border-brand-light focus:bg-white/10 focus:outline-none";

  return (
    <aside className="sticky top-28 overflow-hidden rounded-[1.4rem] border border-line bg-ink p-6 text-white shadow-float">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-20 -right-16 h-52 w-52 rounded-full blur-[70px]"
        style={{ background: "radial-gradient(circle, rgba(116,87,255,.8), transparent 70%)" }}
      />

      <span className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/20">
        <Mail className="h-5 w-5" />
      </span>
      <h3 className="font-display relative mt-4 text-[1.15rem] font-700">Still have a question?</h3>
      <p className="relative mt-2 text-[0.85rem] leading-relaxed text-white/55">
        This form posts to <code className="font-mono text-[0.78rem] text-aqua">/api/v1/contact</code>{" "}
        when the backend is running.
      </p>

      {state === "sent" ? (
        <div className="relative mt-6 rounded-2xl border border-emerald-400/25 bg-emerald-400/10 p-5 text-center">
          <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-emerald-400 text-ink">
            <Check className="h-5 w-5" strokeWidth={2.6} />
          </span>
          <p className="mt-3 text-[0.9rem] font-700 text-white">Thanks — we have it.</p>
          <p className="mt-1.5 text-[0.78rem] leading-relaxed text-white/60">{note}</p>
          <button
            type="button"
            onClick={() => {
              setState("idle");
              setNote("");
            }}
            className="mt-4 text-[0.8rem] font-700 text-aqua underline underline-offset-2"
          >
            Send another
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="relative mt-5 space-y-2.5">
          <div>
            <input
              required
              value={form.name}
              onChange={set("name")}
              placeholder="Your name"
              aria-label="Your name"
              className={cn(field, fieldErrors.name && "border-rose-400/60")}
            />
            {fieldErrors.name && <p className="mt-1 text-[0.72rem] text-rose-300">{fieldErrors.name}</p>}
          </div>
          <div>
            <input
              required
              type="email"
              value={form.email}
              onChange={set("email")}
              placeholder="you@studio.com"
              aria-label="Your email"
              className={cn(field, fieldErrors.email && "border-rose-400/60")}
            />
            {fieldErrors.email && <p className="mt-1 text-[0.72rem] text-rose-300">{fieldErrors.email}</p>}
          </div>

          <div className="flex gap-1.5">
            {TOPICS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setForm((f) => ({ ...f, topic: t.id }))}
                className={cn(
                  "flex-1 rounded-lg px-2 py-2 text-[0.75rem] font-700 transition-colors duration-200",
                  form.topic === t.id
                    ? "bg-gradient-to-r from-brand to-brand-dark text-white"
                    : "border border-white/12 bg-white/[0.04] text-white/55 hover:text-white",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div>
            <textarea
              required
              rows={3}
              value={form.message}
              onChange={set("message")}
              placeholder="What are you trying to cut out?"
              aria-label="Your message"
              className={cn(field, "resize-none", fieldErrors.message && "border-rose-400/60")}
            />
            {fieldErrors.message && (
              <p className="mt-1 text-[0.72rem] text-rose-300">{fieldErrors.message}</p>
            )}
          </div>

          {state === "error" && note && (
            <p className="rounded-lg bg-rose-400/10 px-3 py-2 text-[0.76rem] text-rose-200">{note}</p>
          )}

          <button
            type="submit"
            disabled={state === "sending"}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-[0.88rem] font-700 text-ink transition-transform duration-300 hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-60"
          >
            {state === "sending" ? "Sending…" : "Send message"}
          </button>
        </form>
      )}
    </aside>
  );
}
