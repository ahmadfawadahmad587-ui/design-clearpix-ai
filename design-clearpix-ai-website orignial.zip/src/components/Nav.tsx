import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { Close, Logo, Menu, Sparkle, Wordmark } from "./Icons";

const LINKS = [
  { id: "home", label: "Home" },
  { id: "features", label: "Features" },
  { id: "how", label: "How It Works" },
  { id: "api", label: "API" },
  { id: "pricing", label: "Pricing" },
  { id: "faq", label: "FAQ" },
];

export function Nav() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 36);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = [...LINKS.map((l) => l.id), "studio"];
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((e): e is HTMLElement => !!e);
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (vis) setActive(vis.target.id);
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: [0, 0.2, 0.6] },
    );
    els.forEach((e) => io.observe(e));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  const go = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        solid
          ? "glass border-b border-line/80 shadow-[0_8px_30px_-18px_rgba(16,24,40,.35)]"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <nav className="mx-auto flex h-[72px] max-w-[1240px] items-center justify-between gap-6 px-5 sm:px-7">
        <a
          href="#home"
          onClick={go("home")}
          className="flex shrink-0 items-center gap-2.5"
          aria-label="CLEARPIX AI home"
        >
          <Logo className="h-9 w-9 drop-shadow-[0_6px_14px_rgba(116,87,255,.45)]" />
          <Wordmark dark={!solid} />
        </a>

        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.id}>
              <a
                href={`#${l.id}`}
                onClick={go(l.id)}
                className={cn(
                  "relative rounded-full px-3.5 py-2 text-[0.875rem] font-500 transition-colors duration-200",
                  solid
                    ? active === l.id
                      ? "text-brand"
                      : "text-ink-soft hover:text-ink"
                    : active === l.id
                      ? "text-white"
                      : "text-white/65 hover:text-white",
                )}
              >
                {l.label}
                <span
                  className={cn(
                    "absolute inset-x-3.5 -bottom-0.5 h-[2px] rounded-full bg-gradient-to-r from-brand to-aqua transition-all duration-300",
                    active === l.id ? "opacity-100" : "scale-x-0 opacity-0",
                  )}
                />
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2.5">
          <a
            href="#/admin"
            className={cn(
              "hidden rounded-full px-4 py-2 text-[0.875rem] font-600 transition-colors sm:inline-flex",
              solid ? "text-ink-soft hover:text-brand" : "text-white/75 hover:text-white",
            )}
          >
            Sign In
          </a>
          <a
            href="#studio"
            onClick={go("studio")}
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-dark px-4 py-2.5 text-[0.85rem] font-700 text-white shadow-[0_10px_26px_-10px_rgba(116,87,255,.9)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_16px_34px_-12px_rgba(116,87,255,1)] sm:px-5"
          >
            <Sparkle className="h-4 w-4" />
            Try for Free
          </a>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
            aria-expanded={open}
            className={cn(
              "inline-flex h-10 w-10 items-center justify-center rounded-xl border transition-colors lg:hidden",
              solid
                ? "border-line bg-white text-ink"
                : "border-white/20 bg-white/10 text-white",
            )}
          >
            {open ? <Close className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* mobile sheet */}
      <div
        className={cn(
          "overflow-hidden border-t transition-[max-height,opacity] duration-400 lg:hidden",
          open
            ? "max-h-[420px] border-line/70 opacity-100"
            : "max-h-0 border-transparent opacity-0",
        )}
      >
        <div className="glass px-5 pt-3 pb-6">
          <ul className="flex flex-col">
            {LINKS.map((l) => (
              <li key={l.id}>
                <a
                  href={`#${l.id}`}
                  onClick={go(l.id)}
                  className={cn(
                    "flex items-center justify-between rounded-xl px-3 py-3 text-[0.98rem] font-600 transition-colors",
                    active === l.id ? "bg-brand-wash text-brand" : "text-ink hover:bg-mist",
                  )}
                >
                  {l.label}
                  <span className="text-ink-muted text-xs">0{LINKS.indexOf(l) + 1}</span>
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#/admin"
            onClick={() => setOpen(false)}
            className="mt-3 block w-full rounded-xl border border-line bg-white py-3 text-center text-[0.92rem] font-600 text-ink-soft"
          >
            Sign In
          </a>
        </div>
      </div>
    </header>
  );
}
