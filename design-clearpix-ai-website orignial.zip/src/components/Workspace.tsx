import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { CompareSlider } from "./CompareSlider";
import {
  Bolt,
  Check,
  Cpu,
  Download,
  Hd,
  Lock,
  Reset,
  Scissors,
  Sparkle,
  Swap,
  Upload,
} from "./Icons";
import { Eyebrow, Reveal } from "./ui";
import { SAMPLES } from "@/data/samples";
import { loadImage } from "@/lib/segment";
import { api, ApiError, type HealthInfo } from "@/lib/api";
import {
  detectBackend,
  exportCutout,
  runCutout,
  saveFile,
  type EngineResult,
} from "@/lib/engine";

type Stage = "idle" | "loaded" | "working" | "done";

interface Source {
  name: string;
  src: string;
  w: number;
  h: number;
  size?: number;
  objectUrl: boolean;
  file?: File | null;
}

const ACCEPT = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
const MAX_MB = 14;

const BACKDROPS = [
  { id: "none", label: "Transparent", value: null as string | null, swatch: "checker" },
  { id: "white", label: "White", value: "#FFFFFF", swatch: "#FFFFFF" },
  { id: "ink", label: "Midnight", value: "#101828", swatch: "#101828" },
  { id: "brand", label: "Violet", value: "#7457FF", swatch: "#7457FF" },
  { id: "aqua", label: "Cyan", value: "#36D9E8", swatch: "#36D9E8" },
  { id: "sand", label: "Sand", value: "#F2E9DD", swatch: "#F2E9DD" },
];

const PIPELINE = [
  "Reading pixels",
  "Profiling backdrop",
  "Tracing subject outline",
  "Recovering enclosed gaps",
  "Removing speckles",
  "Feathering edges",
  "Decontaminating colour",
];


export function Workspace() {
  const [stage, setStage] = useState<Stage>("idle");
  const [source, setSource] = useState<Source | null>(null);
  const [cut, setCut] = useState<EngineResult | null>(null);
  const [progress, setProgress] = useState({ pct: 0, label: "" });
  const [sensitivity, setSensitivity] = useState(50);
  const [backdrop, setBackdrop] = useState<string | null>(null);
  const [credits, setCredits] = useState(3);
  const [dragOver, setDragOver] = useState(false);
  const [toast, setToast] = useState<{ msg: string; tone: "ok" | "warn" } | null>(null);
  const [health, setHealth] = useState<HealthInfo | null>(null);
  const [probing, setProbing] = useState(true);

  const input = useRef<HTMLInputElement>(null);
  const prevSource = useRef<Source | null>(null);
  const prevCut = useRef<EngineResult | null>(null);

  const say = useCallback((msg: string, tone: "ok" | "warn" = "ok") => {
    setToast({ msg, tone });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3600);
    return () => clearTimeout(t);
  }, [toast]);

  // cleanup previous object URLs when the source / cutout changes
  useEffect(() => {
    const old = prevSource.current;
    if (old && old !== source && old.objectUrl) URL.revokeObjectURL(old.src);
    prevSource.current = source;
  }, [source]);
  useEffect(() => {
    const old = prevCut.current;
    if (old && old !== cut) URL.revokeObjectURL(old.url);
    prevCut.current = cut;
  }, [cut]);

  // probe the REST API once; fall back to the in-tab engine when it is absent
  useEffect(() => {
    let alive = true;
    detectBackend()
      .then(async (info) => {
        if (!alive) return;
        setHealth(info);
        if (info) {
          const account = await api.account().catch(() => null);
          if (alive && account) setCredits(account.usage.creditsRemaining);
        }
      })
      .finally(() => alive && setProbing(false));
    return () => {
      alive = false;
    };
  }, []);

  const adoptFile = useCallback(
    async (file: File) => {
      if (!ACCEPT.includes(file.type)) {
        say("Unsupported format — please use PNG, JPG or WEBP.", "warn");
        return;
      }
      if (file.size > MAX_MB * 1024 * 1024) {
        say(`That file is over ${MAX_MB} MB. Try a smaller image.`, "warn");
        return;
      }
      const url = URL.createObjectURL(file);
      try {
        const img = await loadImage(url);
        setCut(null);
        setBackdrop(null);
        setSource({
          name: file.name,
          src: url,
          w: img.naturalWidth,
          h: img.naturalHeight,
          size: file.size,
          objectUrl: true,
          file,
        });
        setStage("loaded");
        say("Image loaded — ready to cut out.");
      } catch {
        URL.revokeObjectURL(url);
        say("We couldn't read that image file.", "warn");
      }
    },
    [say],
  );

  const adoptSample = useCallback(
    async (id: string) => {
      const s = SAMPLES.find((x) => x.id === id)!;
      const img = await loadImage(s.src);
      setCut(null);
      setBackdrop(null);
      setSensitivity(s.sensitivity);
      setSource({
        name: `${s.name.toLowerCase().replace(/\s+/g, "-")}.jpg`,
        src: s.src,
        w: img.naturalWidth,
        h: img.naturalHeight,
        objectUrl: false,
        file: null,
      });
      setStage("loaded");
      say(`Sample loaded — ${s.name}.`);
    },
    [say],
  );

  const run = useCallback(async () => {
    if (!source) return;
    setStage("working");
    setProgress({ pct: 4, label: "Reading pixels" });
    try {
      const res = await runCutout(
        { src: source.src, name: source.name, file: source.file },
        { sensitivity, onProgress: (pct, label) => setProgress({ pct, label }) },
      );
      setCut(res);
      setStage("done");
      say(
        res.mode === "server"
          ? `Subject isolated by the API in ${res.ms} ms.`
          : `Subject isolated in-browser in ${res.ms} ms.`,
      );
    } catch (err) {
      setStage("loaded");
      say(err instanceof ApiError ? err.message : "Something went wrong while processing.", "warn");
    }
  }, [source, sensitivity, say]);

  const download = useCallback(async () => {
    if (!cut) return;
    if (cut.mode === "local" && credits <= 0) {
      say("Demo export limit reached — this prototype has no billing.", "warn");
      return;
    }
    try {
      const outcome = await exportCutout(cut, backdrop, source?.name ?? "image");
      saveFile(outcome);
      setCredits((c) => outcome.creditsRemaining ?? c - 1);
      say(
        `${backdrop ? "PNG exported with backdrop" : "Transparent PNG exported"} · ${
          outcome.mode === "server" ? "via API" : "local engine"
        }.`,
      );
    } catch (err) {
      say(
        err instanceof ApiError ? err.message : "The export could not be completed.",
        "warn",
      );
      if (err instanceof ApiError && err.code === "credits_exhausted") setCredits(0);
    }
  }, [cut, credits, backdrop, source, say]);

  const reset = useCallback(() => {
    setCut(null);
    setSource(null);
    setStage("idle");
    setBackdrop(null);
    setProgress({ pct: 0, label: "" });
    if (input.current) input.current.value = "";
  }, []);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) void adoptFile(f);
  };

  const activeStep = PIPELINE.findIndex((p) => p === progress.label);

  return (
    <section id="studio" className="relative scroll-mt-24 bg-mist py-20 sm:py-28">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[340px]"
        style={{
          background:
            "radial-gradient(ellipse 60% 100% at 50% 0%, rgba(116,87,255,.14), transparent 70%)",
        }}
      />

      <div className="relative mx-auto max-w-[1240px] px-5 sm:px-7">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <Eyebrow>
              <Cpu className="h-3.5 w-3.5" /> The Workspace
            </Eyebrow>
          </Reveal>
          <Reveal delay={60}>
            <h2 className="font-display mt-5 text-[2rem] leading-[1.08] font-700 tracking-[-0.025em] text-ink sm:text-[2.7rem]">
              Drop an image. Keep the <span className="text-gradient">subject</span>.
            </h2>
          </Reveal>
          <Reveal delay={110}>
            <p className="mt-4 text-[1.02rem] leading-relaxed text-ink-soft">
              Everything happens locally, right here in this browser tab. Load one of our studio
              samples or bring your own photo.
            </p>
          </Reveal>
        </div>

        <Reveal delay={140}>
          <div className="relative mt-12">
            <div
              aria-hidden
              className="absolute -inset-3 rounded-[2.6rem] bg-gradient-to-br from-brand/18 via-transparent to-aqua/18 blur-2xl"
            />
            <div className="relative overflow-hidden rounded-[2rem] border border-line bg-white p-3 shadow-card sm:rounded-[2.3rem] sm:p-4">
              {/* window chrome */}
              <div className="mb-3 flex flex-wrap items-center justify-between gap-3 px-2 pt-1.5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-aqua text-white">
                    <Scissors className="h-4 w-4" />
                  </span>
                  <span className="font-display text-[0.8rem] font-700 tracking-[0.14em] text-ink uppercase">
                    Cutout Studio
                  </span>
                  <span
                    className={cn(
                      "ml-1 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-700 tracking-[0.1em] uppercase",
                      stage === "working"
                        ? "bg-aqua-wash text-aqua-dark"
                        : stage === "done"
                          ? "bg-emerald-50 text-emerald-600"
                          : "bg-mist text-ink-muted",
                    )}
                  >
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        stage === "working"
                          ? "animate-pulse bg-aqua-dark"
                          : stage === "done"
                            ? "bg-emerald-500"
                            : "bg-ink-muted",
                      )}
                    />
                    {stage === "idle"
                      ? "awaiting image"
                      : stage === "loaded"
                        ? "ready"
                        : stage === "working"
                          ? "processing"
                          : "cutout ready"}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    title={
                      health
                        ? `${health.service} v${health.version} · ${health.queue.concurrency} worker thread(s)`
                        : "REST API not reachable — the identical pipeline runs in this tab"
                    }
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-700 tracking-[0.08em] uppercase",
                      probing
                        ? "border-line bg-mist text-ink-muted"
                        : health
                          ? "border-emerald-200 bg-emerald-50 text-emerald-600"
                          : "border-brand/20 bg-brand-wash text-brand",
                    )}
                  >
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        probing
                          ? "animate-pulse bg-ink-muted"
                          : health
                            ? "bg-emerald-500"
                            : "bg-brand",
                      )}
                    />
                    {probing ? "probing api" : health ? "api connected" : "local engine"}
                  </span>
                  <span className="hidden items-center gap-1.5 text-[11px] font-600 text-ink-muted sm:inline-flex">
                    <Lock className="h-3.5 w-3.5 text-brand" />
                    {health ? "Private session · assets auto-expire" : "Nothing leaves this device"}
                  </span>
                </div>
              </div>

              <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_336px]">
                {/* ================= STAGE ================= */}
                <div className="flex flex-col gap-3">
                  <div className="relative min-h-[380px] overflow-hidden rounded-[1.5rem] bg-[#0d1322] sm:min-h-[500px]">
                    {stage === "idle" && (
                      <div
                        role="button"
                        tabIndex={0}
                        onClick={() => input.current?.click()}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            input.current?.click();
                          }
                        }}
                        onDragOver={(e) => {
                          e.preventDefault();
                          setDragOver(true);
                        }}
                        onDragLeave={() => setDragOver(false)}
                        onDrop={onDrop}
                        className={cn(
                          "absolute inset-0 m-3 flex cursor-pointer flex-col items-center justify-center rounded-[1.2rem] border-2 border-dashed px-6 py-10 text-center transition-all duration-300",
                          dragOver
                            ? "scale-[0.99] border-aqua bg-aqua/10"
                            : "border-white/18 bg-white/[0.03] hover:border-brand-light/70 hover:bg-white/[0.06]",
                        )}
                      >
                        <div className="relative mb-6">
                          <span className="animate-pulse-ring absolute inset-0 rounded-full bg-brand/40" />
                          <span
                            className="animate-pulse-ring absolute inset-0 rounded-full bg-aqua/30"
                            style={{ animationDelay: "1.1s" }}
                          />
                          <span className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-brand to-brand-dark text-white shadow-[0_0_46px_-6px_rgba(116,87,255,.9)]">
                            <Upload className="h-8 w-8" />
                          </span>
                        </div>
                        <h3 className="font-display text-[1.3rem] font-700 tracking-[-0.01em] text-white sm:text-[1.55rem]">
                          Drag &amp; drop your image here
                        </h3>
                        <p className="mt-2.5 max-w-sm text-[0.9rem] leading-relaxed text-white/50">
                          Clean, evenly lit studio shots give the sharpest cutouts. Your file is
                          read directly from your device.
                        </p>
                        <span
                          onClick={(e) => {
                            e.stopPropagation();
                            input.current?.click();
                          }}
                          className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-[0.92rem] font-700 text-ink shadow-[0_14px_34px_-14px_rgba(0,0,0,.8)] transition-transform duration-300 hover:-translate-y-0.5"
                        >
                          <Upload className="h-[18px] w-[18px] text-brand" />
                          Upload Image
                        </span>
                        <p className="mt-5 text-[0.76rem] font-600 tracking-[0.1em] text-white/35 uppercase">
                          PNG · JPG · WEBP — up to {MAX_MB} MB
                        </p>
                      </div>
                    )}

                    {stage !== "idle" && source && (
                      <>
                        {stage === "done" && cut ? (
                          <CompareSlider
                            before={source.src}
                            after={cut.url}
                            fit="contain"
                            checker="md"
                            backdrop={backdrop}
                            initial={50}
                            alt={source.name}
                            className="absolute inset-0 h-full w-full"
                          />
                        ) : (
                          <div className="absolute inset-0">
                            <img
                              src={source.src}
                              alt={source.name}
                              className="absolute inset-0 h-full w-full object-contain"
                              draggable={false}
                            />
                            {stage === "working" && (
                              <div className="pointer-events-none absolute inset-0 overflow-hidden bg-ink/35 backdrop-blur-[1px]">
                                <div className="animate-scan absolute inset-x-0 h-[22%] bg-gradient-to-b from-transparent via-aqua/45 to-transparent" />
                                <div
                                  className="absolute inset-x-0 h-px bg-aqua shadow-[0_0_22px_4px_rgba(54,217,232,.8)]"
                                  style={{ top: `${progress.pct}%` }}
                                />
                              </div>
                            )}
                          </div>
                        )}

                        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-between gap-3 bg-gradient-to-t from-black/60 to-transparent px-4 pt-10 pb-3.5">
                          <span className="truncate text-[0.78rem] font-600 text-white/85">
                            {source.name}
                          </span>
                          <span className="shrink-0 rounded-full bg-black/40 px-2.5 py-1 text-[10px] font-700 tracking-[0.1em] text-white/80 uppercase backdrop-blur-sm">
                            {source.w} × {source.h}
                          </span>
                        </div>
                      </>
                    )}

                    {stage === "working" && (
                      <div className="absolute inset-x-0 top-0 p-4">
                        <div className="glass-dark rounded-xl border border-white/10 px-4 py-3">
                          <div className="flex items-center justify-between text-[0.78rem] font-600 text-white/90">
                            <span className="inline-flex items-center gap-2">
                              <Sparkle className="h-3.5 w-3.5 text-aqua" />
                              {progress.label || "Working"}…
                            </span>
                            <span className="tabular-nums text-aqua">{Math.round(progress.pct)}%</span>
                          </div>
                          <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-white/15">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-brand to-aqua transition-[width] duration-300"
                              style={{ width: `${progress.pct}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* ---- toolbar ---- */}
                  <div className="flex flex-wrap items-center gap-2.5 rounded-2xl border border-line bg-mist/70 p-2.5">
                    <button
                      type="button"
                      onClick={run}
                      disabled={!source || stage === "working"}
                      className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-brand to-brand-dark px-5 py-3 text-[0.88rem] font-700 text-white shadow-[0_12px_28px_-12px_rgba(116,87,255,.9)] transition-all duration-300 hover:-translate-y-0.5 disabled:pointer-events-none disabled:opacity-40 sm:flex-none"
                    >
                      <Scissors className="h-[17px] w-[17px]" />
                      {stage === "done" ? "Run Again" : "Remove Background"}
                    </button>

                    <button
                      type="button"
                      onClick={download}
                      disabled={stage !== "done"}
                      className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-ink px-5 py-3 text-[0.88rem] font-700 text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#1b2538] disabled:pointer-events-none disabled:opacity-30 sm:flex-none"
                    >
                      <Download className="h-[17px] w-[17px]" />
                      Download PNG
                    </button>

                    <button
                      type="button"
                      onClick={() => input.current?.click()}
                      className="inline-flex items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 py-3 text-[0.86rem] font-600 text-ink-soft transition-all duration-300 hover:-translate-y-0.5 hover:border-brand/30 hover:text-brand"
                    >
                      <Swap className="h-[17px] w-[17px]" />
                      Replace
                    </button>

                    <button
                      type="button"
                      onClick={reset}
                      disabled={!source}
                      className="inline-flex items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 py-3 text-[0.86rem] font-600 text-ink-soft transition-all duration-300 hover:-translate-y-0.5 hover:border-rose-200 hover:text-rose-500 disabled:pointer-events-none disabled:opacity-40"
                    >
                      <Reset className="h-[17px] w-[17px]" />
                      Reset
                    </button>
                  </div>
                </div>

                {/* ================= PANEL ================= */}
                <aside className="flex flex-col gap-3">
                  {/* samples */}
                  <div className="rounded-2xl border border-line bg-white p-4">
                    <p className="text-[0.72rem] font-700 tracking-[0.14em] text-ink-muted uppercase">
                      Studio samples
                    </p>
                    <div className="mt-3 grid grid-cols-5 gap-2">
                      {SAMPLES.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          title={s.name}
                          onClick={() => void adoptSample(s.id)}
                          className={cn(
                            "group relative aspect-square overflow-hidden rounded-xl border-2 transition-all duration-300 hover:-translate-y-0.5",
                            source?.src === s.src
                              ? "border-brand shadow-[0_0_0_3px_rgba(116,87,255,.14)]"
                              : "border-transparent hover:border-brand/40",
                          )}
                        >
                          <img src={s.src} alt={s.name} className="h-full w-full object-cover" />
                        </button>
                      ))}
                    </div>
                    <p className="mt-2.5 text-[0.74rem] leading-relaxed text-ink-muted">
                      Tap a thumbnail to load a licensed demo photo.
                    </p>
                  </div>

                  {/* precision */}
                  <div className="rounded-2xl border border-line bg-white p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-[0.72rem] font-700 tracking-[0.14em] text-ink-muted uppercase">
                        Edge precision
                      </p>
                      <span className="rounded-md bg-brand-wash px-2 py-0.5 text-[0.72rem] font-700 tabular-nums text-brand">
                        {sensitivity}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={16}
                      max={86}
                      value={sensitivity}
                      onChange={(e) => setSensitivity(+e.target.value)}
                      aria-label="Edge precision"
                      className="mt-3.5 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-line accent-brand"
                      style={{
                        background: `linear-gradient(90deg,#7457FF 0%,#36D9E8 ${((sensitivity - 16) / 70) * 100}%, #E4E9F2 ${((sensitivity - 16) / 70) * 100}%)`,
                      }}
                    />
                    <div className="mt-2 flex justify-between text-[0.7rem] font-600 text-ink-muted">
                      <span>Keep more</span>
                      <span>Cut more</span>
                    </div>
                    <p className="mt-2.5 text-[0.74rem] leading-relaxed text-ink-muted">
                      Controls how aggressively the engine treats colours as backdrop. Re-run after
                      adjusting.
                    </p>
                  </div>

                  {/* pipeline / result */}
                  <div className="flex-1 rounded-2xl border border-line bg-white p-4">
                    <p className="text-[0.72rem] font-700 tracking-[0.14em] text-ink-muted uppercase">
                      {stage === "done" ? "Result" : "Pipeline"}
                    </p>

                    {stage === "done" && cut ? (
                      <>
                        <dl className="mt-3 grid grid-cols-2 gap-2">
                          {[
                            { k: "Output", v: `${cut.width}×${cut.height}` },
                            { k: "Time", v: `${cut.ms} ms` },
                            { k: "Subject", v: `${(cut.coverage * 100).toFixed(0)}%` },
                            { k: "Backdrop", v: cut.backdrop.toUpperCase() },
                            { k: "Engine", v: cut.mode === "server" ? "REST API" : "In-browser" },
                            { k: "Job", v: cut.jobId ?? "local" },
                          ].map((x) => (
                            <div key={x.k} className="rounded-xl bg-mist px-3 py-2.5">
                              <dt className="text-[0.68rem] font-700 tracking-[0.1em] text-ink-muted uppercase">
                                {x.k}
                              </dt>
                              <dd className="mt-0.5 truncate text-[0.84rem] font-700 text-ink">{x.v}</dd>
                            </div>
                          ))}
                        </dl>
                        <p className="mt-4 text-[0.72rem] font-700 tracking-[0.14em] text-ink-muted uppercase">
                          Preview backdrop
                        </p>
                        <div className="mt-2.5 flex flex-wrap gap-2">
                          {BACKDROPS.map((b) => (
                            <button
                              key={b.id}
                              type="button"
                              title={b.label}
                              onClick={() => setBackdrop(b.value)}
                              className={cn(
                                "h-8 w-8 rounded-lg border-2 transition-transform duration-200 hover:scale-110",
                                backdrop === b.value
                                  ? "border-brand shadow-[0_0_0_3px_rgba(116,87,255,.15)]"
                                  : "border-line",
                                b.swatch === "checker" && "checkerboard-sm",
                              )}
                              style={b.swatch !== "checker" ? { background: b.swatch } : undefined}
                            />
                          ))}
                        </div>
                      </>
                    ) : (
                      <ol className="mt-3 space-y-2">
                        {PIPELINE.map((p, i) => {
                          const done = stage === "working" && activeStep > i;
                          const now = stage === "working" && activeStep === i;
                          return (
                            <li
                              key={p}
                              className={cn(
                                "flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-[0.8rem] font-600 transition-colors duration-300",
                                now ? "bg-brand-wash text-brand" : done ? "text-ink" : "text-ink-muted",
                              )}
                            >
                              <span
                                className={cn(
                                  "flex h-5 w-5 shrink-0 items-center justify-center rounded-md text-[0.62rem] font-700",
                                  done
                                    ? "bg-emerald-500 text-white"
                                    : now
                                      ? "bg-brand text-white"
                                      : "bg-mist text-ink-muted",
                                )}
                              >
                                {done ? <Check className="h-3 w-3" /> : i + 1}
                              </span>
                              {p}
                            </li>
                          );
                        })}
                      </ol>
                    )}
                  </div>

                  {/* credits */}
                  <div className="rounded-2xl border border-brand/18 bg-gradient-to-br from-brand-wash to-aqua-wash p-4">
                    <div className="flex items-center justify-between">
                      <span className="inline-flex items-center gap-2 text-[0.8rem] font-700 text-ink">
                        <Hd className="h-4 w-4 text-brand" />
                        Demo exports
                      </span>
                      <span className="rounded-full bg-white px-2.5 py-1 text-[0.74rem] font-700 tabular-nums text-brand">
                        {Math.max(0, credits)} / 3 left
                      </span>
                    </div>
                    <div className="mt-2.5 flex gap-1.5">
                      {[0, 1, 2].map((i) => (
                        <span
                          key={i}
                          className={cn(
                            "h-1.5 flex-1 rounded-full",
                            i < credits ? "bg-gradient-to-r from-brand to-aqua" : "bg-white/70",
                          )}
                        />
                      ))}
                    </div>
                    <p className="mt-2.5 text-[0.73rem] leading-relaxed text-ink-soft">
                      Free-plan allowance for this prototype.{" "}
                      <button
                        type="button"
                        onClick={async () => {
                          if (health) {
                            const res = await api.resetCredits().catch(() => null);
                            setCredits(res?.credits ?? 3);
                            say(res ? "Credits refilled on the server." : "Demo credits reset.");
                          } else {
                            setCredits(3);
                            say("Demo credits reset.");
                          }
                        }}
                        className="font-700 text-brand underline underline-offset-2"
                      >
                        Reset credits
                      </button>
                    </p>
                  </div>
                </aside>
              </div>

              {/* honest disclosure */}
              <div className="mt-3 flex items-start gap-3 rounded-2xl border border-line bg-mist/80 px-4 py-3.5">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-ink text-white">
                  <Bolt className="h-3.5 w-3.5" />
                </span>
                <p className="text-[0.78rem] leading-relaxed text-ink-soft">
                  <strong className="font-700 text-ink">Prototype notice.</strong> The cutout is
                  genuine: an edge-aware colour segmentation pipeline (border flood-fill matting,
                  feathering and colour decontamination). It is <em>not</em> a trained neural
                  network, and no third-party AI service is called.{" "}
                  {health ? (
                    <>
                      The CLEARPIX REST API is reachable, so this image is processed by the Node
                      backend in a worker thread — uploads and renders are scoped to your session
                      and swept from disk automatically.
                    </>
                  ) : (
                    <>
                      The REST API is not running, so the identical pipeline executes in this tab
                      and nothing is uploaded. Start it with{" "}
                      <code className="rounded bg-white px-1 py-0.5 font-mono text-[0.72rem] text-brand">
                        node server/index.js
                      </code>{" "}
                      to switch to the backend.
                    </>
                  )}{" "}
                  Results are strongest on photos with an evenly lit backdrop.
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      <input
        ref={input}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void adoptFile(f);
        }}
      />

      {/* toast */}
      <div
        aria-live="polite"
        className={cn(
          "pointer-events-none fixed inset-x-0 bottom-7 z-50 flex justify-center px-4 transition-all duration-400",
          toast ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0",
        )}
      >
        {toast && (
          <div
            className={cn(
              "glass-dark flex max-w-md items-center gap-2.5 rounded-full border px-5 py-3 text-[0.85rem] font-600 text-white shadow-float",
              toast.tone === "warn" ? "border-amber-300/40" : "border-white/15",
            )}
          >
            <span
              className={cn(
                "flex h-5 w-5 items-center justify-center rounded-full",
                toast.tone === "warn" ? "bg-amber-400 text-ink" : "bg-aqua text-ink",
              )}
            >
              <Check className="h-3 w-3" />
            </span>
            {toast.msg}
          </div>
        )}
      </div>
    </section>
  );
}
