import { useState } from "react";
import { cn } from "@/utils/cn";
import { ChevronDown, Shield } from "./Icons";
import { ContactCard } from "./ContactCard";
import { Reveal, SectionHeading } from "./ui";

const QA = [
  {
    q: "What is CLEARPIX AI?",
    a: "CLEARPIX AI is a background-removal workspace for photographers, online sellers and designers. You load an image, the engine separates the subject from its backdrop, and you export a transparent PNG you can drop onto any new background. This site is a design prototype: the interface, the workflow and the cutout engine are all real and interactive, while billing and account features are illustrative only.",
  },
  {
    q: "How does background removal work?",
    a: "The demo engine runs entirely in your browser. It profiles the dominant colour around the image border, flood-fills inward wherever the pixels still match that backdrop (following gentle gradients so studio sweeps are handled), recovers enclosed gaps such as the space inside a handle, discards tiny speckles, then feathers the boundary and removes colour spill so the old backdrop does not fringe your subject. It is a deterministic computer-vision pipeline rather than a trained neural network — we would rather tell you exactly what runs than imply a model that is not there.",
  },
  {
    q: "Which image formats are supported?",
    a: "PNG, JPG/JPEG and WEBP files up to 14 MB. Images are processed at up to 1500 pixels on the long edge in this demo, which keeps the interaction instant while still producing a usable high-resolution export.",
  },
  {
    q: "Can I download transparent PNG files?",
    a: "Yes. The Download PNG button saves a genuine 32-bit PNG with a real alpha channel — semi-transparent pixels along the edge included. If you pick one of the preview backdrops, the exported file is flattened onto that colour instead, so you can grab either version.",
  },
  {
    q: "Is the tool free?",
    a: "The workspace on this page is free to use and includes three demo exports, which you can reset at any time from the credits panel. The Pro and Business tiers shown in the pricing section are concept tiers for this prototype — there is no checkout, no payment processor and no active subscription.",
  },
  {
    q: "Is my uploaded image private?",
    a: "Yes. When the REST API is not running, your file never leaves the tab: it is read with the File API, decoded into a canvas, processed in memory and discarded on reset. When the API is running, the upload is scoped to your own signed session, is only readable by that session, and both the upload and the render are swept from disk automatically after a few hours. No analytics capture your image either way.",
  },
  {
    q: "Is there a backend, or is this all front-end?",
    a: "There is a real backend. The /server folder contains a Node + Express service with versioned REST routes, multipart uploads, a worker-thread job queue with live progress polling, signed sessions (scrypt password hashing and HMAC tokens), per-owner access control, rate limiting, plan and credit enforcement, a JSON document store and automatic asset expiry. Start it with `node server/index.js` and the workspace switches from the in-browser engine to the API automatically — the status chip above the canvas always tells you which one produced your cutout.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative scroll-mt-24 bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
        <SectionHeading
          eyebrow={
            <>
              <Shield className="h-3.5 w-3.5" /> FAQ
            </>
          }
          title={
            <>
              Answers, <span className="text-gradient">in plain language</span>.
            </>
          }
          lead="Everything worth knowing before you drop your first file into the workspace."
        />

        <div className="mx-auto mt-14 grid max-w-[1000px] gap-10 lg:grid-cols-[minmax(0,1fr)_300px]">
          <div className="space-y-3">
            {QA.map((item, i) => {
              const isOpen = open === i;
              return (
                <Reveal key={item.q} delay={i * 55}>
                  <div
                    className={cn(
                      "overflow-hidden rounded-[1.2rem] border transition-all duration-300",
                      isOpen
                        ? "border-brand/25 bg-mist/70 shadow-soft"
                        : "border-line bg-white hover:border-brand/20",
                    )}
                  >
                    <h3>
                      <button
                        type="button"
                        onClick={() => setOpen(isOpen ? null : i)}
                        aria-expanded={isOpen}
                        className="flex w-full items-center justify-between gap-5 px-5 py-5 text-left sm:px-6"
                      >
                        <span
                          className={cn(
                            "text-[1rem] font-700 transition-colors duration-200 sm:text-[1.05rem]",
                            isOpen ? "text-brand" : "text-ink",
                          )}
                        >
                          {item.q}
                        </span>
                        <span
                          className={cn(
                            "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all duration-300",
                            isOpen
                              ? "rotate-180 border-brand bg-brand text-white"
                              : "border-line bg-white text-ink-muted",
                          )}
                        >
                          <ChevronDown className="h-4 w-4" />
                        </span>
                      </button>
                    </h3>
                    <div
                      className={cn(
                        "grid transition-[grid-template-rows,opacity] duration-400 ease-out",
                        isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                      )}
                    >
                      <div className="overflow-hidden">
                        <p className="px-5 pb-5 text-[0.93rem] leading-[1.75] text-ink-soft sm:px-6">
                          {item.a}
                        </p>
                      </div>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>

          <Reveal delay={120}>
            <ContactCard />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
