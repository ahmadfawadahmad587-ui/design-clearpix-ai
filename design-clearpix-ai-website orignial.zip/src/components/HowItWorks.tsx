import { ArrowRight, Cpu, Download, Upload } from "./Icons";
import { Eyebrow, GlowOrb, Reveal } from "./ui";

const STEPS = [
  {
    n: "01",
    title: "Upload Your Image",
    body: "Choose an image from your device — drag it into the workspace or browse for a PNG, JPG or WEBP file.",
    icon: Upload,
  },
  {
    n: "02",
    title: "AI Detects the Subject",
    body: "The system identifies the foreground and separates it from the background, then softens the boundary so edges stay natural.",
    icon: Cpu,
  },
  {
    n: "03",
    title: "Download Your Result",
    body: "Export a transparent PNG ready to use in a store listing, a deck, a thumbnail or a full composite.",
    icon: Download,
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="relative scroll-mt-24 overflow-hidden bg-ink py-20 sm:py-28">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.04) 1px, transparent 1px)",
          backgroundSize: "70px 70px",
          maskImage: "radial-gradient(ellipse 70% 70% at 50% 40%, #000 20%, transparent 75%)",
          WebkitMaskImage: "radial-gradient(ellipse 70% 70% at 50% 40%, #000 20%, transparent 75%)",
        }}
      />
      <GlowOrb className="top-0 left-1/4 h-[420px] w-[420px]" color="116,87,255" opacity={0.38} />
      <GlowOrb className="right-4 bottom-0 h-[360px] w-[360px]" color="54,217,232" opacity={0.22} />

      <div className="relative mx-auto max-w-[1240px] px-5 sm:px-7">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <Eyebrow tone="dark">
              <ArrowRight className="h-3.5 w-3.5" /> How It Works
            </Eyebrow>
          </Reveal>
          <Reveal delay={60}>
            <h2 className="font-display mt-5 text-[2rem] leading-[1.08] font-700 tracking-[-0.025em] text-white sm:text-[2.7rem]">
              Three steps. <span className="text-gradient">Zero fuss.</span>
            </h2>
          </Reveal>
          <Reveal delay={110}>
            <p className="mt-4 text-[1.02rem] leading-relaxed text-white/60">
              From raw photo to transparent PNG without opening a single editing panel.
            </p>
          </Reveal>
        </div>

        <div className="relative mt-16">
          {/* connecting rail */}
          <div
            aria-hidden
            className="absolute top-[58px] right-[14%] left-[14%] hidden h-px bg-gradient-to-r from-brand/0 via-brand/60 to-aqua/0 lg:block"
          />
          <div className="grid gap-6 lg:grid-cols-3 lg:gap-8">
            {STEPS.map((s, i) => (
              <Reveal key={s.n} delay={i * 110}>
                <div className="group relative flex h-full flex-col items-center rounded-[1.6rem] border border-white/10 bg-white/[0.045] p-8 text-center backdrop-blur-md transition-all duration-400 hover:-translate-y-1.5 hover:border-white/22 hover:bg-white/[0.08]">
                  <span className="relative z-10 flex h-[58px] w-[58px] items-center justify-center rounded-2xl bg-gradient-to-br from-brand to-brand-dark text-white shadow-[0_14px_34px_-12px_rgba(116,87,255,1)] transition-transform duration-400 group-hover:scale-110">
                    <s.icon className="h-6 w-6" />
                  </span>
                  <span className="font-display mt-6 text-[0.78rem] font-700 tracking-[0.3em] text-aqua">
                    {s.n}
                  </span>
                  <h3 className="font-display mt-2.5 text-[1.3rem] font-700 tracking-[-0.01em] text-white">
                    {s.title}
                  </h3>
                  <p className="mt-3 text-[0.93rem] leading-[1.7] text-white/58">{s.body}</p>
                  <span
                    aria-hidden
                    className="font-display pointer-events-none absolute right-5 bottom-2 text-[4.5rem] leading-none font-700 text-white/[0.045] transition-colors duration-500 group-hover:text-white/[0.08]"
                  >
                    {s.n}
                  </span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
