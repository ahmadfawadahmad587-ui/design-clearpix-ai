import {
  useEffect,
  useRef,
  useState,
  type ElementType,
  type ReactNode,
} from "react";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ */
/* Entrance reveal                                                     */
/* ------------------------------------------------------------------ */
export function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: ElementType;
}) {
  const ref = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            el.setAttribute("data-reveal", "in");
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <Tag
      ref={ref as never}
      data-reveal=""
      style={{ transitionDelay: `${delay}ms` }}
      className={className}
    >
      {children}
    </Tag>
  );
}

/** Fires once when the element first scrolls into view. */
export function useInView<T extends HTMLElement>(rootMargin = "200px") {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;
    const io = new IntersectionObserver(
      (e) => e.forEach((x) => x.isIntersecting && setSeen(true)),
      { rootMargin },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [seen, rootMargin]);
  return { ref, seen };
}

/* ------------------------------------------------------------------ */
/* Primitives                                                          */
/* ------------------------------------------------------------------ */
export function Eyebrow({
  children,
  tone = "light",
  className,
}: {
  children: ReactNode;
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] font-700 tracking-[0.16em] uppercase",
        tone === "light"
          ? "border border-brand/15 bg-white text-brand shadow-[0_1px_2px_rgba(16,24,40,.04)]"
          : "border border-white/15 bg-white/10 text-white/80",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  lead,
  tone = "light",
  align = "center",
  className,
}: {
  eyebrow?: ReactNode;
  title: ReactNode;
  lead?: ReactNode;
  tone?: "light" | "dark";
  align?: "center" | "left";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "max-w-3xl",
        align === "center" ? "mx-auto text-center" : "text-left",
        className,
      )}
    >
      {eyebrow && (
        <Reveal>
          <Eyebrow tone={tone}>{eyebrow}</Eyebrow>
        </Reveal>
      )}
      <Reveal delay={60}>
        <h2
          className={cn(
            "font-display mt-5 text-[2rem] leading-[1.1] font-700 tracking-[-0.02em] sm:text-[2.6rem]",
            tone === "light" ? "text-ink" : "text-white",
          )}
        >
          {title}
        </h2>
      </Reveal>
      {lead && (
        <Reveal delay={120}>
          <p
            className={cn(
              "mt-4 text-[1.02rem] leading-relaxed",
              tone === "light" ? "text-ink-soft" : "text-white/65",
              align === "center" && "mx-auto max-w-2xl",
            )}
          >
            {lead}
          </p>
        </Reveal>
      )}
    </div>
  );
}

type BtnProps = {
  children: ReactNode;
  variant?: "primary" | "ghost" | "outline" | "dark" | "soft";
  size?: "md" | "lg" | "sm";
  className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement> &
  Partial<Pick<HTMLAnchorElement, "href">>;

export function Button({
  children,
  variant = "primary",
  size = "md",
  className,
  href,
  ...rest
}: BtnProps) {
  const Tag: ElementType = href ? "a" : "button";
  return (
    <Tag
      href={href}
      className={cn(
        "group relative inline-flex items-center justify-center gap-2 rounded-full font-600 whitespace-nowrap transition-all duration-300 select-none",
        "disabled:pointer-events-none disabled:opacity-45",
        size === "sm" && "px-4 py-2 text-[0.82rem]",
        size === "md" && "px-5 py-2.5 text-[0.9rem]",
        size === "lg" && "px-7 py-3.5 text-[0.96rem]",
        variant === "primary" &&
          "bg-gradient-to-r from-brand to-brand-dark text-white shadow-[0_10px_30px_-10px_rgba(116,87,255,.75)] hover:-translate-y-0.5 hover:shadow-[0_18px_40px_-12px_rgba(116,87,255,.85)]",
        variant === "dark" &&
          "bg-ink text-white shadow-[0_10px_30px_-12px_rgba(16,24,40,.6)] hover:-translate-y-0.5 hover:bg-[#1b2538]",
        variant === "outline" &&
          "border border-line bg-white text-ink hover:-translate-y-0.5 hover:border-brand/35 hover:text-brand hover:shadow-[0_12px_28px_-14px_rgba(16,24,40,.35)]",
        variant === "soft" &&
          "bg-brand-wash text-brand hover:bg-brand/12 hover:-translate-y-0.5",
        variant === "ghost" &&
          "border border-white/15 bg-white/5 text-white hover:border-white/35 hover:bg-white/10",
        className,
      )}
      {...(rest as Record<string, unknown>)}
    >
      {children}
    </Tag>
  );
}

export function GlowOrb({
  className,
  color = "116,87,255",
  opacity = 0.5,
}: {
  className?: string;
  color?: string;
  opacity?: number;
}) {
  return (
    <div
      aria-hidden
      className={cn("pointer-events-none absolute rounded-full blur-[90px]", className)}
      style={{ background: `radial-gradient(circle, rgba(${color},${opacity}) 0%, rgba(${color},0) 70%)` }}
    />
  );
}
