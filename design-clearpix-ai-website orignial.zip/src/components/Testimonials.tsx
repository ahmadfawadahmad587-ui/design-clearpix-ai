import { Quote, Star } from "./Icons";
import { Reveal, SectionHeading } from "./ui";

const ITEMS = [
  {
    quote:
      "I used to spend twenty minutes per listing in a photo editor. Now I drop the shot in, pull the slider to check the edge, and the transparent PNG is on my product page before my coffee cools.",
    name: "Amara Osei",
    role: "Founder, Lumen Ceramics",
    initials: "AO",
    from: "#7457FF",
    to: "#36D9E8",
  },
  {
    quote:
      "The edge feathering is what sold me. Most one-click tools leave a hard sticker outline around hair — this keeps the softness, so portraits still look photographed rather than cut out.",
    name: "Daniel Reyes",
    role: "Portrait Photographer",
    initials: "DR",
    from: "#5B3FE6",
    to: "#A08FFF",
  },
  {
    quote:
      "Our catalogue team pushes hundreds of SKUs a season. A consistent cutout look across every image — on the same backdrop, at the same crop — is worth more than any single clever feature.",
    name: "Priya Nandakumar",
    role: "Ecommerce Lead, Northfold",
    initials: "PN",
    from: "#13B4C4",
    to: "#7457FF",
  },
  {
    quote:
      "Knowing the image never leaves the browser means I can prep client work on a train with bad signal and not worry about where the file ended up.",
    name: "Tomas Lindqvist",
    role: "Freelance Art Director",
    initials: "TL",
    from: "#36D9E8",
    to: "#5B3FE6",
  },
];

export function Testimonials() {
  return (
    <section id="stories" className="relative scroll-mt-24 bg-mist py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
        <SectionHeading
          eyebrow={
            <>
              <Star className="h-3 w-3" /> Sample Testimonials
            </>
          }
          title={
            <>
              What people would <span className="text-gradient">say</span>.
            </>
          }
          lead="Illustrative placeholder reviews written for this design prototype. The names, companies and quotes below are fictional and are not real customer statements."
        />

        <div className="mt-14 grid gap-5 md:grid-cols-2">
          {ITEMS.map((t, i) => (
            <Reveal key={t.name} delay={i * 80}>
              <figure className="group relative flex h-full flex-col overflow-hidden rounded-[1.6rem] border border-line bg-white p-7 transition-all duration-400 hover:-translate-y-1.5 hover:border-brand/25 hover:shadow-card">
                <Quote className="h-7 w-7 text-brand/18 transition-colors duration-400 group-hover:text-brand/30" />
                <blockquote className="mt-4 flex-1 text-[0.98rem] leading-[1.75] text-ink-soft">
                  “{t.quote}”
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3.5 border-t border-line pt-5">
                  <span
                    className="font-display flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[0.82rem] font-700 text-white"
                    style={{ background: `linear-gradient(135deg, ${t.from}, ${t.to})` }}
                    aria-hidden
                  >
                    {t.initials}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[0.92rem] font-700 text-ink">{t.name}</p>
                    <p className="truncate text-[0.8rem] text-ink-muted">{t.role}</p>
                  </div>
                  <span className="ml-auto flex shrink-0 gap-0.5">
                    {Array.from({ length: 5 }).map((_, k) => (
                      <Star key={k} className="h-3.5 w-3.5 text-amber-400" />
                    ))}
                  </span>
                </figcaption>
                <span
                  aria-hidden
                  className="absolute inset-x-0 bottom-0 h-[3px] origin-left scale-x-0 bg-gradient-to-r from-brand to-aqua transition-transform duration-500 group-hover:scale-x-100"
                />
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
