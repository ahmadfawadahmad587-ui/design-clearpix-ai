import { ArrowRight, Dribbble, Github, LinkedIn, Logo, Scissors, Twitter, Wordmark } from "./Icons";
import { Reveal } from "./ui";

const COLUMNS = [
  {
    title: "Product",
    links: [
      { label: "Workspace", href: "#studio" },
      { label: "Features", href: "#features" },
      { label: "Before & After", href: "#gallery" },
      { label: "Batch Processing", href: "#features", tag: "Soon" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "How It Works", href: "#how" },
      { label: "Developer API", href: "#api", tag: "REST" },
      { label: "Pricing", href: "#pricing" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "Contact", href: "#faq" },
      { label: "Privacy Policy", href: "#faq" },
      { label: "Terms of Service", href: "#faq" },
      { label: "Admin Console", href: "#/admin", tag: "Staff" },
    ],
  },
];

const SOCIALS = [
  { label: "X / Twitter", Icon: Twitter },
  { label: "LinkedIn", Icon: LinkedIn },
  { label: "Dribbble", Icon: Dribbble },
  { label: "GitHub", Icon: Github },
];

export function Footer() {
  const jump = (href: string) => (e: React.MouseEvent) => {
    if (!href.startsWith("#") || href.startsWith("#/")) return;
    e.preventDefault();
    document.getElementById(href.slice(1))?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      {/* ---------- CTA band ---------- */}
      <section className="relative bg-white px-5 pb-20 sm:px-7 sm:pb-24">
        <Reveal>
          <div className="relative mx-auto max-w-[1100px] overflow-hidden rounded-[2rem] bg-ink px-7 py-14 text-center shadow-float sm:px-14 sm:py-20">
            <div
              aria-hidden
              className="pointer-events-none absolute -top-28 -left-20 h-80 w-80 rounded-full blur-[90px]"
              style={{ background: "radial-gradient(circle, rgba(116,87,255,.85), transparent 70%)" }}
            />
            <div
              aria-hidden
              className="pointer-events-none absolute -right-20 -bottom-28 h-80 w-80 rounded-full blur-[90px]"
              style={{ background: "radial-gradient(circle, rgba(54,217,232,.55), transparent 70%)" }}
            />
            <div
              aria-hidden
              className="pointer-events-none absolute inset-0 opacity-50"
              style={{
                backgroundImage:
                  "linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px)",
                backgroundSize: "56px 56px",
                maskImage: "radial-gradient(ellipse 60% 70% at 50% 50%, #000, transparent 75%)",
                WebkitMaskImage: "radial-gradient(ellipse 60% 70% at 50% 50%, #000, transparent 75%)",
              }}
            />
            <div className="relative">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/8 px-3.5 py-1.5 text-[11px] font-700 tracking-[0.16em] text-white/75 uppercase">
                Your Subject. Perfectly Isolated.
              </span>
              <h2 className="font-display mx-auto mt-6 max-w-2xl text-[2.1rem] leading-[1.08] font-700 tracking-[-0.03em] text-white sm:text-[2.9rem]">
                Ready to see your subject <span className="text-gradient">float free</span>?
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-[1rem] leading-relaxed text-white/60">
                Load a studio sample or your own photo. No account, no upload, no waiting — the
                whole engine lives in this tab.
              </p>
              <div className="mt-9 flex flex-wrap justify-center gap-3.5">
                <a
                  href="#studio"
                  onClick={jump("#studio")}
                  className="group inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-brand to-brand-dark px-7 py-4 text-[0.95rem] font-700 text-white shadow-[0_18px_44px_-14px_rgba(116,87,255,1)] transition-all duration-300 hover:-translate-y-0.5"
                >
                  <Scissors className="h-[18px] w-[18px]" />
                  Remove a Background
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                </a>
                <a
                  href="#pricing"
                  onClick={jump("#pricing")}
                  className="inline-flex items-center gap-2 rounded-full border border-white/18 bg-white/[0.06] px-6 py-4 text-[0.95rem] font-600 text-white backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:border-white/40 hover:bg-white/12"
                >
                  Compare plans
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* ---------- footer ---------- */}
      <footer className="relative overflow-hidden border-t border-white/8 bg-[#0B111E] pt-16 pb-9">
        <div
          aria-hidden
          className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[640px] -translate-x-1/2 rounded-full blur-[110px]"
          style={{ background: "radial-gradient(circle, rgba(116,87,255,.28), transparent 70%)" }}
        />
        <div className="relative mx-auto max-w-[1240px] px-5 sm:px-7">
          <div className="grid gap-12 lg:grid-cols-[1.45fr_repeat(3,minmax(0,1fr))]">
            <div className="max-w-sm">
              <div className="flex items-center gap-2.5">
                <Logo className="h-10 w-10" />
                <Wordmark dark />
              </div>
              <p className="mt-5 text-[0.92rem] leading-[1.75] text-white/50">
                Your Subject. Perfectly Isolated. A privacy-first cutout workspace for product
                photography, portraits and everything you need to drop onto a new background.
              </p>
              <div className="mt-6 flex gap-2.5">
                {SOCIALS.map(({ label, Icon }) => (
                  <button
                    key={label}
                    type="button"
                    aria-label={label}
                    className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-white/60 transition-all duration-300 hover:-translate-y-0.5 hover:border-brand/50 hover:bg-brand/15 hover:text-white"
                  >
                    <Icon className="h-[18px] w-[18px]" />
                  </button>
                ))}
              </div>
            </div>

            {COLUMNS.map((col) => (
              <div key={col.title}>
                <h3 className="font-display text-[0.74rem] font-700 tracking-[0.2em] text-white/90 uppercase">
                  {col.title}
                </h3>
                <ul className="mt-5 space-y-3.5">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      <a
                        href={l.href}
                        onClick={jump(l.href)}
                        className="group inline-flex items-center gap-2 text-[0.9rem] text-white/50 transition-colors duration-200 hover:text-white"
                      >
                        <span className="h-px w-0 bg-aqua transition-all duration-300 group-hover:w-3" />
                        {l.label}
                        {"tag" in l && l.tag && (
                          <span className="rounded-full bg-aqua/15 px-2 py-0.5 text-[9px] font-700 tracking-[0.1em] text-aqua uppercase">
                            {l.tag}
                          </span>
                        )}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/8 pt-7 sm:flex-row">
            <p className="text-[0.82rem] text-white/40">
              © {new Date().getFullYear()} CLEARPIX AI — student / portfolio design prototype.
            </p>
            <p className="text-center text-[0.8rem] text-white/35 sm:text-right">
              Interface concept. No payments, accounts or external AI services are connected.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
