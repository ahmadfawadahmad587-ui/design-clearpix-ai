import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

const base = (p: P) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  ...p,
});

export const Sparkle = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3l1.7 4.6L18.3 9l-4.6 1.4L12 15l-1.7-4.6L5.7 9l4.6-1.4L12 3Z" />
    <path d="M18.5 15.5l.8 2.1 2.2.7-2.2.7-.8 2.1-.8-2.1-2.2-.7 2.2-.7.8-2.1Z" />
  </svg>
);

export const Upload = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 16V4" />
    <path d="m7.5 8.5 4.5-4.5 4.5 4.5" />
    <path d="M4 15v2.5A2.5 2.5 0 0 0 6.5 20h11a2.5 2.5 0 0 0 2.5-2.5V15" />
  </svg>
);

export const Download = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 4v12" />
    <path d="m7.5 11.5 4.5 4.5 4.5-4.5" />
    <path d="M4 17v.5A2.5 2.5 0 0 0 6.5 20h11a2.5 2.5 0 0 0 2.5-2.5V17" />
  </svg>
);

export const Reset = (p: P) => (
  <svg {...base(p)}>
    <path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1" />
    <path d="M3.5 4.5V10H9" />
  </svg>
);

export const Swap = (p: P) => (
  <svg {...base(p)}>
    <rect x="3" y="3" width="13" height="13" rx="2.5" />
    <path d="M8 21h10.5A2.5 2.5 0 0 0 21 18.5V8" />
    <path d="m6.5 12 2.6-2.9a1.4 1.4 0 0 1 2 0L16 15" />
    <circle cx="11.5" cy="7.5" r="1.3" />
  </svg>
);

export const Scissors = (p: P) => (
  <svg {...base(p)}>
    <circle cx="6" cy="6" r="2.6" />
    <circle cx="6" cy="18" r="2.6" />
    <path d="M8.2 7.6 20 18" />
    <path d="M8.2 16.4 20 6" />
  </svg>
);

export const Bolt = (p: P) => (
  <svg {...base(p)}>
    <path d="M13.5 2.5 4.8 13.2a.6.6 0 0 0 .47.98H11l-.5 7.3 8.7-10.7a.6.6 0 0 0-.47-.98H13l.5-7.3Z" />
  </svg>
);

export const Hd = (p: P) => (
  <svg {...base(p)}>
    <rect x="2.5" y="4.5" width="19" height="15" rx="3" />
    <path d="M7 9.5v5M7 12h3m0-2.5v5" />
    <path d="M13.8 9.5h1.9a2.5 2.5 0 0 1 2.5 2.5 2.5 2.5 0 0 1-2.5 2.5h-1.9v-5Z" />
  </svg>
);

export const Tag = (p: P) => (
  <svg {...base(p)}>
    <path d="M3.5 11.3V5.2a1.7 1.7 0 0 1 1.7-1.7h6.1c.45 0 .88.18 1.2.5l7 7a1.7 1.7 0 0 1 0 2.4l-6.1 6.1a1.7 1.7 0 0 1-2.4 0l-7-7a1.7 1.7 0 0 1-.5-1.2Z" />
    <circle cx="8" cy="8" r="1.4" />
  </svg>
);

export const Portrait = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.5" y="2.8" width="17" height="18.4" rx="3" />
    <circle cx="12" cy="10" r="3" />
    <path d="M6.8 19.4a5.6 5.6 0 0 1 10.4 0" />
  </svg>
);

export const Layers = (p: P) => (
  <svg {...base(p)}>
    <path d="m12 3 8.5 4.5L12 12 3.5 7.5 12 3Z" />
    <path d="m4 12.5 8 4.3 8-4.3" />
    <path d="m4 16.8 8 4.2 8-4.2" />
  </svg>
);

export const Shield = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 2.8 5 5.5v5.9c0 4.3 3 7.6 7 9.8 4-2.2 7-5.5 7-9.8V5.5l-7-2.7Z" />
    <path d="m9 12 2.2 2.2L15.4 10" />
  </svg>
);

export const Check = (p: P) => (
  <svg {...base(p)}>
    <path d="m5 12.5 4.5 4.5L19 7" />
  </svg>
);

export const ArrowRight = (p: P) => (
  <svg {...base(p)}>
    <path d="M4.5 12h15" />
    <path d="m13.5 6 6 6-6 6" />
  </svg>
);

export const ChevronDown = (p: P) => (
  <svg {...base(p)}>
    <path d="m6 9.5 6 6 6-6" />
  </svg>
);

export const Menu = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 7h16M4 12h16M4 17h16" />
  </svg>
);

export const Close = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);

export const Star = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="m12 2.6 2.9 5.9 6.5.95-4.7 4.58 1.11 6.47L12 17.45 6.19 20.5l1.11-6.47-4.7-4.58 6.5-.95L12 2.6Z" />
  </svg>
);

export const Quote = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="M9.5 5C6.46 6.3 4.6 9.1 4.6 12.6c0 3.5 1.9 5.9 4.6 5.9 2.2 0 3.8-1.6 3.8-3.7 0-2-1.4-3.5-3.3-3.5-.37 0-.7.05-1 .13.4-1.6 1.6-3 3.2-3.9L9.5 5Zm9.1 0c-3.04 1.3-4.9 4.1-4.9 7.6 0 3.5 1.9 5.9 4.6 5.9 2.2 0 3.8-1.6 3.8-3.7 0-2-1.4-3.5-3.3-3.5-.37 0-.7.05-1 .13.4-1.6 1.6-3 3.2-3.9L18.6 5Z" />
  </svg>
);

export const Grid = (p: P) => (
  <svg {...base(p)}>
    <rect x="3.2" y="3.2" width="7.4" height="7.4" rx="2" />
    <rect x="13.4" y="3.2" width="7.4" height="7.4" rx="2" />
    <rect x="3.2" y="13.4" width="7.4" height="7.4" rx="2" />
    <rect x="13.4" y="13.4" width="7.4" height="7.4" rx="2" />
  </svg>
);

export const Lock = (p: P) => (
  <svg {...base(p)}>
    <rect x="4.5" y="10" width="15" height="10.5" rx="2.5" />
    <path d="M8 10V7.5a4 4 0 1 1 8 0V10" />
  </svg>
);

export const Cpu = (p: P) => (
  <svg {...base(p)}>
    <rect x="6.5" y="6.5" width="11" height="11" rx="2.5" />
    <rect x="9.8" y="9.8" width="4.4" height="4.4" rx="1" />
    <path d="M10 3v3.5M14 3v3.5M10 17.5V21M14 17.5V21M3 10h3.5M3 14h3.5M17.5 10H21M17.5 14H21" />
  </svg>
);

export const Twitter = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="M17.5 3h3.2l-7 8 8.2 10h-6.4l-5-6.1L4.7 21H1.5l7.5-8.6L1.2 3h6.6l4.5 5.6L17.5 3Zm-1.1 16.1h1.8L7.7 4.8H5.8l10.6 14.3Z" />
  </svg>
);

export const LinkedIn = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="M4.98 3.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM3 9.5h4v11H3v-11Zm6.5 0h3.8v1.5h.05c.53-.95 1.84-1.95 3.78-1.95 4.04 0 4.79 2.5 4.79 5.76v5.69h-4v-5.05c0-1.2-.02-2.76-1.75-2.76-1.75 0-2.02 1.3-2.02 2.67v5.14h-4v-11Z" />
  </svg>
);

export const Dribbble = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9.2" />
    <path d="M5 7.6c3.9 2 8.9 2.4 13.2.8" />
    <path d="M3.4 13.6c4.5-1.2 9.6.2 12.4 4.6" />
    <path d="M9.4 3.2c3.3 3.6 5.6 8 6.4 13.3" />
  </svg>
);

export const Github = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="M12 2a10 10 0 0 0-3.16 19.49c.5.09.68-.22.68-.48l-.01-1.7c-2.78.6-3.37-1.34-3.37-1.34-.45-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.61.07-.61 1 .07 1.53 1.03 1.53 1.03.9 1.53 2.34 1.09 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.56-1.11-4.56-4.94 0-1.09.39-1.99 1.03-2.69-.1-.25-.45-1.27.1-2.65 0 0 .84-.27 2.75 1.02a9.5 9.5 0 0 1 5 0c1.91-1.29 2.75-1.02 2.75-1.02.55 1.38.2 2.4.1 2.65.64.7 1.03 1.6 1.03 2.69 0 3.84-2.34 4.68-4.57 4.93.36.31.68.92.68 1.85l-.01 2.75c0 .27.18.58.69.48A10 10 0 0 0 12 2Z" />
  </svg>
);

export const Mail = (p: P) => (
  <svg {...base(p)}>
    <rect x="2.8" y="4.8" width="18.4" height="14.4" rx="3" />
    <path d="m4 7.5 7.1 5.1a1.6 1.6 0 0 0 1.8 0L20 7.5" />
  </svg>
);

export function Logo({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 44 44" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="cpx-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7457FF" />
          <stop offset="100%" stopColor="#36D9E8" />
        </linearGradient>
      </defs>
      <rect x="1.5" y="1.5" width="41" height="41" rx="13" fill="url(#cpx-g)" />
      <path d="M13 13h8.5a9 9 0 0 1 0 18H13V13Z" fill="rgba(255,255,255,.96)" />
      <path d="M21.5 18.4H18.4v7.2h3.1a3.6 3.6 0 0 0 0-7.2Z" fill="#101828" opacity=".9" />
      <circle cx="31.6" cy="13.6" r="3" fill="#fff" opacity=".85" />
    </svg>
  );
}

export function Wordmark({ dark = false, className = "" }: { dark?: boolean; className?: string }) {
  return (
    <span
      className={`font-display text-[1.06rem] font-700 tracking-[0.14em] ${
        dark ? "text-white" : "text-ink"
      } ${className}`}
      style={{ fontWeight: 700 }}
    >
      CLEARPIX<span className="text-gradient"> AI</span>
    </span>
  );
}
