import { cn } from "@/utils/cn";
import { Bolt, Grid, Hd, Portrait, Scissors, Sparkle, Tag } from "./Icons";
import { Reveal, SectionHeading } from "./ui";

const FEATURES = [
  {
    icon: Scissors,
    title: "Precision Cutout",
    body: "Intelligent subject detection with clean edges. Feathered alpha and colour decontamination keep hair, straps and thin details believable.",
    accent: true,
    tag: "Core engine",
  },
  {
    icon: Bolt,
    title: "One-Click Removal",
    body: "A simple workflow for background removal — drop a file, press one button, and watch the subject lift away from its backdrop.",
    tag: "Workflow",
  },
  {
    icon: Hd,
    title: "HD Export",
    body: "High-resolution transparent image export. Keep up to 1500px on the long edge in the demo, with crisp PNG alpha for compositing.",
    tag: "Export",
  },
  {
    icon: Tag,
    title: "Product Photo Ready",
    body: "Designed for online stores and product photography. Drop cutouts straight onto marketplace white, brand colours or lifestyle scenes.",
    tag: "Commerce",
  },
  {
    icon: Portrait,
    title: "Portrait Isolation",
    body: "Designed for profile pictures and portraits. Soft edge matting keeps skin tones and flyaway hair from turning into a hard sticker.",
    tag: "People",
  },
  {
    icon: Grid,
    title: "Batch Processing",
    body: "A dedicated interface for processing multiple images, with queue status, shared presets and one combined download. Planned for the Business tier.",
    tag: "Roadmap",
  },
];

export function Features() {
  return (
    <section id="features" className="relative scroll-mt-24 bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
        <SectionHeading
          eyebrow={
            <>
              <Sparkle className="h-3.5 w-3.5" /> Smart AI Features
            </>
          }
          title={
            <>
              Built for people who care about <span className="text-gradient">edges</span>.
            </>
          }
          lead="Every part of CLEARPIX is tuned around one outcome: a subject that looks like it was photographed on transparency in the first place."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={i * 70}>
              <article
                className={cn(
                  "group relative h-full overflow-hidden rounded-[1.6rem] border p-7 transition-all duration-400 hover:-translate-y-1.5",
                  f.accent
                    ? "border-white/10 bg-ink text-white shadow-float"
                    : "border-line bg-mist/60 hover:border-brand/25 hover:bg-white hover:shadow-card",
                )}
              >
                {f.accent && (
                  <>
                    <div
                      aria-hidden
                      className="pointer-events-none absolute -top-20 -right-16 h-52 w-52 rounded-full blur-[70px]"
                      style={{ background: "radial-gradient(circle, rgba(116,87,255,.75), transparent 70%)" }}
                    />
                    <div
                      aria-hidden
                      className="pointer-events-none absolute -bottom-24 -left-10 h-48 w-48 rounded-full blur-[70px]"
                      style={{ background: "radial-gradient(circle, rgba(54,217,232,.45), transparent 70%)" }}
                    />
                  </>
                )}

                <div className="relative flex items-start justify-between">
                  <span
                    className={cn(
                      "flex h-12 w-12 items-center justify-center rounded-[0.95rem] transition-transform duration-400 group-hover:scale-110",
                      f.accent
                        ? "bg-white/12 text-white ring-1 ring-white/20"
                        : "bg-gradient-to-br from-brand to-brand-dark text-white shadow-[0_10px_24px_-10px_rgba(116,87,255,.9)]",
                    )}
                  >
                    <f.icon className="h-[22px] w-[22px]" />
                  </span>
                  <span
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[10px] font-700 tracking-[0.12em] uppercase",
                      f.accent ? "bg-white/10 text-white/70" : "bg-white text-ink-muted ring-1 ring-line",
                    )}
                  >
                    {f.tag}
                  </span>
                </div>

                <h3
                  className={cn(
                    "font-display relative mt-6 text-[1.22rem] font-700 tracking-[-0.01em]",
                    f.accent ? "text-white" : "text-ink",
                  )}
                >
                  {f.title}
                </h3>
                <p
                  className={cn(
                    "relative mt-2.5 text-[0.92rem] leading-[1.65]",
                    f.accent ? "text-white/60" : "text-ink-soft",
                  )}
                >
                  {f.body}
                </p>

                <span
                  aria-hidden
                  className={cn(
                    "absolute inset-x-7 bottom-0 h-[2px] origin-left scale-x-0 rounded-full transition-transform duration-500 group-hover:scale-x-100",
                    f.accent
                      ? "bg-gradient-to-r from-brand-light to-aqua"
                      : "bg-gradient-to-r from-brand to-aqua",
                  )}
                />
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
