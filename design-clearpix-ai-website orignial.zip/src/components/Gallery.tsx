import { useEffect, useState } from "react";
import { CompareSlider } from "./CompareSlider";
import { Layers } from "./Icons";
import { Reveal, SectionHeading, useInView } from "./ui";
import { SAMPLES, type Sample } from "@/data/samples";
import { getCutout } from "@/lib/segment";

const SHOWCASE: Sample[] = [
  SAMPLES[0], // product
  SAMPLES[1], // portrait
  SAMPLES[2], // fashion
  SAMPLES[3], // creative object
];

function GalleryCard({ sample, delay }: { sample: Sample; delay: number }) {
  const { ref, seen } = useInView<HTMLDivElement>("250px");
  const [cut, setCut] = useState<string | null>(null);

  useEffect(() => {
    if (!seen) return;
    let alive = true;
    // stagger so four live cutouts never fight for the main thread at once
    const t = setTimeout(() => {
      getCutout(sample.src, 820, sample.sensitivity)
        .then((r) => alive && setCut(r.url))
        .catch(() => {});
    }, delay * 4);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [seen, sample, delay]);

  return (
    <Reveal delay={delay}>
      <div ref={ref} className="group h-full">
        <div className="h-full overflow-hidden rounded-[1.5rem] border border-line bg-white p-2.5 shadow-soft transition-all duration-400 hover:-translate-y-1.5 hover:border-brand/25 hover:shadow-card">
          <CompareSlider
            before={sample.src}
            after={cut}
            loading={!cut}
            initial={52}
            fit="cover"
            checker="sm"
            alt={sample.name}
            className="aspect-[4/5] w-full rounded-[1.1rem]"
          />
          <div className="flex items-center justify-between gap-3 px-2.5 pt-3.5 pb-2">
            <div className="min-w-0">
              <h3 className="font-display truncate text-[0.98rem] font-700 text-ink">
                {sample.name}
              </h3>
              <p className="mt-0.5 truncate text-[0.78rem] text-ink-muted">{sample.note}</p>
            </div>
            <span className="shrink-0 rounded-full bg-brand-wash px-2.5 py-1 text-[10px] font-700 tracking-[0.08em] text-brand uppercase">
              {sample.category.split(" ")[0]}
            </span>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

export function Gallery() {
  return (
    <section id="gallery" className="relative scroll-mt-24 bg-mist py-20 sm:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-7">
        <SectionHeading
          eyebrow={
            <>
              <Layers className="h-3.5 w-3.5" /> Before &amp; After
            </>
          }
          title={
            <>
              Drag any slider. These cutouts are{" "}
              <span className="text-gradient">generated live</span>.
            </>
          }
          lead="Nothing here is a pre-exported screenshot — each example is processed by the same in-browser engine the moment the card scrolls into view."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SHOWCASE.map((s, i) => (
            <GalleryCard key={s.id} sample={s} delay={i * 90} />
          ))}
        </div>

        <Reveal delay={120}>
          <p className="mt-8 text-center text-[0.82rem] text-ink-muted">
            Sample photography is used for demonstration purposes only.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
