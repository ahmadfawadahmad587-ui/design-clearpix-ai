import { useEffect, useState } from "react";
import { ApiSection } from "@/components/ApiSection";
import { FAQ } from "@/components/FAQ";
import { Features } from "@/components/Features";
import { Footer } from "@/components/Footer";
import { Gallery } from "@/components/Gallery";
import { Hero } from "@/components/Hero";
import { HowItWorks } from "@/components/HowItWorks";
import { Nav } from "@/components/Nav";
import { Pricing } from "@/components/Pricing";
import { Testimonials } from "@/components/Testimonials";
import { Workspace } from "@/components/Workspace";
import { Sparkle } from "@/components/Icons";
import { AdminApp } from "@/admin/AdminApp";

const isAdminRoute = () =>
  location.hash.startsWith("#/admin") || location.pathname.replace(/\/$/, "") === "/admin";

function useAdminRoute() {
  const [admin, setAdmin] = useState(isAdminRoute);
  useEffect(() => {
    const check = () => {
      const next = isAdminRoute();
      setAdmin(next);
      if (next) window.scrollTo(0, 0);
    };
    window.addEventListener("hashchange", check);
    window.addEventListener("popstate", check);
    return () => {
      window.removeEventListener("hashchange", check);
      window.removeEventListener("popstate", check);
    };
  }, []);
  return admin;
}

const MARQUEE = [
  "Transparent PNG export",
  "Hair-level edge feathering",
  "On-device privacy",
  "Product photography",
  "Portrait isolation",
  "WEBP · JPG · PNG",
  "Colour decontamination",
  "Marketplace-ready cutouts",
  "No account required",
];

function ScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setP(h > 0 ? (window.scrollY / h) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);
  return (
    <div className="fixed inset-x-0 top-0 z-[60] h-[3px] bg-transparent" aria-hidden>
      <div
        className="h-full rounded-r-full bg-gradient-to-r from-brand via-brand-light to-aqua transition-[width] duration-150"
        style={{ width: `${p}%` }}
      />
    </div>
  );
}

function CapabilityStrip() {
  const row = [...MARQUEE, ...MARQUEE];
  return (
    <div className="relative overflow-hidden border-y border-line bg-white py-4">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-white to-transparent"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-white to-transparent"
      />
      <div className="animate-marquee flex w-max items-center gap-10">
        {row.map((t, i) => (
          <span
            key={`${t}-${i}`}
            className="flex shrink-0 items-center gap-3 text-[0.8rem] font-700 tracking-[0.16em] text-ink-muted uppercase"
          >
            <Sparkle className="h-3.5 w-3.5 text-brand/70" />
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const admin = useAdminRoute();
  if (admin) return <AdminApp />;

  return (
    <div className="min-h-screen bg-mist">
      <ScrollProgress />
      <Nav />
      <main>
        <Hero />
        <CapabilityStrip />
        <Workspace />
        <Features />
        <Gallery />
        <HowItWorks />
        <ApiSection />
        <Pricing />
        <Testimonials />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}
