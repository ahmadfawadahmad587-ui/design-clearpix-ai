# CLEARPIX AI

**Your Subject. Perfectly Isolated.** — a premium AI-styled background removal
platform: marketing site, interactive cutout workspace, and a real REST backend.

```
├── src/      React 19 + Vite + Tailwind v4 front-end
├── server/   Node + Express REST API (see server/README.md)
└── dist/     single-file production build
```

## Run

```bash
npm install

npm run dev           # front-end on http://localhost:5173
node server/index.js  # API on       http://localhost:8787
```

```bash
npm run build         # build the site
node server/index.js  # now serves the site AND the API on :8787
```

### Admin console

Open `http://localhost:8787/#/admin` (or the "Sign In" / footer "Admin Console"
links) and sign in with the seeded administrator — `admin@clearpix.ai` /
`clearpix-admin` by default (override with `CLEARPIX_ADMIN_EMAIL` and
`CLEARPIX_ADMIN_PASSWORD`). The console requires the API and provides:

- **Overview** — jobs/exports per hour, success rate, queue depth, plan mix, storage, runtime
- **Jobs** — every cutout across all sessions with live progress, source/cutout preview, retry, delete
- **Users** — accounts and guest sessions: change plan, grant/revoke credits, promote/demote, suspend, delete
- **Assets** — uploads on disk and the export ledger
- **Inbox** — contact-form messages with read/resolved workflow
- **System** — pause/resume processing with a maintenance message, TTL sweep, guest purge, config, live log tail

The front-end probes `GET /api/health` on load. If the API answers, uploads are
processed by the Node backend in a worker thread; if it does not, the **identical**
segmentation pipeline runs in the browser tab. The workspace status chip and the
result panel always state which path produced your cutout.

## What is real, and what is not

| Real | Not real |
| --- | --- |
| The cutout engine — deterministic edge-aware colour matting, in the browser and on the server | Any trained neural network or third-party AI service |
| Transparent 32-bit PNG export with a true alpha channel | Payments, checkout or active subscriptions |
| REST API: uploads, job queue, progress polling, exports, sessions, rate limits, plan + credit enforcement | Testimonials — they are clearly labelled fictional samples |
| On-device processing when the API is offline; per-session ownership and TTL sweeps when it is online | Email delivery from the contact form (messages are stored locally) |

Full API documentation, configuration and architecture notes live in
[`server/README.md`](server/README.md).
